# Build the PicoCalc keyboard controller
This distribution contains the PicoOS modifications to the ClockworkPi keyboard firmware, the PU/1 resident updater, and the tools used to produce both images. The stock-derived keyboard firmware and accompanying PicoOS controller source in this distribution are available under GPLv3. See COPYING. Third-party source, notices and licenses are preserved in upstream/. The compiler and Arduino CLI run on the development computer.

Use PowerShell 7, Git, Arduino CLI and a C++20 host compiler on Windows. Run the following from the extracted source root. Git must preserve the upstream line endings. The release includes the exact STM32duino, CMSIS, XPowersLib and original keyboard sources. The following commands install the compiler and core using the Arduino board manager and reproduce the Git identity check in the build script.

```powershell
$ErrorActionPreference = 'Stop'
$lock = Get-Content dependencies.lock.json -Raw | ConvertFrom-Json
$d = $lock.local_dependencies
$root = (Get-Location).Path
New-Item -ItemType Directory -Force .deps,.downloads | Out-Null
Invoke-WebRequest $d.arduino_cli.archive_url -OutFile .downloads/cli.zip
if ((Get-FileHash .downloads/cli.zip).Hash -ne $d.arduino_cli.archive_sha256) { throw 'CLI checksum' }
Expand-Archive .downloads/cli.zip $d.arduino_cli.install_directory -Force
$cli = Join-Path $d.arduino_cli.install_directory arduino-cli.exe
$cfg = $d.arduino_cli.config_file
& $cli config init --dest-file $cfg --overwrite
foreach ($key in 'data','user','downloads') {
  $setting = $key + '_directory'
  & $cli config set "directories.$key" (Join-Path $root $d.arduino_cli.$setting) --config-file $cfg
}
$core = $d.stm32_arduino_core
& $cli core update-index --additional-urls $core.board_manager_url --config-file $cfg
& $cli core install "$($core.package)@$($core.version)" --additional-urls $core.board_manager_url --config-file $cfg
$x = $d.stm32_xpowers
git -c core.autocrlf=false clone $x.repository $x.install_directory
git -C $x.install_directory checkout --detach $x.commit
$stock = Join-Path $lock.reference_dependencies.clockworkpi_picocalc_hardware.install_directory Code/picocalc_keyboard
New-Item -ItemType Directory -Force $stock | Out-Null
Copy-Item upstream/clockworkpi/* $stock
./scripts/stm32-updater-build.ps1
./scripts/stm32-firmware.ps1 stock-updatable-proof
```

In a Visual Studio developer shell with MSVC available, build the two host packers and package the images. Use the build identity compiled into your application. A modified application needs its own identity. The ROM path in INSTALL.md also works for locally built modified firmware and does not depend on a release-signing key.

```powershell
cl /nologo /EHsc /std:c++20 /Icontroller/include controller/tools/install_pack.cpp controller/src/updater.cpp /Fe:build/install-pack.exe
cl /nologo /EHsc /std:c++20 /Icontroller/include controller/tools/update_pack.cpp controller/src/updater.cpp /Fe:build/update-pack.exe
$elf = 'build/stm32-stock-updatable-proof-output/picocalc_keyboard.ino.elf'
./build/install-pack.exe build/stm32-resident-updater/resident-NOT-ACCEPTED.bin $elf build/initial-install.bin 53540114
./build/update-pack.exe $elf build/controller-update.pcu 53540114
```
