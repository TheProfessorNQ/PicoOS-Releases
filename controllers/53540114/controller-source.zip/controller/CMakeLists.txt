add_library(calc_stm32_protocol STATIC
    src/protocol.c
)
add_library(calc::stm32_protocol ALIAS calc_stm32_protocol)
target_include_directories(calc_stm32_protocol PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
)
target_compile_features(calc_stm32_protocol PUBLIC c_std_11)
calc_set_project_warnings(calc_stm32_protocol)

add_library(calc_stm32_model STATIC
    src/client.cpp
    src/diagnostic.cpp
    src/f103_rtc.cpp
    src/hardware.cpp
    src/model.cpp
    src/self_test.cpp
    src/server.cpp
    src/stock_extension.cpp
    src/transport.cpp
)
add_library(calc::stm32_model ALIAS calc_stm32_model)
target_include_directories(calc_stm32_model PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
)
target_link_libraries(calc_stm32_model PUBLIC calc::stm32_protocol)
target_compile_features(calc_stm32_model PUBLIC cxx_std_20)
calc_set_project_warnings(calc_stm32_model)

add_library(calc_stm32_updater STATIC src/updater.cpp src/update_flash.cpp src/update_sender.cpp src/update_i2c.cpp src/update_power.cpp src/update_entry.cpp)
target_include_directories(calc_stm32_updater PUBLIC include)
target_compile_features(calc_stm32_updater PUBLIC cxx_std_20)
calc_set_project_warnings(calc_stm32_updater)

add_executable(controller-update-pack tools/update_pack.cpp)
target_link_libraries(controller-update-pack PRIVATE calc_stm32_updater)
calc_set_project_warnings(controller-update-pack)
add_executable(controller-install-pack tools/install_pack.cpp)
target_link_libraries(controller-install-pack PRIVATE calc_stm32_updater)
calc_set_project_warnings(controller-install-pack)
