# PicoOS STM32 controller

Active board development (2026-11-20): `stock/picocalc_keyboard` is a derivative
of pinned ClockworkPi source. It retains stock board behavior and adds a
read-only private key-state endpoint. Build with `stm32-firmware.ps1 stock-candidate`.
Factory backup/restore and physical acceptance remain pending; use
`docs/STM32_STOCK_ROADMAP.md` for current sequencing. The portable libraries below
support this work but their full model is not a complete hardware implementation.

This directory contains the hardware-independent protocol and behavioral model
for the planned PicoOS firmware on the PicoCalc's STM32F103R8T6 keyboard/power
controller.

Current status:

- the bounded I2C framing contract is implemented in portable C11;
- protocol 1.2 requires a harmless transaction-zero session sync before a new
  RP2350 client may issue ordinary commands;
- prepared RP firmware now consumes the stock-derived physical stream and
  coherent Caps/held snapshots; factory keyboards keep their existing route.
  Physical acceptance is pending; see `proofs/CONTROLLER_INPUT_2026-11-20.md`;
- the fixed-memory keyboard, power, RTC, backlight-heartbeat, headphone, PMU
  telemetry, diagnostic, and optional allowlisted-GPIO reference model is
  implemented in C++20 for host verification;
- the pinned untouched ClockworkPi controller baseline can be reproduced with
  `scripts/stm32-firmware.ps1 baseline`;
- the complete portable logic cross-compiles for the F103R8 with
  `scripts/stm32-firmware.ps1 logic-proof`; that proof has no board adapters and
  is deliberately non-flashable;
- `DiagnosticRuntime` permanently selects a restricted command profile and an
  empty output policy; `scripts/stm32-firmware.ps1 diagnostic-proof`
  cross-compiles this non-flashable first-contact scaffold for F103R8;
- `run_self_test()` provides one deterministic fixed-memory logic check shared
  by host tests, the F103 proof, and the loose-Pico RP2350 lab image;
- `ControllerHardwareAdapter` is a fixed-memory, callback-based boundary whose
  physical outputs all default disabled; host fixtures cover reset bootstrap,
  held-key repair, output retry, and graceful shutdown ordering;
- the V2.0/F103 backlight board driver is implemented in
  `boards/picocalc/backlights.cpp`: independent PA8 LCD / PC8 keyboard PWM,
  10 kHz, normalized levels mapped to the stock adjustment ceiling, and static
  low outputs with stopped timers for off. Host fixtures compile this actual
  driver against fake peripherals; `scripts/stm32-firmware.ps1 backlight-proof`
  also links it against the pinned real STM32 core without invoking it;
- no integrated custom STM32 device image is built or flashed yet; and
- factory recovery and physical validation remain mandatory before device code
  is enabled.

The complete scope and acceptance gates are in
[`../docs/STM32_FIRMWARE_PLAN.md`](../docs/STM32_FIRMWARE_PLAN.md). The wire
contract is documented in
[`../docs/STM32_PROTOCOL.md`](../docs/STM32_PROTOCOL.md). Mandatory first-contact
backup and restoration are recorded in
[`../docs/STM32_RECOVERY.md`](../docs/STM32_RECOVERY.md).

The portable C protocol source is intended to be compiled unchanged into both
the eventual controller image and the private PicoOS RP2350 driver. The host
model is the executable specification for fault-injection tests; it is shared
firmware logic, but it does not touch registers or prove physical behavior.

## Backlight board integration

`PicoCalcBacklights` owns TIM1 (PA8/channel 1) and TIM3 (PC8/channel 3, full
remap) exclusively. Do not also call stock backlight/analogWrite code or assign
those timers to another service. Construction has no hardware side effects;
the object must live for the lifetime of the firmware, and defaults to disabled.
After recovery gates pass, board integration can explicitly construct it with
output permission and forward `HardwareBindings.write_backlights` to `write()`.
The outer `HardwarePolicy.allow_backlights` must also be enabled. Calls belong
in the controller main loop, not I2C/interrupt callbacks.

Logical levels 0..255 map by rounded `level * 240 / 255`; zero is off, 255 is
the stock normal-adjustment ceiling, and both channels are independent. Status
currently reports model targets, not measured brightness. The driver checks
timer ownership, pin mapping, and PWM register acceptance; an off write checks
the pin reads low and its timer is stopped. This is not optical/current feedback.
Failure returns false for the pair, always attempts the other channel, and
allows the existing hardware boundary to retry without acknowledging shutdown.

The compile-only proof must not be flashed. It contains no keyboard, PMU,
charging, power-button or I2C integration. Physical brightness, current,
flicker, remapping, off/wake and fault acceptance remain pending on the Calc.
