#include <picoos/stm32/update_power.hpp>
namespace picoos::stm32::update {
bool RecoveryPower::modify(std::uint8_t reg, std::uint8_t clear, std::uint8_t set) {
    std::uint8_t value{}, check{};
    if (!io_.read(io_.context, reg, value)) return false;
    value = static_cast<std::uint8_t>((value & ~clear) | set);
    return io_.write(io_.context, reg, value) && io_.read(io_.context, reg, check) && check == value;
}
bool RecoveryPower::initialize() {
    healthy_ = false;
    if (shutdown_) return false;
    std::uint8_t id{};
    if (!io_.read || !io_.write || !io_.read(io_.context, 0x03, id) || id != 0x4A) return false;
    // Values traced to the pinned stock setup() and XPowersAXP2101 methods.
    if (!modify(0x24, 0x07, 0x02) || // system shutdown 2800 mV
        !modify(0x30, 0x02, 0x0D) || // no TS; battery/VBUS/system voltage ADC
        !modify(0x68, 0, 1) ||      // battery detection
        !modify(0x69, 0x06, 1) ||   // automatic charging indicator
        !modify(0x1A, 0xFF, 0x01) || // warning 5%, shutdown 1%
        !modify(0x40, 0, 0x40) || !modify(0x41, 0, 4)) return false;
    // Enable low-threshold and long-key events, preserving other enables.
    // Poll their status without an ISR, including while the app is absent.
    // Stock setup clears pre-startup key events. Do not interpret the press
    // that powered the board on as a fresh request to power it off. Preserve
    // the separate low-battery status so that safety event is still handled.
    std::uint8_t startup_key{};
    if (!io_.read(io_.context, 0x49, startup_key) ||
        ((startup_key & 4U) != 0 && !io_.write(io_.context, 0x49, 4))) return false;
    initialized_ = true;
    return poll(0);
}
bool RecoveryPower::poll(std::uint32_t now) {
    healthy_ = false;
    if (!initialized_) return false;
    if (shutdown_) {
        std::uint8_t config{};
        if (io_.read(io_.context, 0x10, config))
            (void)io_.write(io_.context, 0x10, static_cast<std::uint8_t>(config | 1U));
        return false;
    }
    std::uint8_t irq1{}, irq2{}, present{}, percent{};
    if (!io_.read(io_.context, 0x48, irq1) || !io_.read(io_.context, 0x49, irq2) ||
        !io_.read(io_.context, 0x00, present)) return false;
    const bool battery_present = (present & 8U) != 0;
    if (battery_present && (!io_.read(io_.context, 0xA4, percent) || percent > 100)) return false;
    if (now - sampled_ >= 20000U) {
        sampled_ = now;
        empty_samples_ = battery_present && percent == 0 ? empty_samples_ + 1 : 0;
    }
    // AXP2101 can retain the low-SOC latch with no battery installed (observed
    // on CPI2.0: STATUS1=0x20, INTSTS1=0x40). It is not a low battery in that
    // case. Acknowledge it below, while preserving unconditional long-key off.
    // Reset accumulated empty samples on removal, including between samples.
    if (!battery_present) empty_samples_ = 0;
    if ((battery_present && (irq1 & 0x40U) != 0) || (irq2 & 4U) != 0 || empty_samples_ >= 4) {
        // Same immediate low-threshold/long-key shutdown as stock. Latch before
        // the bus write: failure must never re-enable programming or booting.
        shutdown_ = true;
        std::uint8_t config{};
        if (io_.read(io_.context, 0x10, config))
            (void)io_.write(io_.context, 0x10, static_cast<std::uint8_t>(config | 1U));
        return false;
    }
    // Acknowledge observed flags only, not newly arriving bits.
    if ((irq1 && !io_.write(io_.context, 0x48, irq1)) ||
        (irq2 && !io_.write(io_.context, 0x49, irq2))) return false;
    healthy_ = true;
    return true;
}
}
