#include <picoos/stm32/client.hpp>

#include <array>
#include <cstring>

namespace picoos::stm32 {

ControllerClient::ControllerClient(const ClientIo io) : io_(io) {}

ClientResult ControllerClient::synchronize(const std::uint32_t session_nonce) {
    if (session_nonce == 0U) return ClientResult::invalid_argument;
    PicoOsStm32Frame request{};
    request.command = PICOOS_STM32_COMMAND_SESSION_SYNC;
    request.transaction = 0U;
    request.payload_size = 4U;
    picoos_stm32_write_u32_le(request.payload, session_nonce);
    PicoOsStm32Frame response{};
    PicoOsStm32Status remote_status{};
    const auto result = exchange_request(request, response, remote_status);
    if (result != ClientResult::ok) return result;
    if (response.payload_size != 5U ||
        picoos_stm32_read_u32_le(response.payload + 1U) != session_nonce) {
        ++diagnostics_.response_mismatches;
        return ClientResult::response_mismatch;
    }
    transaction_ = 0U;
    session_synchronized_ = true;
    ++diagnostics_.session_synchronizations;
    return ClientResult::ok;
}

ClientResult ControllerClient::transact(const std::uint8_t command,
                                        const std::uint8_t* payload,
                                        const std::uint8_t payload_size,
                                        PicoOsStm32Frame& response,
                                        PicoOsStm32Status& remote_status) {
    response = {};
    remote_status = PICOOS_STM32_STATUS_INTERNAL_ERROR;
    if (!session_synchronized_) return ClientResult::session_required;
    if (io_.exchange == nullptr ||
        payload_size > PICOOS_STM32_PAYLOAD_MAX_SIZE ||
        (payload_size != 0U && payload == nullptr)) {
        return ClientResult::invalid_argument;
    }

    PicoOsStm32Frame request{};
    request.command = command;
    request.transaction = next_transaction();
    request.payload_size = payload_size;
    if (payload_size != 0U) std::memcpy(request.payload, payload, payload_size);

    const auto result = exchange_request(request, response, remote_status);
    if (result == ClientResult::ok) ++diagnostics_.successful_transactions;
    return result;
}

ClientResult ControllerClient::exchange_request(
    const PicoOsStm32Frame& request, PicoOsStm32Frame& response,
    PicoOsStm32Status& remote_status) {
    response = {};
    remote_status = PICOOS_STM32_STATUS_INTERNAL_ERROR;
    if (io_.exchange == nullptr) return ClientResult::invalid_argument;

    std::array<std::uint8_t, PICOOS_STM32_FRAME_MAX_SIZE> request_bytes{};
    std::array<std::uint8_t, PICOOS_STM32_FRAME_MAX_SIZE> response_bytes{};
    std::size_t request_size{};
    if (picoos_stm32_frame_encode(&request, request_bytes.data(),
                                  request_bytes.size(), &request_size) !=
        PICOOS_STM32_CODEC_OK) {
        ++diagnostics_.codec_errors;
        return ClientResult::codec_error;
    }

    bool exchanged = false;
    for (std::uint8_t attempt = 0U; attempt < 2U; ++attempt) {
        response_bytes = {};
        if (io_.exchange(io_.context, request_bytes.data(), request_size,
                         response_bytes.data(), response_bytes.size())) {
            exchanged = true;
            break;
        }
        ++diagnostics_.io_errors;
        if (attempt == 0U) ++diagnostics_.retries;
    }
    if (!exchanged) return ClientResult::io_error;

    if (picoos_stm32_frame_decode(response_bytes.data(), response_bytes.size(),
                                  &response) != PICOOS_STM32_CODEC_OK) {
        ++diagnostics_.codec_errors;
        return ClientResult::codec_error;
    }
    if (response.command != request.command ||
        response.transaction != request.transaction ||
        (response.flags & PICOOS_STM32_FRAME_RESPONSE) == 0U ||
        response.payload_size == 0U) {
        ++diagnostics_.response_mismatches;
        return ClientResult::response_mismatch;
    }
    remote_status = static_cast<PicoOsStm32Status>(response.payload[0]);
    if ((response.flags & PICOOS_STM32_FRAME_ERROR) != 0U ||
        remote_status != PICOOS_STM32_STATUS_OK) {
        ++diagnostics_.remote_errors;
        return ClientResult::remote_error;
    }
    return ClientResult::ok;
}

const ClientDiagnostics& ControllerClient::diagnostics() const {
    return diagnostics_;
}

std::uint16_t ControllerClient::next_transaction() {
    ++transaction_;
    if (transaction_ == 0U) ++transaction_;
    return transaction_;
}

}  // namespace picoos::stm32
