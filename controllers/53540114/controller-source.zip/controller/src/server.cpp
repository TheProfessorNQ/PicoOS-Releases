#include <picoos/stm32/server.hpp>

#include <algorithm>
#include <array>
#include <cstring>

namespace picoos::stm32 {
namespace {

constexpr std::uint8_t snapshot_page_bytes = 10U;
constexpr std::uint8_t snapshot_page_count = 2U;
constexpr std::uint8_t diagnostics_page_count = 2U;
constexpr std::uint8_t telemetry_page_count = 2U;

void write_status(PicoOsStm32Frame& response, const PicoOsStm32Status status) {
    response.payload[0] = static_cast<std::uint8_t>(status);
}

}  // namespace

ControllerServer::ControllerServer(const ControllerProfile profile,
                                   const std::uint32_t build_identity)
    : profile_(profile), build_identity_(build_identity) {}

PicoOsStm32Status ControllerServer::handle(const PicoOsStm32Frame& request,
                                           const std::uint64_t now_milliseconds,
                                           PicoOsStm32Frame& response) {
    begin_response(request, response);
    if (request.flags != 0U) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    if (!command_allowed(request.command)) {
        return finish(response, PICOOS_STM32_STATUS_UNSUPPORTED, 1U);
    }
    switch (request.command) {
        case PICOOS_STM32_COMMAND_IDENTIFY:
            if (request.payload_size != 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            return identify(response);
        case PICOOS_STM32_COMMAND_POWER_REQUEST:
            if (request.payload_size != 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            picoos_stm32_write_u32_le(response.payload + 1U, power_requests_);
            return finish(response, PICOOS_STM32_STATUS_OK, 5U);
        case PICOOS_STM32_COMMAND_STATUS:
            if (request.payload_size != 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            return status(response);
        case PICOOS_STM32_COMMAND_SESSION_SYNC:
            if (request.transaction != 0U || request.payload_size != 4U ||
                picoos_stm32_read_u32_le(request.payload) == 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            std::copy_n(request.payload, 4U, response.payload + 1U);
            return finish(response, PICOOS_STM32_STATUS_OK, 5U);
        case PICOOS_STM32_COMMAND_KEY_NEXT:
            if (request.payload_size != 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            return key_next(response);
        case PICOOS_STM32_COMMAND_KEY_SNAPSHOT:
            return key_snapshot(request, response);
        case PICOOS_STM32_COMMAND_RTC_READ:
            if (request.payload_size != 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            return rtc_read(now_milliseconds, response);
        case PICOOS_STM32_COMMAND_RTC_SET:
            if (request.payload_size != 8U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            if (hardware_rtc_) return finish(response, hardware_rtc_->request(true,
                picoos_stm32_read_u64_le(request.payload)), 1U);
            model_.rtc().set(picoos_stm32_read_u64_le(request.payload), now_milliseconds);
            return finish(response, PICOOS_STM32_STATUS_OK, 1U);
        case PICOOS_STM32_COMMAND_RTC_INVALIDATE:
            if (request.payload_size != 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            if (hardware_rtc_) return finish(response, hardware_rtc_->request(false), 1U);
            model_.rtc().invalidate();
            return finish(response, PICOOS_STM32_STATUS_OK, 1U);
        case PICOOS_STM32_COMMAND_POWER_PREPARE: {
            if (request.payload_size != 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            const auto token = model_.power().prepare_soft_off(now_milliseconds);
            if (!token.has_value())
                return finish(response, PICOOS_STM32_STATUS_INVALID_STATE, 1U);
            picoos_stm32_write_u32_le(response.payload + 1U, token.value());
            picoos_stm32_write_u16_le(
                response.payload + 5U,
                static_cast<std::uint16_t>(PowerController::prepare_timeout_milliseconds));
            return finish(response, PICOOS_STM32_STATUS_OK, 7U);
        }
        case PICOOS_STM32_COMMAND_POWER_COMMIT:
            if (request.payload_size != 4U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            return finish(response,
                          model_.commit_soft_off(
                              picoos_stm32_read_u32_le(request.payload), now_milliseconds)
                              ? PICOOS_STM32_STATUS_OK
                              : PICOOS_STM32_STATUS_STALE_TOKEN,
                          1U);
        case PICOOS_STM32_COMMAND_POWER_CANCEL:
            if (request.payload_size != 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            return finish(response,
                          model_.power().cancel_soft_off()
                              ? PICOOS_STM32_STATUS_OK
                              : PICOOS_STM32_STATUS_INVALID_STATE,
                          1U);
        case PICOOS_STM32_COMMAND_HEARTBEAT:
            if (request.payload_size != 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            model_.power().heartbeat(now_milliseconds);
            return finish(response, PICOOS_STM32_STATUS_OK, 1U);
        case PICOOS_STM32_COMMAND_BACKLIGHT_SET:
            if (request.payload_size != 2U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            model_.power().set_backlights(request.payload[0], request.payload[1]);
            return finish(response, PICOOS_STM32_STATUS_OK, 1U);
        case PICOOS_STM32_COMMAND_HEADPHONE_READ:
            if (request.payload_size != 0U)
                return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
            response.payload[1] = model_.headphone().initialized() ? 1U : 0U;
            response.payload[2] = model_.headphone().inserted() ? 1U : 0U;
            picoos_stm32_write_u32_le(response.payload + 3U,
                                      model_.headphone().edge_count());
            return finish(response, PICOOS_STM32_STATUS_OK, 7U);
        case PICOOS_STM32_COMMAND_DIAGNOSTICS_READ:
            return diagnostics(request, response);
        case PICOOS_STM32_COMMAND_TELEMETRY_READ:
            return telemetry(request, response);
        case PICOOS_STM32_COMMAND_GPIO_DESCRIBE:
            return gpio_describe(request, response);
        case PICOOS_STM32_COMMAND_GPIO_CONFIGURE:
            return gpio_configure(request, response);
        case PICOOS_STM32_COMMAND_GPIO_READ:
            return gpio_read(request, response);
        case PICOOS_STM32_COMMAND_GPIO_WRITE:
            return gpio_write(request, response);
        case PICOOS_STM32_COMMAND_GPIO_EDGES:
            return gpio_edges(request, response);
        default:
            return finish(response, PICOOS_STM32_STATUS_INVALID_COMMAND, 1U);
    }
}

ControllerModel& ControllerServer::model() {
    return model_;
}

const ControllerModel& ControllerServer::model() const {
    return model_;
}

bool ControllerServer::command_allowed(const std::uint8_t command) const {
    if (profile_ == ControllerProfile::full) return true;
    if (hardware_power_ && (command == PICOOS_STM32_COMMAND_POWER_PREPARE ||
        command == PICOOS_STM32_COMMAND_POWER_COMMIT || command == PICOOS_STM32_COMMAND_POWER_CANCEL)) return true;
    if (hardware_rtc_ && (command == PICOOS_STM32_COMMAND_RTC_READ ||
        command == PICOOS_STM32_COMMAND_RTC_SET || command == PICOOS_STM32_COMMAND_RTC_INVALIDATE)) return true;
    return command == PICOOS_STM32_COMMAND_POWER_REQUEST ||
           command == PICOOS_STM32_COMMAND_IDENTIFY ||
           command == PICOOS_STM32_COMMAND_STATUS ||
           command == PICOOS_STM32_COMMAND_SESSION_SYNC ||
           command == PICOOS_STM32_COMMAND_KEY_NEXT ||
           command == PICOOS_STM32_COMMAND_KEY_SNAPSHOT ||
           command == PICOOS_STM32_COMMAND_DIAGNOSTICS_READ;
}

void ControllerServer::begin_response(const PicoOsStm32Frame& request,
                                      PicoOsStm32Frame& response) {
    response = {};
    response.command = request.command;
    response.transaction = request.transaction;
    response.flags = PICOOS_STM32_FRAME_RESPONSE;
}

PicoOsStm32Status ControllerServer::finish(PicoOsStm32Frame& response,
                                           const PicoOsStm32Status status,
                                           const std::uint8_t payload_size) {
    write_status(response, status);
    response.payload_size = payload_size;
    if (status != PICOOS_STM32_STATUS_OK) {
        response.flags = static_cast<std::uint8_t>(response.flags |
                                                   PICOOS_STM32_FRAME_ERROR);
        response.payload_size = 1U;
    }
    return status;
}

PicoOsStm32Status ControllerServer::identify(PicoOsStm32Frame& response) const {
    response.payload[1] = PICOOS_STM32_PROTOCOL_MINOR;
    response.payload[2] = firmware_major;
    response.payload[3] = firmware_minor;
    response.payload[4] = firmware_patch;
    response.payload[5] = 14U;
    std::uint32_t advertised = profile_ == ControllerProfile::diagnostic
                                   ? diagnostic_capabilities
                                   : base_capabilities;
    if (profile_ == ControllerProfile::full && model_.gpio().size() != 0U) {
        advertised |= PICOOS_STM32_CAPABILITY_GPIO;
    }
    if (hardware_rtc_) advertised |= PICOOS_STM32_CAPABILITY_RTC;
    if (hardware_power_) advertised |= PICOOS_STM32_CAPABILITY_SOFT_OFF;
    if (suspend_ui_) advertised |= PICOOS_STM32_CAPABILITY_SUSPEND_UI;
    picoos_stm32_write_u32_le(response.payload + 6U, advertised);
    picoos_stm32_write_u32_le(response.payload + 10U, build_identity_);
    return finish(response, PICOOS_STM32_STATUS_OK, 14U);
}

PicoOsStm32Status ControllerServer::status(PicoOsStm32Frame& response) const {
    const auto snapshot = model_.keyboard().snapshot();
    const auto backlights = model_.power().backlights();
    std::uint8_t flags{};
    if (model_.power().pico_powered()) flags = static_cast<std::uint8_t>(flags | 1U);
    if (hardware_rtc_ ? (hardware_rtc_->snapshot().valid && !hardware_rtc_->snapshot().pending)
                      : model_.rtc().valid()) flags = static_cast<std::uint8_t>(flags | 2U);
    if (model_.headphone().initialized()) flags = static_cast<std::uint8_t>(flags | 4U);
    if (model_.headphone().inserted()) flags = static_cast<std::uint8_t>(flags | 8U);
    if (snapshot.overflow_count != 0U) flags = static_cast<std::uint8_t>(flags | 16U);
    if (model_.keyboard().caps_lock()) flags = static_cast<std::uint8_t>(flags | 32U);
    response.payload[1] = 16U;
    response.payload[2] = static_cast<std::uint8_t>(model_.power().state());
    response.payload[3] = static_cast<std::uint8_t>(model_.power().last_reason());
    response.payload[4] = flags;
    response.payload[5] = static_cast<std::uint8_t>(model_.keyboard().size());
    response.payload[6] = backlights.lcd;
    response.payload[7] = backlights.keyboard;
    picoos_stm32_write_u32_le(response.payload + 8U, snapshot.next_sequence);
    picoos_stm32_write_u32_le(response.payload + 12U, snapshot.overflow_count);
    return finish(response, PICOOS_STM32_STATUS_OK, 16U);
}

PicoOsStm32Status ControllerServer::key_next(PicoOsStm32Frame& response) {
    const auto event = model_.keyboard().pop();
    response.payload[1] = event.has_value() ? 1U : 0U;
    if (!event.has_value()) return finish(response, PICOOS_STM32_STATUS_OK, 2U);
    picoos_stm32_write_u32_le(response.payload + 2U, event->sequence);
    picoos_stm32_write_u32_le(response.payload + 6U, event->timestamp_milliseconds);
    response.payload[10] = event->key_id;
    response.payload[11] = static_cast<std::uint8_t>(event->transition);
    response.payload[12] = event->modifiers;
    return finish(response, PICOOS_STM32_STATUS_OK, 13U);
}

PicoOsStm32Status ControllerServer::key_snapshot(
    const PicoOsStm32Frame& request, PicoOsStm32Frame& response) const {
    if (request.payload_size != 1U || request.payload[0] >= snapshot_page_count) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    const auto snapshot = model_.keyboard().snapshot();
    const std::uint8_t page = request.payload[0];
    const std::size_t offset = static_cast<std::size_t>(page) * snapshot_page_bytes;
    const std::size_t remaining = snapshot.held.size() - offset;
    const std::uint8_t amount = static_cast<std::uint8_t>(
        std::min<std::size_t>(snapshot_page_bytes, remaining));
    response.payload[1] = page;
    response.payload[2] = snapshot_page_count;
    response.payload[3] = amount;
    picoos_stm32_write_u32_le(response.payload + 4U, snapshot.next_sequence);
    picoos_stm32_write_u32_le(response.payload + 8U, snapshot.overflow_count);
    std::memcpy(response.payload + 12U, snapshot.held.data() + offset, amount);
    return finish(response, PICOOS_STM32_STATUS_OK,
                  static_cast<std::uint8_t>(12U + amount));
}

PicoOsStm32Status ControllerServer::rtc_read(
    const std::uint64_t now_milliseconds, PicoOsStm32Frame& response) const {
    if (hardware_rtc_) {
        const auto value = hardware_rtc_->snapshot();
        response.payload[1] = value.valid && !value.pending ? 1U : 0U;
        response.payload[2] = value.oscillator;
        response.payload[3] = value.pending ? 1U : 0U;
        picoos_stm32_write_u64_le(response.payload + 4U, response.payload[1] ? value.seconds : 0U);
        return finish(response, PICOOS_STM32_STATUS_OK, 12U);
    }
    const auto time = model_.rtc().read(now_milliseconds);
    response.payload[1] = time.has_value() ? 1U : 0U;
    response.payload[2] = 1U;
    response.payload[3] = 0U;
    picoos_stm32_write_u64_le(response.payload + 4U, time.value_or(0U));
    return finish(response, PICOOS_STM32_STATUS_OK, 12U);
}

PicoOsStm32Status ControllerServer::diagnostics(
    const PicoOsStm32Frame& request, PicoOsStm32Frame& response) const {
    if (request.payload_size != 1U || request.payload[0] >= diagnostics_page_count) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    const auto& power = model_.power().diagnostics();
    const auto snapshot = model_.keyboard().snapshot();
    const std::array<std::uint32_t, 8> counters{
        power.stale_token_count,
        power.prepare_timeout_count,
        power.heartbeat_timeout_count,
        power.soft_off_count,
        power.wake_count,
        power.hard_off_count,
        snapshot.overflow_count,
        model_.headphone().edge_count(),
    };
    const std::uint8_t page = request.payload[0];
    response.payload[1] = page;
    response.payload[2] = diagnostics_page_count;
    response.payload[3] = 4U;
    const std::size_t offset = static_cast<std::size_t>(page) * 4U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        picoos_stm32_write_u32_le(response.payload + 4U + index * 4U,
                                  counters[offset + index]);
    }
    return finish(response, PICOOS_STM32_STATUS_OK, 20U);
}

PicoOsStm32Status ControllerServer::telemetry(
    const PicoOsStm32Frame& request, PicoOsStm32Frame& response) const {
    if (request.payload_size != 1U || request.payload[0] >= telemetry_page_count) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    if (!model_.telemetry().initialized()) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_STATE, 1U);
    }
    const auto& snapshot = model_.telemetry().snapshot();
    const auto& sample = snapshot.sample;
    const std::uint8_t page = request.payload[0];
    response.payload[1] = page;
    response.payload[2] = telemetry_page_count;
    response.payload[3] = 1U;
    picoos_stm32_write_u32_le(response.payload + 4U, snapshot.generation);
    if (page == 0U) {
        picoos_stm32_write_u32_le(response.payload + 8U,
                                  snapshot.captured_milliseconds);
        picoos_stm32_write_u16_le(response.payload + 12U, sample.validity);
        response.payload[14] = sample.state_flags;
        response.payload[15] = sample.battery_percent;
        response.payload[16] = static_cast<std::uint8_t>(sample.charger_state);
        picoos_stm32_write_u16_le(response.payload + 17U,
                                  sample.battery_millivolts);
        picoos_stm32_write_u16_le(response.payload + 19U,
                                  sample.vbus_millivolts);
        return finish(response, PICOOS_STM32_STATUS_OK, 21U);
    }
    picoos_stm32_write_u16_le(response.payload + 8U, sample.system_millivolts);
    picoos_stm32_write_u16_le(
        response.payload + 10U,
        static_cast<std::uint16_t>(sample.battery_milliamps));
    picoos_stm32_write_u32_le(response.payload + 12U, sample.fault_flags);
    picoos_stm32_write_u32_le(response.payload + 16U, sample.last_irq_flags);
    response.payload[20] = sample.warning_threshold_percent;
    response.payload[21] = sample.shutdown_threshold_percent;
    return finish(response, PICOOS_STM32_STATUS_OK, 22U);
}

PicoOsStm32Status ControllerServer::gpio_describe(
    const PicoOsStm32Frame& request, PicoOsStm32Frame& response) const {
    if (model_.gpio().size() == 0U) {
        return finish(response, PICOOS_STM32_STATUS_UNSUPPORTED, 1U);
    }
    if (request.payload_size != 1U) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    const auto* channel = model_.gpio().at(request.payload[0]);
    if (channel == nullptr) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    response.payload[1] = request.payload[0];
    response.payload[2] = static_cast<std::uint8_t>(model_.gpio().size());
    response.payload[3] = channel->descriptor.logical_id;
    response.payload[4] = channel->descriptor.capabilities;
    response.payload[5] = channel->descriptor.safe_value ? 1U : 0U;
    response.payload[6] = channel->configured ? 1U : 0U;
    response.payload[7] = static_cast<std::uint8_t>(channel->direction);
    response.payload[8] = static_cast<std::uint8_t>(channel->pull);
    response.payload[9] = channel->value ? 1U : 0U;
    response.payload[10] = channel->edges;
    return finish(response, PICOOS_STM32_STATUS_OK, 11U);
}

PicoOsStm32Status ControllerServer::gpio_configure(
    const PicoOsStm32Frame& request, PicoOsStm32Frame& response) {
    if (model_.gpio().size() == 0U) {
        return finish(response, PICOOS_STM32_STATUS_UNSUPPORTED, 1U);
    }
    if (request.payload_size != 3U ||
        request.payload[1] > static_cast<std::uint8_t>(GpioDirection::output) ||
        request.payload[2] > static_cast<std::uint8_t>(GpioPull::down)) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    const auto direction = static_cast<GpioDirection>(request.payload[1]);
    const auto pull = static_cast<GpioPull>(request.payload[2]);
    return finish(response,
                  model_.gpio().configure(request.payload[0], direction, pull)
                      ? PICOOS_STM32_STATUS_OK
                      : PICOOS_STM32_STATUS_INVALID_ARGUMENT,
                  1U);
}

PicoOsStm32Status ControllerServer::gpio_read(
    const PicoOsStm32Frame& request, PicoOsStm32Frame& response) const {
    if (model_.gpio().size() == 0U) {
        return finish(response, PICOOS_STM32_STATUS_UNSUPPORTED, 1U);
    }
    if (request.payload_size != 1U) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    const auto* channel = model_.gpio().find(request.payload[0]);
    if (channel == nullptr) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    const auto value = model_.gpio().read(request.payload[0]);
    if (!value.has_value()) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_STATE, 1U);
    }
    response.payload[1] = request.payload[0];
    response.payload[2] = value.value() ? 1U : 0U;
    response.payload[3] = static_cast<std::uint8_t>(channel->direction);
    return finish(response, PICOOS_STM32_STATUS_OK, 4U);
}

PicoOsStm32Status ControllerServer::gpio_write(
    const PicoOsStm32Frame& request, PicoOsStm32Frame& response) {
    if (model_.gpio().size() == 0U) {
        return finish(response, PICOOS_STM32_STATUS_UNSUPPORTED, 1U);
    }
    if (request.payload_size != 2U || request.payload[1] > 1U) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    if (model_.gpio().find(request.payload[0]) == nullptr) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    return finish(response,
                  model_.gpio().write(request.payload[0], request.payload[1] != 0U)
                      ? PICOOS_STM32_STATUS_OK
                      : PICOOS_STM32_STATUS_INVALID_STATE,
                  1U);
}

PicoOsStm32Status ControllerServer::gpio_edges(
    const PicoOsStm32Frame& request, PicoOsStm32Frame& response) {
    if (model_.gpio().size() == 0U) {
        return finish(response, PICOOS_STM32_STATUS_UNSUPPORTED, 1U);
    }
    if (request.payload_size != 2U ||
        (request.payload[1] &
         static_cast<std::uint8_t>(~(gpio_edge_rising | gpio_edge_falling))) != 0U) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    if (model_.gpio().find(request.payload[0]) == nullptr) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_ARGUMENT, 1U);
    }
    const auto edges = model_.gpio().edges(request.payload[0], request.payload[1]);
    if (!edges.has_value()) {
        return finish(response, PICOOS_STM32_STATUS_INVALID_STATE, 1U);
    }
    response.payload[1] = request.payload[0];
    response.payload[2] = edges.value();
    return finish(response, PICOOS_STM32_STATUS_OK, 3U);
}

}  // namespace picoos::stm32
