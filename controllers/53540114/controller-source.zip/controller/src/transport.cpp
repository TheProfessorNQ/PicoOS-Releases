#include <picoos/stm32/transport.hpp>

#include <algorithm>
#include <cstring>

namespace picoos::stm32 {

TransportEndpoint::TransportEndpoint(const ControllerProfile profile,
                                     const std::uint32_t build_identity)
    : server_(profile, build_identity) {}

PicoOsStm32CodecResult TransportEndpoint::receive(
    const std::uint8_t* bytes, const std::size_t size,
    const std::uint64_t now_milliseconds) {
    PicoOsStm32Frame request{};
    const auto decoded = picoos_stm32_frame_decode(bytes, size, &request);
    if (decoded != PICOOS_STM32_CODEC_OK) {
        ++diagnostics_.malformed_frames;
        const std::uint8_t command = bytes != nullptr && size > 3U ? bytes[3] : 0U;
        const std::uint16_t transaction =
            bytes != nullptr && size > 5U ? picoos_stm32_read_u16_le(bytes + 4U) : 0U;
        encode_error(command, transaction, PICOOS_STM32_STATUS_INTEGRITY);
        return decoded;
    }

    if (request.command == PICOOS_STM32_COMMAND_SESSION_SYNC) {
        if (request.transaction != 0U || request.payload_size != 4U ||
            picoos_stm32_read_u32_le(request.payload) == 0U) {
            ++diagnostics_.rejected_commands;
            encode_error(request.command, request.transaction,
                         PICOOS_STM32_STATUS_INVALID_ARGUMENT);
            return PICOOS_STM32_CODEC_OK;
        }
        reset_transport();
        PicoOsStm32Frame response{};
        const auto status = server_.handle(request, now_milliseconds, response);
        if (status != PICOOS_STM32_STATUS_OK) ++diagnostics_.rejected_commands;
        encode_response(response);
        ++diagnostics_.session_resynchronizations;
        return response_size_ == 0U ? PICOOS_STM32_CODEC_NO_SPACE
                                    : PICOOS_STM32_CODEC_OK;
    }
    if (request.transaction == 0U) {
        ++diagnostics_.rejected_commands;
        encode_error(request.command, request.transaction,
                     PICOOS_STM32_STATUS_INVALID_ARGUMENT);
        return PICOOS_STM32_CODEC_OK;
    }

    if (transaction_valid_ && request.transaction == transaction_) {
        if (size == request_size_ &&
            std::memcmp(bytes, request_.data(), request_size_) == 0) {
            ++diagnostics_.duplicate_transactions;
            response_ = replay_response_;
            response_size_ = replay_response_size_;
            return PICOOS_STM32_CODEC_OK;
        }
        ++diagnostics_.reused_transaction_ids;
        ++diagnostics_.rejected_commands;
        encode_error(request.command, request.transaction,
                     PICOOS_STM32_STATUS_INVALID_ARGUMENT);
        return PICOOS_STM32_CODEC_OK;
    }

    PicoOsStm32Frame response{};
    const auto status = server_.handle(request, now_milliseconds, response);
    if (status != PICOOS_STM32_STATUS_OK) ++diagnostics_.rejected_commands;
    encode_response(response);
    if (response_size_ == 0U) return PICOOS_STM32_CODEC_NO_SPACE;

    std::copy_n(bytes, size, request_.begin());
    request_size_ = size;
    transaction_ = request.transaction;
    transaction_valid_ = true;
    replay_response_ = response_;
    replay_response_size_ = response_size_;
    return PICOOS_STM32_CODEC_OK;
}

const std::uint8_t* TransportEndpoint::response_data() const {
    return response_.data();
}

std::size_t TransportEndpoint::response_size() const {
    return response_size_;
}

ControllerServer& TransportEndpoint::server() {
    return server_;
}

const ControllerServer& TransportEndpoint::server() const {
    return server_;
}

const TransportDiagnostics& TransportEndpoint::diagnostics() const {
    return diagnostics_;
}

void TransportEndpoint::reset_transport() {
    request_ = {};
    response_ = {};
    replay_response_ = {};
    replay_response_size_ = 0U;
    request_size_ = 0U;
    response_size_ = 0U;
    transaction_ = 0U;
    transaction_valid_ = false;
}

void TransportEndpoint::note_bus_recovery() {
    ++diagnostics_.bus_recoveries;
    reset_transport();
}

void TransportEndpoint::encode_error(const std::uint8_t command,
                                     const std::uint16_t transaction,
                                     const PicoOsStm32Status status) {
    PicoOsStm32Frame response{};
    response.command = command;
    response.transaction = transaction;
    response.flags = static_cast<std::uint8_t>(PICOOS_STM32_FRAME_RESPONSE |
                                               PICOOS_STM32_FRAME_ERROR);
    response.payload_size = 1U;
    response.payload[0] = static_cast<std::uint8_t>(status);
    encode_response(response);
}

void TransportEndpoint::encode_response(const PicoOsStm32Frame& response) {
    response_size_ = 0U;
    if (picoos_stm32_frame_encode(&response, response_.data(), response_.size(),
                                  &response_size_) != PICOOS_STM32_CODEC_OK) {
        response_size_ = 0U;
        ++diagnostics_.response_encode_failures;
    }
}

}  // namespace picoos::stm32
