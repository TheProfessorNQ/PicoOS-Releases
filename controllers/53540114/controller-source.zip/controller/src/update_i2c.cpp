#include <picoos/stm32/update_i2c.hpp>
namespace picoos::stm32::update {
void I2cReceiver::discard() {
    received_ = sent_ = 0; receiving_ = transmitting_ = overflow_ = false;
    for (auto& byte : reply_) byte = 0xFF; // never replay an old successful command
}
bool I2cReceiver::initialize_8mhz() {
    if (!io_.read || !io_.write || !io_.lines_idle) return false;
    discard();
    io_.write(io_.context, I2cRegister::cr1, 0x8000U);
    io_.write(io_.context, I2cRegister::cr1, 0);
    io_.write(io_.context, I2cRegister::cr2, 8U); // PCLK1=8 MHz, interrupts/DMA off
    io_.write(io_.context, I2cRegister::oar1, 0x4000U | (0x1FU << 1U));
    io_.write(io_.context, I2cRegister::ccr, 40U);
    io_.write(io_.context, I2cRegister::trise, 9U);
    io_.write(io_.context, I2cRegister::cr1, 0x401U); // PE, ACK; clock stretching enabled
    initialized_ = true; return true;
}
void I2cReceiver::drain_received() {
    // Both data-register and shift-register bytes may precede STOPF.
    for (unsigned n = 0; n < 2; ++n) {
        if ((io_.read(io_.context, I2cRegister::sr1) & 0x40U) == 0) break;
        const auto value = static_cast<std::uint8_t>(io_.read(io_.context, I2cRegister::dr));
        if (receiving_ && received_ < packet_bytes) request_[received_++] = value;
        else overflow_ = true;
    }
}
void I2cReceiver::finish_received() {
    // SR1 then CR1 clears STOPF, leaving a later ADDR pending and stretched.
    if ((io_.read(io_.context, I2cRegister::sr1) & 0x40U) != 0) overflow_ = true;
    io_.write(io_.context, I2cRegister::cr1, 0x401U);
    const bool complete = receiving_ && !overflow_ && received_ == packet_bytes;
    const bool identity = receiving_ && !overflow_ && received_ == 1 && request_[0] == 0x0FU;
    receiving_ = transmitting_ = false;
    if (complete) (void)exchange(receiver_, request_, packet_bytes, reply_);
    else if (identity) {
        for (auto& byte : reply_) byte = 0;
        reply_[0] = 'P'; reply_[1] = 'U'; reply_[2] = 1; reply_[3] = 1;
        write32(reply_ + 4, 0x50550101U); write32(reply_ + 8, layout_id);
    }
    received_ = 0;
}
void I2cReceiver::poll() {
    if (!initialized_) return;
    auto flags = io_.read(io_.context, I2cRegister::sr1);
    if ((flags & 0xDB00U) != 0) { // bus/arbitration/overrun/PEC/timeout/SMBus errors, not AF
        initialize_8mhz(); return;
    }
    if ((flags & 0x400U) != 0) {
        io_.write(io_.context, I2cRegister::sr1, flags & ~0x400U);
        transmitting_ = false;
    }
    // A STOP followed by another address may accumulate while servicing PMU
    // or flash. Finish the OLD write before acknowledging the NEW address.
    // Handling ADDR first discards the request and STOP then clears the new
    // transmitter state, leaving the master's read clock-stretched forever.
    if ((flags & 0x10U) != 0) {
        drain_received();
        finish_received();
        return;
    }
    if ((flags & 2U) != 0) {
        const auto direction = io_.read(io_.context, I2cRegister::sr2); // clears ADDR after SR1
        if ((direction & 4U) != 0) {
            if (receiving_) discard(); // repeated-start write/read is not admitted
            transmitting_ = true; sent_ = 0;
        } else {
            discard(); receiving_ = true;
        }
    }
    drain_received();
    flags = io_.read(io_.context, I2cRegister::sr1);
    if ((flags & 0x10U) != 0) {
        finish_received();
    } else if (transmitting_ && (flags & 0x80U) != 0) {
        io_.write(io_.context, I2cRegister::dr, sent_ < packet_bytes ? reply_[sent_++] : 0xFFU);
    }
}
bool I2cReceiver::idle() {
    // SR2 is not a harmless BUSY query: following a poll's SR1 read it can
    // consume a newly arriving ADDR. Only poll's ADDR handler may read SR2.
    // Check pending events plus the physical lines without acknowledging them.
    // A START arriving after this sample may be retried by the host across boot;
    // an addressed/in-progress transfer must finish before flash work/handoff.
    return initialized_ && !receiving_ && !transmitting_ &&
        (io_.read(io_.context, I2cRegister::sr1) & 0x56U) == 0 && io_.lines_idle(io_.context);
}
}
