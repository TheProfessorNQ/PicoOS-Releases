#include <picoos/stm32/update_flash.hpp>

namespace picoos::stm32::update {
namespace {
constexpr std::uint32_t busy = 1, errors = 0x14, eop = 0x20, lock = 0x80;
}
bool F103Flash::ready() {
    if (!admitted_ || !io_.read_register || !io_.write_register || !io_.ticks ||
        io_.deadline_ticks == 0 || io_.deadline_ticks > 0x7FFFFFFFU) return false;
    const auto start = io_.ticks(io_.context);
    for (unsigned spin = 0; spin < 1000000U; ++spin) {
        if ((io_.read_register(io_.context, FlashRegister::status) & busy) == 0) return true;
        if (io_.ticks(io_.context) - start >= io_.deadline_ticks) break;
    }
    admitted_ = false; // uncertain busy controller requires reset, never another erase
    return false;
}
bool F103Flash::unlock() {
    if (!ready()) return false;
    if ((io_.read_register(io_.context, FlashRegister::control) & ~lock) != 0) return false;
    if ((io_.read_register(io_.context, FlashRegister::control) & lock) != 0) {
        io_.write_register(io_.context, FlashRegister::key, 0x45670123U);
        io_.write_register(io_.context, FlashRegister::key, 0xCDEF89ABU);
    }
    if (io_.read_register(io_.context, FlashRegister::control) != 0) return false;
    io_.write_register(io_.context, FlashRegister::status, errors | eop);
    return true;
}
bool F103Flash::finish() {
    if (!ready()) return false; // do not alter CR while BSY remains set
    const auto status = io_.read_register(io_.context, FlashRegister::status);
    io_.write_register(io_.context, FlashRegister::control, lock);
    io_.write_register(io_.context, FlashRegister::status, errors | eop);
    return (status & errors) == 0 && (status & eop) != 0;
}
bool F103Flash::read(void* context, std::uint32_t address, std::uint8_t* bytes, std::size_t count) {
    auto& self = *static_cast<F103Flash*>(context);
    if (!self.admitted_ || !self.io_.read_memory || !bytes || address < app_base ||
        address > flash_base + 65536U || count > flash_base + 65536U - address) return false;
    return self.io_.read_memory(self.io_.context, address, bytes, count);
}
bool F103Flash::erase(void* context, std::uint32_t address) {
    auto& self = *static_cast<F103Flash*>(context);
    if (address < app_base || address > manifest_base || address % page_bytes != 0 || !self.unlock()) return false;
    self.io_.write_register(self.io_.context, FlashRegister::control, 2U);
    self.io_.write_register(self.io_.context, FlashRegister::address, address);
    self.io_.write_register(self.io_.context, FlashRegister::control, 2U | 0x40U);
    return self.finish();
}
bool F103Flash::program(void* context, std::uint32_t address, std::uint16_t value) {
    auto& self = *static_cast<F103Flash*>(context);
    if (address < app_base || address >= manifest_base + 32U || (address & 1U) != 0 ||
        !self.io_.write_halfword || !self.unlock()) return false;
    self.io_.write_register(self.io_.context, FlashRegister::control, 1U);
    self.io_.write_halfword(self.io_.context, address, value);
    return self.finish();
}
} // namespace picoos::stm32::update
