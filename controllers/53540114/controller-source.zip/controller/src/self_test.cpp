#include <picoos/stm32/client.hpp>
#include <picoos/stm32/diagnostic.hpp>
#include <picoos/stm32/hardware.hpp>
#include <picoos/stm32/self_test.hpp>
#include <picoos/stm32/transport.hpp>

#include <algorithm>
#include <array>
#include <cstring>

namespace picoos::stm32 {
namespace {

void record(SelfTestReport& report, const std::uint32_t bit,
            const bool condition) {
    if (condition)
        report.passed |= bit;
    else
        report.failed |= bit;
}

bool encode(const PicoOsStm32Frame& frame,
            std::array<std::uint8_t, PICOOS_STM32_FRAME_MAX_SIZE>& bytes,
            std::size_t& size) {
    bytes = {};
    return picoos_stm32_frame_encode(&frame, bytes.data(), bytes.size(), &size) ==
           PICOOS_STM32_CODEC_OK;
}

struct Loopback {
    TransportEndpoint endpoint{};
    std::uint64_t now{};
    bool lose_response{true};
};

struct InertHardware {
    std::uint64_t now{};
};

bool read_milliseconds(void* context, std::uint64_t& value) {
    value = static_cast<InertHardware*>(context)->now;
    return true;
}

bool exchange(void* context, const std::uint8_t* request,
              const std::size_t request_size, std::uint8_t* response,
              const std::size_t response_size) {
    auto& loopback = *static_cast<Loopback*>(context);
    if (response == nullptr || response_size != PICOOS_STM32_FRAME_MAX_SIZE ||
        loopback.endpoint.receive(request, request_size, loopback.now++) !=
            PICOOS_STM32_CODEC_OK) {
        return false;
    }
    if (loopback.lose_response) {
        loopback.lose_response = false;
        return false;
    }
    std::fill_n(response, response_size, static_cast<std::uint8_t>(0U));
    std::copy_n(loopback.endpoint.response_data(),
                loopback.endpoint.response_size(), response);
    return true;
}

}  // namespace

SelfTestReport run_self_test() {
    SelfTestReport report{};
    std::array<std::uint8_t, PICOOS_STM32_FRAME_MAX_SIZE> bytes{};
    std::size_t size{};
    PicoOsStm32Frame request{};
    request.command = PICOOS_STM32_COMMAND_IDENTIFY;
    request.transaction = 1U;
    PicoOsStm32Frame decoded{};
    const bool encoded = encode(request, bytes, size);
    record(report, self_test_codec,
           encoded && picoos_stm32_frame_decode(bytes.data(), bytes.size(),
                                                &decoded) ==
                          PICOOS_STM32_CODEC_OK &&
               decoded.command == request.command &&
               decoded.transaction == request.transaction);

    auto corrupt = bytes;
    if (size != 0U) corrupt[size - 1U] ^= 0x80U;
    record(report, self_test_integrity,
           encoded && picoos_stm32_frame_decode(corrupt.data(), size, &decoded) ==
                          PICOOS_STM32_CODEC_BAD_CRC);

    TransportEndpoint endpoint;
    const bool first = endpoint.receive(bytes.data(), size, 10U) ==
                       PICOOS_STM32_CODEC_OK;
    std::array<std::uint8_t, PICOOS_STM32_FRAME_MAX_SIZE> first_response{};
    const std::size_t first_response_size = endpoint.response_size();
    if (first_response_size <= first_response.size()) {
        std::copy_n(endpoint.response_data(), first_response_size,
                    first_response.begin());
    }
    const bool second = endpoint.receive(bytes.data(), size, 11U) ==
                        PICOOS_STM32_CODEC_OK;
    report.duplicate_transactions =
        endpoint.diagnostics().duplicate_transactions;
    record(report, self_test_duplicate_replay,
           first && second && report.duplicate_transactions == 1U &&
               endpoint.response_size() == first_response_size &&
               std::memcmp(endpoint.response_data(), first_response.data(),
                           first_response_size) == 0);

    ControllerModel model;
    model.rtc().set(1'000U, 1'000U);
    const auto token = model.power().prepare_soft_off(2'000U);
    const bool wrong_rejected = token.has_value() &&
                                !model.commit_soft_off(token.value() ^ 1U, 2'001U) &&
                                model.power().pico_powered();
    const bool correct_accepted = token.has_value() &&
                                  model.commit_soft_off(token.value(), 2'002U) &&
                                  !model.power().pico_powered() && model.rtc().valid();
    record(report, self_test_power_safety,
           wrong_rejected && correct_accepted && model.power().wake_from_button());

    for (std::uint8_t key = 0U;
         key < static_cast<std::uint8_t>(key_queue_capacity + 1U); ++key) {
        static_cast<void>(model.keyboard().transition(key, true, 0U, key));
    }
    report.queue_overflows = model.keyboard().snapshot().overflow_count;
    record(report, self_test_keyboard_recovery,
           report.queue_overflows == 1U && model.keyboard().held(0U) &&
               model.keyboard().held(
                   static_cast<std::uint8_t>(key_queue_capacity)));

    PmuSample sample{};
    sample.validity = static_cast<std::uint16_t>(
        pmu_valid_battery_percent | pmu_valid_battery_voltage);
    sample.battery_percent = 73U;
    sample.battery_millivolts = 3'912U;
    model.telemetry().update(sample, 12'345U);
    record(report, self_test_telemetry,
           model.telemetry().initialized() &&
               model.telemetry().snapshot().generation == 1U &&
               model.telemetry().snapshot().sample.battery_percent == 73U);

    const bool gpio_added = model.gpio().add(
        {42U, gpio_capability_output, false});
    const bool gpio_configured =
        model.gpio().configure(42U, GpioDirection::output, GpioPull::none);
    const bool gpio_written = model.gpio().write(42U, true);
    model.gpio().restore_safe();
    const auto* gpio = model.gpio().find(42U);
    record(report, self_test_gpio_safe_state,
           gpio_added && gpio_configured && gpio_written && gpio != nullptr &&
               !gpio->configured && !gpio->value);

    Loopback loopback{};
    ControllerClient client({&loopback, exchange});
    PicoOsStm32Frame response{};
    PicoOsStm32Status remote_status{};
    loopback.lose_response = false;
    const auto synchronize_result = client.synchronize(0x13579BDFU);
    loopback.lose_response = true;
    const auto client_result = client.transact(
        PICOOS_STM32_COMMAND_STATUS, nullptr, 0U, response, remote_status);
    record(report, self_test_client_retry,
           synchronize_result == ClientResult::ok &&
               client_result == ClientResult::ok &&
               remote_status == PICOOS_STM32_STATUS_OK &&
               client.diagnostics().retries == 1U &&
               client.diagnostics().session_synchronizations == 1U &&
               loopback.endpoint.diagnostics().session_resynchronizations == 1U &&
               loopback.endpoint.diagnostics().duplicate_transactions == 1U);

    ControllerModel boundary_model;
    InertHardware inert{5'000U};
    HardwareBindings bindings{};
    bindings.context = &inert;
    bindings.milliseconds = read_milliseconds;
    ControllerHardwareAdapter adapter(boundary_model, bindings);
    const bool booted = adapter.bootstrap(
        {inert.now, 1'700'000'000ULL, 0x10203040U, true, true});
    const auto old_token = boundary_model.power().prepare_soft_off(inert.now);
    const bool rebooted = adapter.bootstrap(
        {inert.now, 1'700'000'000ULL, 0x50607080U, true, true});
    const bool old_rejected = old_token.has_value() &&
                              !boundary_model.commit_soft_off(old_token.value(),
                                                              inert.now);
    const auto new_token = boundary_model.power().prepare_soft_off(inert.now);
    const bool new_committed =
        new_token.has_value() && old_token.has_value() &&
        new_token.value() != old_token.value() &&
        boundary_model.commit_soft_off(new_token.value(), inert.now);
    record(report, self_test_hardware_boundary,
           booted && rebooted && old_rejected && new_committed && adapter.poll() &&
               adapter.diagnostics().blocked_outputs >= 2U &&
               boundary_model.power().state() == PowerState::soft_off);

    DiagnosticRuntime diagnostic(bindings);
    const bool diagnostic_booted = diagnostic.bootstrap(
        {inert.now, 1'700'000'000ULL, 0xA5A55A5AU, true, true});
    request = {};
    request.command = PICOOS_STM32_COMMAND_SESSION_SYNC;
    request.transaction = 0U;
    request.payload_size = 4U;
    picoos_stm32_write_u32_le(request.payload, 0x2468ACE0U);
    const bool diagnostic_sync_encoded = encode(request, bytes, size);
    const bool diagnostic_synced =
        diagnostic_sync_encoded &&
        diagnostic.receive(bytes.data(), size, inert.now) ==
            PICOOS_STM32_CODEC_OK;
    request = {};
    request.command = PICOOS_STM32_COMMAND_POWER_PREPARE;
    request.transaction = 1U;
    const bool forbidden_encoded = encode(request, bytes, size);
    const bool forbidden_answered =
        forbidden_encoded &&
        diagnostic.receive(bytes.data(), size, inert.now) ==
            PICOOS_STM32_CODEC_OK &&
        picoos_stm32_frame_decode(diagnostic.response_data(),
                                  diagnostic.response_size(), &decoded) ==
            PICOOS_STM32_CODEC_OK;
    record(report, self_test_diagnostic_profile,
           diagnostic_booted && diagnostic.poll() && diagnostic_synced &&
               forbidden_answered &&
               decoded.payload[0] == PICOOS_STM32_STATUS_UNSUPPORTED &&
               (decoded.flags & PICOOS_STM32_FRAME_ERROR) != 0U);

    report.failed |= self_test_all & ~report.passed;
    return report;
}

}  // namespace picoos::stm32
