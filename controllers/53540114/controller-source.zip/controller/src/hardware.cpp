#include <picoos/stm32/hardware.hpp>

namespace picoos::stm32 {
namespace {

bool same_backlights(const BacklightState left, const BacklightState right) {
    return left.lcd == right.lcd && left.keyboard == right.keyboard;
}

}  // namespace

ControllerHardwareAdapter::ControllerHardwareAdapter(
    ControllerModel& model, const HardwareBindings bindings,
    const HardwarePolicy policy)
    : model_(model), bindings_(bindings), policy_(policy) {}

bool ControllerHardwareAdapter::valid() const {
    if (bindings_.milliseconds == nullptr) return false;
    if (has(hardware_capability_keyboard) && bindings_.read_key == nullptr)
        return false;
    if (has(hardware_capability_headphone) && bindings_.read_headphone == nullptr)
        return false;
    if (has(hardware_capability_pmu) && bindings_.read_pmu == nullptr) return false;
    if (has(hardware_capability_rtc_write) && bindings_.write_rtc == nullptr)
        return false;
    if (has(hardware_capability_backlights) &&
        bindings_.write_backlights == nullptr)
        return false;
    if (has(hardware_capability_pico_power) &&
        bindings_.write_pico_power == nullptr)
        return false;
    if (has(hardware_capability_stop) && bindings_.enter_stop == nullptr)
        return false;
    if (has(hardware_capability_hard_shutdown) &&
        bindings_.hard_shutdown == nullptr)
        return false;
    if (policy_.allow_rtc_write && !has(hardware_capability_rtc_write)) return false;
    if (policy_.allow_backlights && !has(hardware_capability_backlights)) return false;
    if (policy_.allow_pico_power && !has(hardware_capability_pico_power)) return false;
    if (policy_.allow_stop && !has(hardware_capability_stop)) return false;
    if (policy_.allow_hard_shutdown &&
        !has(hardware_capability_hard_shutdown))
        return false;
    return true;
}

bool ControllerHardwareAdapter::bootstrap(const HardwareBootState& state) {
    if (!valid()) return false;
    model_.controller_reset(state.pico_powered, state.reset_nonce, false);
    if (state.rtc_valid)
        model_.rtc().set(state.rtc_epoch_seconds, state.now_milliseconds);
    applied_rtc_revision_ = model_.rtc().revision();
    applied_pico_power_ = state.pico_powered;
    pico_power_confirmed_ = true;
    applied_backlights_valid_ = false;
    backlights_confirmed_ = false;
    observed_power_state_ = model_.power().state();
    first_key_scan_ = true;
    action_handled_ = false;
    bootstrapped_ = true;
    ++diagnostics_.boots;
    return true;
}

bool ControllerHardwareAdapter::poll() {
    if (!bootstrapped_ || !valid()) return false;
    std::uint64_t now_milliseconds{};
    if (!bindings_.milliseconds(bindings_.context, now_milliseconds)) {
        ++diagnostics_.input_failures;
        return false;
    }
    ++diagnostics_.polls;
    sample_inputs(now_milliseconds);
    model_.power().poll(now_milliseconds);
    synchronize_outputs(now_milliseconds);
    return true;
}

bool ControllerHardwareAdapter::wake_from_button() {
    if (!bootstrapped_ || !model_.power().wake_from_button()) return false;
    action_handled_ = false;
    return true;
}

const HardwareDiagnostics& ControllerHardwareAdapter::diagnostics() const {
    return diagnostics_;
}

bool ControllerHardwareAdapter::has(const std::uint32_t capability) const {
    return (bindings_.capabilities & capability) != 0U;
}

void ControllerHardwareAdapter::sample_inputs(
    const std::uint64_t now_milliseconds) {
    if (has(hardware_capability_keyboard)) {
        for (std::size_t index = 0U; index < key_count; ++index) {
            bool pressed{};
            if (!bindings_.read_key(bindings_.context,
                                    static_cast<std::uint8_t>(index), pressed)) {
                ++diagnostics_.input_failures;
                continue;
            }
            const bool changed = model_.keyboard().transition(
                static_cast<std::uint8_t>(index), pressed, 0U,
                static_cast<std::uint32_t>(now_milliseconds));
            if (first_key_scan_ && pressed && changed)
                ++diagnostics_.held_state_repairs;
        }
        first_key_scan_ = false;
    }

    if (has(hardware_capability_headphone)) {
        bool inserted{};
        if (bindings_.read_headphone(bindings_.context, inserted)) {
            static_cast<void>(model_.headphone().sample(inserted, now_milliseconds));
        } else {
            ++diagnostics_.input_failures;
        }
    }

    if (has(hardware_capability_pmu)) {
        PmuSample sample{};
        if (bindings_.read_pmu(bindings_.context, sample)) {
            model_.telemetry().update(sample,
                                      static_cast<std::uint32_t>(now_milliseconds));
        } else {
            ++diagnostics_.input_failures;
        }
    }
}

void ControllerHardwareAdapter::synchronize_outputs(
    const std::uint64_t now_milliseconds) {
    synchronize_backlights();
    synchronize_rtc(now_milliseconds);
    synchronize_pico_power();
    synchronize_power_action();
}

void ControllerHardwareAdapter::synchronize_backlights() {
    const BacklightState desired = model_.power().backlights();
    if (applied_backlights_valid_ &&
        same_backlights(desired, applied_backlights_))
        return;
    if (!policy_.allow_backlights) {
        ++diagnostics_.blocked_outputs;
        applied_backlights_ = desired;
        applied_backlights_valid_ = true;
        backlights_confirmed_ = false;
        return;
    }
    if (!bindings_.write_backlights(bindings_.context, desired)) {
        ++diagnostics_.output_failures;
        backlights_confirmed_ = false;
        return;
    }
    applied_backlights_ = desired;
    applied_backlights_valid_ = true;
    backlights_confirmed_ = true;
    ++diagnostics_.backlight_writes;
}

void ControllerHardwareAdapter::synchronize_rtc(
    const std::uint64_t now_milliseconds) {
    const std::uint32_t revision = model_.rtc().revision();
    if (revision == applied_rtc_revision_) return;
    const auto time = model_.rtc().read(now_milliseconds);
    if (!policy_.allow_rtc_write) {
        ++diagnostics_.blocked_outputs;
        applied_rtc_revision_ = revision;
        return;
    }
    if (!bindings_.write_rtc(bindings_.context, time.has_value(),
                             time.value_or(0U))) {
        ++diagnostics_.output_failures;
        return;
    }
    applied_rtc_revision_ = revision;
    ++diagnostics_.rtc_writes;
}

void ControllerHardwareAdapter::synchronize_pico_power() {
    const bool desired = model_.power().pico_powered();
    if (desired == applied_pico_power_) return;
    if (!policy_.allow_pico_power) {
        ++diagnostics_.blocked_outputs;
        applied_pico_power_ = desired;
        pico_power_confirmed_ = false;
        return;
    }
    if (!desired && model_.power().state() == PowerState::soft_off &&
        !backlights_confirmed_) {
        pico_power_confirmed_ = false;
        return;
    }
    if (!bindings_.write_pico_power(bindings_.context, desired)) {
        ++diagnostics_.output_failures;
        pico_power_confirmed_ = false;
        return;
    }
    applied_pico_power_ = desired;
    pico_power_confirmed_ = true;
    ++diagnostics_.pico_power_writes;
}

void ControllerHardwareAdapter::synchronize_power_action() {
    const PowerState state = model_.power().state();
    if (state != observed_power_state_) {
        observed_power_state_ = state;
        action_handled_ = false;
    }
    if (action_handled_) return;

    if (state == PowerState::soft_off) {
        if (!pico_power_confirmed_) return;
        if (!policy_.allow_stop) {
            ++diagnostics_.blocked_outputs;
            action_handled_ = true;
            return;
        }
        if (!bindings_.enter_stop(bindings_.context)) {
            ++diagnostics_.output_failures;
            return;
        }
        ++diagnostics_.stop_entries;
        action_handled_ = true;
    } else if (state == PowerState::hard_off) {
        if (!policy_.allow_hard_shutdown) {
            ++diagnostics_.blocked_outputs;
            action_handled_ = true;
            return;
        }
        if (!bindings_.hard_shutdown(bindings_.context)) {
            ++diagnostics_.output_failures;
            return;
        }
        ++diagnostics_.hard_shutdowns;
        action_handled_ = true;
    }
}

}  // namespace picoos::stm32
