#include <picoos/stm32/stock_extension.hpp>

namespace picoos::stm32 {

StockRequestKind classify_stock_request(const std::uint8_t* bytes,
                                        const std::size_t size, const bool overflow) {
    if (overflow || bytes == nullptr || size == 0U || size > PICOOS_STM32_FRAME_MAX_SIZE)
        return StockRequestKind::invalid;
    if (bytes[0] == PICOOS_STM32_FRAME_MAGIC_0) return StockRequestKind::extended;
    if (bytes[0] == StockExtension::identity_register && size == 1U)
        return StockRequestKind::identity;
    const bool write = (bytes[0] & 0x80U) != 0U;
    if (size != (write ? 2U : 1U)) return StockRequestKind::invalid;
    return StockRequestKind::legacy;
}

void StockExtension::sample_key(const std::uint8_t id, const bool pressed) {
    // Matrix slot55 is unpopulated, not an extra key or accessory input.
    if (id < physical_keys && id != 55U) samples_[id] = pressed;
}

void StockExtension::finish_scan(const std::uint32_t now) {
    for (std::size_t id = 0; id < physical_keys; ++id) {
        if (samples_[id] != candidate_[id]) {
            candidate_[id] = samples_[id];
            changed_at_[id] = now;
        }
        if (static_cast<std::uint32_t>(now - changed_at_[id]) >= debounce_ms)
            stable_[id] = candidate_[id];
    }
    // Physical modifier bits: Alt, Ctrl, left Shift, right Shift. Compute after
    // debouncing the entire scan so a chord never depends on matrix scan order.
    std::uint8_t modifiers{};
    for (std::size_t bit = 0; bit < 4U; ++bit)
        if (stable_[56U + bit]) modifiers |= static_cast<std::uint8_t>(1U << bit);
    auto& keys = endpoint_.server().model().keyboard();
    // This stream's lock state follows the same debounced physical transitions
    // as its events. Do not mix the earlier legacy scan's Caps flag into it.
    if (stable_[10U] && !keys.held(10U)) keys.set_caps_lock(!keys.caps_lock());
    if (keys.caps_lock()) modifiers |= 0x10U;
    for (std::size_t id = 0; id < physical_keys; ++id)
        static_cast<void>(keys.transition(static_cast<std::uint8_t>(id), stable_[id], modifiers, now));
}

void StockExtension::observe_backlights(const std::uint8_t lcd, const std::uint8_t keyboard) {
    endpoint_.server().model().power().set_backlights(lcd, keyboard);
}

void StockExtension::receive(const std::uint8_t* bytes, const std::size_t size,
                             const std::uint32_t now) {
    static_cast<void>(endpoint_.receive(bytes, size, now));
}

void StockExtension::bus_recovered() { endpoint_.note_bus_recovery(); }
const std::uint8_t* StockExtension::response_data() const { return endpoint_.response_data(); }
std::size_t StockExtension::response_size() const { return endpoint_.response_size(); }
const KeyboardQueue& StockExtension::keyboard() const { return endpoint_.server().model().keyboard(); }

std::size_t StockExtension::identify(std::uint8_t* bytes, const std::size_t capacity,
                                    const bool hardware_rtc) {
    if (bytes == nullptr || capacity < 12U) return 0U;
    bytes[0] = 'P'; bytes[1] = 'S';
    bytes[2] = PICOOS_STM32_PROTOCOL_MAJOR;
    bytes[3] = PICOOS_STM32_PROTOCOL_MINOR;
    picoos_stm32_write_u32_le(bytes + 4U, build_identity);
    picoos_stm32_write_u32_le(bytes + 8U, ControllerServer::diagnostic_capabilities |
        PICOOS_STM32_CAPABILITY_SUSPEND_UI |
        (hardware_rtc ? static_cast<std::uint32_t>(PICOOS_STM32_CAPABILITY_RTC) : 0U));
    return 12U;
}

}  // namespace picoos::stm32
