#include <picoos/stm32/update_sender.hpp>
namespace picoos::stm32::update {
bool Sender::start(Image image, std::uint32_t session, std::uint32_t now) {
    if (state_ != SendState::idle || !source_.read || !link_.exchange || !valid_image_description(image) ||
        image.length != source_.length || session == 0) return false;
    image_ = image; session_ = session; started_ = now; state_ = SendState::checking; return true;
}
void Sender::cancel() {
    if (state_ == SendState::checking || state_ == SendState::probing) {
        state_ = SendState::cancelled; // no accepted update ownership yet
    } else if (state_ == SendState::starting) {
        // A failed BEGIN reply can still mean the receiver accepted it.
        state_ = sent_command_ ? SendState::cancelling : SendState::cancelled;
    } else if (state_ == SendState::erasing || state_ == SendState::sending ||
               (state_ == SendState::committing && !commit_sent_)) {
        state_ = SendState::cancelling;
    }
    // Once COMMIT may have arrived, finish learning its result, not false cancel.
}
void Sender::poll(std::uint32_t now) {
    if (state_ == SendState::idle || state_ == SendState::failed || state_ == SendState::cancelled || state_ == SendState::complete) return;
    // At the factory 10 kHz rate, each 16-byte chunk needs two 32-byte
    // packets: a maximum-size image takes over 200 seconds on the wire alone.
    // Keep a finite overall bound with room for erase, verification and retries.
    if (now - started_ >= 600000U) { fail(Result::busy); return; }
    if (state_ == SendState::checking) {
        std::uint8_t block[256]{};
        const auto count = image_.length - offset_ < sizeof(block) ? image_.length - offset_ : sizeof(block);
        if (!source_.read(source_.context, offset_, block, count)) { fail(Result::io); return; }
        if (offset_ == 0 && !valid_vectors(block, image_.length)) { fail(Result::integrity); return; }
        crc_ = crc32(block, count, crc_); offset_ += static_cast<std::uint32_t>(count);
        if (offset_ == image_.length) {
            if ((crc_ ^ 0xFFFFFFFFU) != image_.crc) { fail(Result::integrity); return; }
            state_ = SendState::probing; offset_ = 0;
        }
        return;
    }
    if (failures_ != 0 && now - attempt_ < 50U) return;
    std::uint8_t request[packet_bytes]{}, reply[packet_bytes]{};
    request[0] = 'P'; request[1] = 'U'; request[2] = 1;
    auto command = Command::status;
    switch (state_) {
    case SendState::starting:
        command = Command::begin; write32(request + 8, image_.length);
        write32(request + 12, image_.crc); write32(request + 16, image_.build);
        write32(request + 20, device_id); write32(request + 24, layout_id); break;
    case SendState::sending: {
        command = Command::data; write32(request + 8, offset_);
        for (std::size_t i = 12; i < 28; ++i) request[i] = 0xFF;
        const auto count = image_.length - offset_ < chunk_bytes ? image_.length - offset_ : chunk_bytes;
        if (!source_.read(source_.context, offset_, request + 12, count)) { fail(Result::io); return; }
        break;
    }
    case SendState::committing: command = Command::commit; break;
    case SendState::cancelling: command = Command::cancel; break;
    default: break;
    }
    request[3] = static_cast<std::uint8_t>(command);
    if (command != Command::status) write32(request + 4, session_);
    write32(request + 28, crc32(request, 28) ^ 0xFFFFFFFFU);
    attempt_ = now;
    if (command != Command::status) sent_command_ = true;
    if (command == Command::commit) commit_sent_ = true;
    if (!link_.exchange(link_.context, request, reply) || reply[0] != 'P' || reply[1] != 'U' || reply[2] != 1 ||
        reply[3] != (request[3] | 0x80U) || reply[12] > static_cast<std::uint8_t>(Result::state) ||
        reply[13] > static_cast<std::uint8_t>(State::failed) || reply[14] > static_cast<std::uint8_t>(Result::state) ||
        reply[15] != 0 || read32(reply + 28) != (crc32(reply, 28) ^ 0xFFFFFFFFU)) {
        if (++failures_ >= 8) fail(Result::io);
        return;
    }
    failures_ = 0;
    const auto remote = static_cast<State>(reply[13]);
    if (state_ == SendState::probing) {
        if (reply[12] != 0) { fail(static_cast<Result>(reply[12])); return; }
        const auto old_session = read32(reply + 4);
        const bool same = read32(reply + 16) == image_.length &&
            read32(reply + 20) == image_.crc && read32(reply + 24) == image_.build;
        if (remote != State::idle && remote != State::failed) {
            if (!same && remote != State::complete) { fail(Result::session); return; }
            if (same) {
                const auto received = read32(reply + 8);
                if (old_session == 0 || received > image_.length ||
                    (received != image_.length && received % chunk_bytes != 0) ||
                    ((remote == State::verifying || remote == State::committing || remote == State::complete) && received != image_.length)) {
                    fail(Result::offset); return;
                }
                // A Pico reset does not reset the resident. Resume only the
                // exact fully checked package; never hijack another image.
                session_ = old_session; offset_ = received;
                if (remote == State::receiving) state_ = received == image_.length ? SendState::committing : SendState::sending;
                else if (remote == State::complete) state_ = SendState::complete;
                else if (remote == State::verifying || remote == State::committing) {
                    commit_sent_ = true; state_ = SendState::verifying;
                } else state_ = SendState::erasing;
                return;
            }
        }
        // Even a failed resident session may remember its identifier. A new
        // BEGIN must not accidentally be mistaken for a duplicate old BEGIN.
        if (session_ == old_session) { ++session_; if (session_ == 0) session_ = 1; }
        state_ = SendState::starting;
        return;
    }
    if (read32(reply + 4) != session_ || read32(reply + 16) != image_.length ||
        read32(reply + 20) != image_.crc || read32(reply + 24) != image_.build) { fail(Result::session); return; }
    if (reply[12] != 0) { fail(static_cast<Result>(reply[12])); return; }
    if (state_ == SendState::cancelling) {
        if (remote != State::failed || reply[14] != static_cast<std::uint8_t>(Result::state)) { fail(Result::state); return; }
        state_ = SendState::cancelled; return;
    }
    if (remote == State::failed) { fail(static_cast<Result>(reply[14])); return; }
    if (state_ == SendState::starting) {
        if (remote != State::invalidate && remote != State::erasing && remote != State::receiving) { fail(Result::state); return; }
        state_ = SendState::erasing;
    } else if (state_ == SendState::erasing) {
        if (remote == State::receiving && read32(reply + 8) == 0) state_ = SendState::sending;
        else if (remote != State::invalidate && remote != State::erasing) fail(Result::state);
    } else if (state_ == SendState::sending) {
        const auto next = image_.length - offset_ < chunk_bytes ? image_.length : offset_ + chunk_bytes;
        if (remote != State::receiving || read32(reply + 8) != next) { fail(Result::offset); return; }
        offset_ = static_cast<std::uint32_t>(next); if (offset_ == image_.length) state_ = SendState::committing;
    } else if (state_ == SendState::committing || state_ == SendState::verifying) {
        if (read32(reply + 8) != image_.length) { fail(Result::offset); return; }
        if (remote == State::complete) state_ = SendState::complete;
        else if (remote == State::verifying || remote == State::committing) state_ = SendState::verifying;
        else fail(Result::state);
    }
}
}
