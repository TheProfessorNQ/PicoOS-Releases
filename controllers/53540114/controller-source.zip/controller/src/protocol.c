#include <picoos/stm32/protocol.h>

#include <string.h>

static const uint8_t known_flags =
    (uint8_t)(PICOOS_STM32_FRAME_RESPONSE | PICOOS_STM32_FRAME_ERROR);

uint16_t picoos_stm32_crc16_ccitt(const uint8_t* data, const size_t size) {
    uint16_t crc = 0xFFFFU;
    size_t index;
    if (data == NULL && size != 0U) return 0U;
    for (index = 0U; index < size; ++index) {
        uint8_t bit;
        crc ^= (uint16_t)((uint16_t)data[index] << 8U);
        for (bit = 0U; bit < 8U; ++bit) {
            crc = (crc & 0x8000U) != 0U
                      ? (uint16_t)((uint16_t)(crc << 1U) ^ 0x1021U)
                      : (uint16_t)(crc << 1U);
        }
    }
    return crc;
}

size_t picoos_stm32_frame_encoded_size(const PicoOsStm32Frame* frame) {
    if (frame == NULL || frame->payload_size > PICOOS_STM32_PAYLOAD_MAX_SIZE) return 0U;
    return PICOOS_STM32_FRAME_HEADER_SIZE + (size_t)frame->payload_size +
           PICOOS_STM32_FRAME_CRC_SIZE;
}

PicoOsStm32CodecResult picoos_stm32_frame_encode(
    const PicoOsStm32Frame* frame,
    uint8_t* destination,
    const size_t capacity,
    size_t* encoded_size) {
    size_t size;
    uint16_t crc;
    if (encoded_size != NULL) *encoded_size = 0U;
    if (frame == NULL || destination == NULL || encoded_size == NULL) {
        return PICOOS_STM32_CODEC_INVALID_ARGUMENT;
    }
    if (frame->payload_size > PICOOS_STM32_PAYLOAD_MAX_SIZE) {
        return PICOOS_STM32_CODEC_BAD_LENGTH;
    }
    if ((frame->flags & (uint8_t)~known_flags) != 0U ||
        ((frame->flags & PICOOS_STM32_FRAME_ERROR) != 0U &&
         (frame->flags & PICOOS_STM32_FRAME_RESPONSE) == 0U)) {
        return PICOOS_STM32_CODEC_BAD_FLAGS;
    }
    size = picoos_stm32_frame_encoded_size(frame);
    if (capacity < size) return PICOOS_STM32_CODEC_NO_SPACE;
    destination[0] = PICOOS_STM32_FRAME_MAGIC_0;
    destination[1] = PICOOS_STM32_FRAME_MAGIC_1;
    destination[2] = PICOOS_STM32_PROTOCOL_MAJOR;
    destination[3] = frame->command;
    picoos_stm32_write_u16_le(destination + 4U, frame->transaction);
    destination[6] = frame->flags;
    destination[7] = frame->payload_size;
    if (frame->payload_size != 0U) {
        memcpy(destination + PICOOS_STM32_FRAME_HEADER_SIZE,
               frame->payload,
               frame->payload_size);
    }
    crc = picoos_stm32_crc16_ccitt(destination, size - PICOOS_STM32_FRAME_CRC_SIZE);
    picoos_stm32_write_u16_le(destination + size - PICOOS_STM32_FRAME_CRC_SIZE, crc);
    *encoded_size = size;
    return PICOOS_STM32_CODEC_OK;
}

PicoOsStm32CodecResult picoos_stm32_frame_decode(
    const uint8_t* source,
    const size_t size,
    PicoOsStm32Frame* frame) {
    size_t expected_size;
    uint16_t expected_crc;
    uint16_t actual_crc;
    uint8_t payload_size;
    if (source == NULL || frame == NULL) return PICOOS_STM32_CODEC_INVALID_ARGUMENT;
    memset(frame, 0, sizeof(*frame));
    if (size < PICOOS_STM32_FRAME_HEADER_SIZE + PICOOS_STM32_FRAME_CRC_SIZE) {
        return PICOOS_STM32_CODEC_TRUNCATED;
    }
    if (source[0] != PICOOS_STM32_FRAME_MAGIC_0 ||
        source[1] != PICOOS_STM32_FRAME_MAGIC_1) {
        return PICOOS_STM32_CODEC_BAD_MAGIC;
    }
    if (source[2] != PICOOS_STM32_PROTOCOL_MAJOR) {
        return PICOOS_STM32_CODEC_BAD_VERSION;
    }
    if ((source[6] & (uint8_t)~known_flags) != 0U ||
        ((source[6] & PICOOS_STM32_FRAME_ERROR) != 0U &&
         (source[6] & PICOOS_STM32_FRAME_RESPONSE) == 0U)) {
        return PICOOS_STM32_CODEC_BAD_FLAGS;
    }
    payload_size = source[7];
    if (payload_size > PICOOS_STM32_PAYLOAD_MAX_SIZE) {
        return PICOOS_STM32_CODEC_BAD_LENGTH;
    }
    expected_size = PICOOS_STM32_FRAME_HEADER_SIZE + (size_t)payload_size +
                    PICOOS_STM32_FRAME_CRC_SIZE;
    if (size < expected_size) return PICOOS_STM32_CODEC_TRUNCATED;
    if (size != expected_size) {
        size_t index;
        if (size != PICOOS_STM32_FRAME_MAX_SIZE) {
            return PICOOS_STM32_CODEC_BAD_LENGTH;
        }
        for (index = expected_size; index < size; ++index) {
            if (source[index] != 0U) return PICOOS_STM32_CODEC_BAD_LENGTH;
        }
    }
    expected_crc = picoos_stm32_read_u16_le(
        source + expected_size - PICOOS_STM32_FRAME_CRC_SIZE);
    actual_crc = picoos_stm32_crc16_ccitt(
        source, expected_size - PICOOS_STM32_FRAME_CRC_SIZE);
    if (actual_crc != expected_crc) return PICOOS_STM32_CODEC_BAD_CRC;
    frame->command = source[3];
    frame->transaction = picoos_stm32_read_u16_le(source + 4U);
    frame->flags = source[6];
    frame->payload_size = payload_size;
    if (payload_size != 0U) {
        memcpy(frame->payload, source + PICOOS_STM32_FRAME_HEADER_SIZE, payload_size);
    }
    return PICOOS_STM32_CODEC_OK;
}

uint16_t picoos_stm32_read_u16_le(const uint8_t* source) {
    return (uint16_t)((uint16_t)source[0] | (uint16_t)((uint16_t)source[1] << 8U));
}

uint32_t picoos_stm32_read_u32_le(const uint8_t* source) {
    return (uint32_t)source[0] | ((uint32_t)source[1] << 8U) |
           ((uint32_t)source[2] << 16U) | ((uint32_t)source[3] << 24U);
}

uint64_t picoos_stm32_read_u64_le(const uint8_t* source) {
    uint64_t value = 0U;
    uint8_t index;
    for (index = 0U; index < 8U; ++index) {
        value |= (uint64_t)source[index] << (8U * index);
    }
    return value;
}

void picoos_stm32_write_u16_le(uint8_t* destination, const uint16_t value) {
    destination[0] = (uint8_t)(value & 0xFFU);
    destination[1] = (uint8_t)(value >> 8U);
}

void picoos_stm32_write_u32_le(uint8_t* destination, const uint32_t value) {
    uint8_t index;
    for (index = 0U; index < 4U; ++index) {
        destination[index] = (uint8_t)(value >> (8U * index));
    }
}

void picoos_stm32_write_u64_le(uint8_t* destination, const uint64_t value) {
    uint8_t index;
    for (index = 0U; index < 8U; ++index) {
        destination[index] = (uint8_t)(value >> (8U * index));
    }
}
