#include <picoos/stm32/diagnostic.hpp>

namespace picoos::stm32 {

DiagnosticRuntime::DiagnosticRuntime(const HardwareBindings bindings)
    : adapter_(endpoint_.server().model(), bindings, HardwarePolicy{}) {}

bool DiagnosticRuntime::bootstrap(const HardwareBootState& state) {
    return adapter_.bootstrap(state);
}

bool DiagnosticRuntime::poll() {
    return adapter_.poll();
}

PicoOsStm32CodecResult DiagnosticRuntime::receive(
    const std::uint8_t* bytes, const std::size_t size,
    const std::uint64_t now_milliseconds) {
    return endpoint_.receive(bytes, size, now_milliseconds);
}

const std::uint8_t* DiagnosticRuntime::response_data() const {
    return endpoint_.response_data();
}

std::size_t DiagnosticRuntime::response_size() const {
    return endpoint_.response_size();
}

const HardwareDiagnostics& DiagnosticRuntime::hardware_diagnostics() const {
    return adapter_.diagnostics();
}

const TransportDiagnostics& DiagnosticRuntime::transport_diagnostics() const {
    return endpoint_.diagnostics();
}

}  // namespace picoos::stm32
