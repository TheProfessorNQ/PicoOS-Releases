#include <picoos/stm32/updater.hpp>

namespace picoos::stm32::update {
namespace {
constexpr std::uint32_t manifest_magic = 0x31554350U;
constexpr std::uint32_t committed = 0xA55A3CC3U;
bool available(const Flash& flash) { return flash.read && flash.erase_page && flash.program_halfword; }
bool read(const Flash& flash, std::uint32_t address, std::uint8_t* data, std::size_t size) {
    return flash.read && flash.read(flash.context, address, data, size);
}
bool equal(const std::uint8_t* a, const std::uint8_t* b, std::size_t size) {
    for (std::size_t i = 0; i < size; ++i) if (a[i] != b[i]) return false;
    return true;
}
bool zero(const std::uint8_t* data, std::size_t size) {
    for (std::size_t i = 0; i < size; ++i) if (data[i] != 0) return false;
    return true;
}
void manifest(std::uint8_t* data, Image image) {
    write32(data, manifest_magic); write32(data + 4, layout_id);
    write32(data + 8, device_id); write32(data + 12, image.length);
    write32(data + 16, image.crc); write32(data + 20, image.build);
    write32(data + 24, crc32(data, 24) ^ 0xFFFFFFFFU);
    write32(data + 28, committed);
}
bool program(const Flash& flash, std::uint32_t address, const std::uint8_t* bytes, std::size_t count) {
    for (std::size_t i = 0; i < count; i += 2) {
        const auto value = static_cast<std::uint16_t>(bytes[i] | (static_cast<std::uint16_t>(bytes[i + 1]) << 8U));
        if (!flash.program_halfword(flash.context, address + static_cast<std::uint32_t>(i), value)) return false;
        std::uint8_t check[2]{};
        if (!read(flash, address + static_cast<std::uint32_t>(i), check, 2) || !equal(check, bytes + i, 2)) return false;
    }
    return true;
}
} // namespace

std::uint32_t read32(const std::uint8_t* p) {
    return static_cast<std::uint32_t>(p[0]) | (static_cast<std::uint32_t>(p[1]) << 8U) |
        (static_cast<std::uint32_t>(p[2]) << 16U) | (static_cast<std::uint32_t>(p[3]) << 24U);
}
void write32(std::uint8_t* p, std::uint32_t v) {
    for (unsigned i = 0; i < 4; ++i) p[i] = static_cast<std::uint8_t>(v >> (i * 8U));
}
std::uint32_t crc32(const std::uint8_t* bytes, std::size_t size, std::uint32_t running) {
    for (std::size_t i = 0; i < size; ++i) {
        running ^= bytes[i];
        for (unsigned b = 0; b < 8; ++b) running = (running >> 1U) ^ ((running & 1U) ? 0xEDB88320U : 0U);
    }
    return running;
}
bool valid_image_description(const Image& image) {
    return image.length >= 256U && image.length <= app_capacity && (image.length & 1U) == 0 && image.build != 0;
}
bool encode_committed_manifest(Image image, std::uint8_t* bytes, std::size_t size) {
    if (!bytes || size != 32 || !valid_image_description(image)) return false;
    manifest(bytes, image); return true;
}
bool encode_package_header(Image image, std::uint8_t* bytes, std::size_t size) {
    if (!bytes || size != package_header_bytes || !valid_image_description(image)) return false;
    write32(bytes, 0x46554350U); write32(bytes + 4, 1); write32(bytes + 8, package_header_bytes);
    write32(bytes + 12, device_id); write32(bytes + 16, layout_id); write32(bytes + 20, app_base);
    write32(bytes + 24, image.length); write32(bytes + 28, image.crc); write32(bytes + 32, image.build);
    write32(bytes + 36, crc32(bytes, 36) ^ 0xFFFFFFFFU); return true;
}
bool decode_package_header(const std::uint8_t* bytes, std::size_t size, Image& image) {
    if (!bytes || size != package_header_bytes || read32(bytes) != 0x46554350U || read32(bytes + 4) != 1 ||
        read32(bytes + 8) != package_header_bytes || read32(bytes + 12) != device_id ||
        read32(bytes + 16) != layout_id || read32(bytes + 20) != app_base ||
        read32(bytes + 36) != (crc32(bytes, 36) ^ 0xFFFFFFFFU)) return false;
    Image candidate{read32(bytes + 24), read32(bytes + 28), read32(bytes + 32)};
    if (!valid_image_description(candidate)) return false;
    image = candidate; return true;
}
bool valid_vectors(const std::uint8_t* vectors, std::uint32_t length) {
    const auto stack = read32(vectors), reset = read32(vectors + 4);
    return stack > 0x20000000U && stack <= 0x20005000U && (stack & 7U) == 0 &&
        (reset & 1U) != 0 && (reset & ~1U) >= app_base + 8U && (reset & ~1U) < app_base + length;
}
bool bootable(const Flash& flash, Image* image) {
    std::uint8_t header[32]{};
    if (!read(flash, manifest_base, header, sizeof(header)) || read32(header) != manifest_magic ||
        read32(header + 4) != layout_id || read32(header + 8) != device_id ||
        read32(header + 28) != committed || read32(header + 24) != (crc32(header, 24) ^ 0xFFFFFFFFU)) return false;
    Image candidate{read32(header + 12), read32(header + 16), read32(header + 20)};
    if (!valid_image_description(candidate)) return false;
    std::uint8_t bytes[256]{};
    std::uint32_t crc = 0xFFFFFFFFU;
    for (std::uint32_t pos = 0; pos < candidate.length;) {
        const auto count = candidate.length - pos < sizeof(bytes) ? candidate.length - pos : sizeof(bytes);
        if (!read(flash, app_base + pos, bytes, count) || (pos == 0 && !valid_vectors(bytes, candidate.length))) return false;
        crc = crc32(bytes, count, crc); pos += static_cast<std::uint32_t>(count);
    }
    if ((crc ^ 0xFFFFFFFFU) != candidate.crc) return false;
    if (image) *image = candidate;
    return true;
}
Result Receiver::begin(std::uint32_t session, Image image) {
    if (session == 0 || !valid_image_description(image)) return Result::argument;
    if (!available(flash_)) return Result::io;
    if (session == session_) {
        if (image.length != image_.length || image.crc != image_.crc || image.build != image_.build) return Result::session;
        return state_ == State::failed ? error_ : Result::ok; // lost BEGIN reply never erases twice
    }
    if (state_ != State::idle && state_ != State::failed && state_ != State::complete) return Result::busy;
    session_ = session; image_ = image; received_ = cursor_ = 0; crc_ = 0xFFFFFFFFU;
    held_ = true; boot_requested_ = false;
    error_ = Result::ok; state_ = State::invalidate;
    return Result::ok;
}
Result Receiver::data(std::uint32_t session, std::uint32_t offset, const std::uint8_t* bytes) {
    if (session == 0 || session != session_) return Result::session;
    if (state_ != State::receiving) return Result::state;
    if (!bytes || offset >= image_.length || offset % chunk_bytes != 0) return Result::argument;
    const auto count = image_.length - offset < chunk_bytes ? image_.length - offset : chunk_bytes;
    for (std::size_t i = count; i < chunk_bytes; ++i) if (bytes[i] != 0xFFU) return Result::argument;
    if (offset < received_) {
        // A lost reply may repeat an already accepted chunk, never alter it.
        if (count > received_ - offset) return Result::offset;
        std::uint8_t check[chunk_bytes]{};
        if (!read(flash_, app_base + offset, check, count)) { fail(Result::io); return error_; }
        return equal(check, bytes, count) ? Result::ok : Result::integrity;
    }
    if (offset != received_) return Result::offset;
    if (!program(flash_, app_base + offset, bytes, count)) { fail(Result::io); return error_; }
    received_ += static_cast<std::uint32_t>(count);
    return Result::ok;
}
Result Receiver::commit(std::uint32_t session) {
    if (session == 0 || session != session_) return Result::session;
    if (state_ == State::verifying || state_ == State::committing || state_ == State::complete) return Result::ok;
    if (state_ != State::receiving || received_ != image_.length) return Result::state;
    cursor_ = 0; crc_ = 0xFFFFFFFFU; state_ = State::verifying;
    return Result::ok;
}
Result Receiver::cancel(std::uint32_t session) {
    if (session == 0 || session != session_) return Result::session;
    // Already committed is not undoable. After invalidation no keyboard image
    // is promised; cancellation means remain in recovery, not boot old code.
    if (state_ == State::complete) return Result::state;
    fail(Result::state); return Result::ok;
}
Result Receiver::request_boot() {
    if (state_ != State::idle && state_ != State::failed && state_ != State::complete) return Result::busy;
    if (!bootable(flash_)) return Result::integrity;
    boot_requested_ = true; return Result::ok;
}
void Receiver::poll() {
    std::uint8_t bytes[256]{};
    if (state_ == State::invalidate) {
        if (!flash_.erase_page(flash_.context, manifest_base)) { fail(Result::io); return; }
        for (std::uint32_t pos = 0; pos < page_bytes; pos += sizeof(bytes)) {
            if (!read(flash_, manifest_base + pos, bytes, sizeof(bytes))) { fail(Result::io); return; }
            for (auto byte : bytes) if (byte != 0xFFU) { fail(Result::io); return; }
        }
        cursor_ = app_base; state_ = State::erasing;
    } else if (state_ == State::erasing) {
        if (!flash_.erase_page(flash_.context, cursor_)) { fail(Result::io); return; }
        for (std::uint32_t pos = 0; pos < page_bytes; pos += sizeof(bytes)) {
            if (!read(flash_, cursor_ + pos, bytes, sizeof(bytes))) { fail(Result::io); return; }
            for (auto byte : bytes) if (byte != 0xFFU) { fail(Result::io); return; }
        }
        cursor_ += page_bytes;
        if (cursor_ == manifest_base) state_ = State::receiving;
    } else if (state_ == State::verifying) {
        const auto count = image_.length - cursor_ < sizeof(bytes) ? image_.length - cursor_ : sizeof(bytes);
        if (!read(flash_, app_base + cursor_, bytes, count)) { fail(Result::io); return; }
        if (cursor_ == 0 && !valid_vectors(bytes, image_.length)) { fail(Result::integrity); return; }
        crc_ = crc32(bytes, count, crc_); cursor_ += static_cast<std::uint32_t>(count);
        if (cursor_ == image_.length) {
            if ((crc_ ^ 0xFFFFFFFFU) != image_.crc) { fail(Result::integrity); return; }
            state_ = State::committing;
        }
    } else if (state_ == State::committing) {
        std::uint8_t header[32]{}; manifest(header, image_);
        // The commit marker is the LAST two halfwords, after all header fields.
        if (!program(flash_, manifest_base, header, sizeof(header))) { fail(Result::io); return; }
        state_ = State::complete;
    }
}
bool exchange(Receiver& receiver, const std::uint8_t* request, std::size_t size, std::uint8_t* reply) {
    if (!request || !reply || size != packet_bytes || request[0] != 'P' || request[1] != 'U' || request[2] != 1 ||
        read32(request + 28) != (crc32(request, 28) ^ 0xFFFFFFFFU)) return false;
    const auto command = static_cast<Command>(request[3]);
    const auto session = read32(request + 4), argument = read32(request + 8);
    Result result = Result::argument;
    Image installed{};
    switch (command) {
    case Command::status:
        if (session == 0 && argument == 0 && zero(request + 12, 16)) result = Result::ok;
        break;
    case Command::begin:
        if (read32(request + 20) == device_id && read32(request + 24) == layout_id)
            result = receiver.begin(session, {argument, read32(request + 12), read32(request + 16)});
        break;
    case Command::data: result = receiver.data(session, argument, request + 12); break;
    case Command::commit:
        if (argument == 0 && zero(request + 12, 16)) result = receiver.commit(session);
        break;
    case Command::cancel:
        if (argument == 0 && zero(request + 12, 16)) result = receiver.cancel(session);
        break;
    case Command::hold:
        if (session == 0 && argument == 0 && zero(request + 12, 16)) { receiver.hold(); result = Result::ok; }
        break;
    case Command::boot:
        if (session == 0 && argument == 0 && zero(request + 12, 16)) result = receiver.request_boot();
        break;
    case Command::installed:
        if (session == 0 && argument == 0 && zero(request + 12, 16))
            result = receiver.installed(installed) ? Result::ok : Result::integrity;
        break;
    default: break;
    }
    for (std::size_t i = 0; i < packet_bytes; ++i) reply[i] = 0;
    reply[0] = 'P'; reply[1] = 'U'; reply[2] = 1; reply[3] = static_cast<std::uint8_t>(command) | 0x80U;
    write32(reply + 4, receiver.session()); write32(reply + 8, receiver.received());
    reply[12] = static_cast<std::uint8_t>(result); reply[13] = static_cast<std::uint8_t>(receiver.state());
    reply[14] = static_cast<std::uint8_t>(receiver.error());
    const auto image = command == Command::installed ? installed : receiver.image();
    write32(reply + 16, image.length); write32(reply + 20, image.crc);
    write32(reply + 24, image.build); write32(reply + 28, crc32(reply, 28) ^ 0xFFFFFFFFU);
    return true;
}
} // namespace picoos::stm32::update
