#include <picoos/stm32/model.hpp>

#include <algorithm>
#include <limits>

namespace picoos::stm32 {
namespace {

std::uint64_t saturating_add(const std::uint64_t left, const std::uint64_t right) {
    if (right > std::numeric_limits<std::uint64_t>::max() - left) {
        return std::numeric_limits<std::uint64_t>::max();
    }
    return left + right;
}

}  // namespace

bool KeyboardQueue::transition(const std::uint8_t key_id, const bool pressed,
                               const std::uint8_t modifiers,
                               const std::uint32_t timestamp_milliseconds) {
    if (key_id >= key_count || held(key_id) == pressed) return false;
    set_held(key_id, pressed);
    if (size_ == events_.size()) {
        head_ = (head_ + 1U) % events_.size();
        --size_;
        ++overflow_count_;
    }
    const std::size_t tail = (head_ + size_) % events_.size();
    events_[tail] = {next_sequence_, timestamp_milliseconds, key_id,
                     pressed ? KeyTransition::pressed : KeyTransition::released,
                     modifiers};
    ++next_sequence_;
    if (next_sequence_ == 0U) next_sequence_ = 1U;
    ++size_;
    return true;
}

std::optional<KeyEvent> KeyboardQueue::pop() {
    if (size_ == 0U) return std::nullopt;
    const KeyEvent event = events_[head_];
    head_ = (head_ + 1U) % events_.size();
    --size_;
    return event;
}

KeySnapshot KeyboardQueue::snapshot() const {
    return {next_sequence_, overflow_count_, held_};
}

void KeyboardQueue::clear_overflow() {
    overflow_count_ = 0U;
}

void KeyboardQueue::reset() {
    events_ = {};
    held_ = {};
    head_ = 0U;
    size_ = 0U;
    next_sequence_ = 1U;
    overflow_count_ = 0U;
    caps_lock_ = false;
}

std::size_t KeyboardQueue::size() const {
    return size_;
}

bool KeyboardQueue::held(const std::uint8_t key_id) const {
    if (key_id >= key_count) return false;
    const std::size_t byte = key_id / 8U;
    const std::uint8_t mask = static_cast<std::uint8_t>(1U << (key_id % 8U));
    return (held_[byte] & mask) != 0U;
}

void KeyboardQueue::set_held(const std::uint8_t key_id, const bool pressed) {
    const std::size_t byte = key_id / 8U;
    const std::uint8_t mask = static_cast<std::uint8_t>(1U << (key_id % 8U));
    if (pressed) {
        held_[byte] = static_cast<std::uint8_t>(held_[byte] | mask);
    } else {
        held_[byte] = static_cast<std::uint8_t>(held_[byte] &
                                                static_cast<std::uint8_t>(~mask));
    }
}

void RtcClock::set(const std::uint64_t epoch_seconds,
                   const std::uint64_t monotonic_milliseconds) {
    epoch_seconds_ = epoch_seconds;
    anchor_milliseconds_ = monotonic_milliseconds;
    valid_ = true;
    ++revision_;
    if (revision_ == 0U) ++revision_;
}

void RtcClock::invalidate() {
    epoch_seconds_ = 0U;
    anchor_milliseconds_ = 0U;
    valid_ = false;
    ++revision_;
    if (revision_ == 0U) ++revision_;
}

bool RtcClock::valid() const {
    return valid_;
}

std::uint32_t RtcClock::revision() const {
    return revision_;
}

std::optional<std::uint64_t> RtcClock::read(
    const std::uint64_t monotonic_milliseconds) const {
    if (!valid_) return std::nullopt;
    if (monotonic_milliseconds <= anchor_milliseconds_) return epoch_seconds_;
    const std::uint64_t elapsed_seconds =
        (monotonic_milliseconds - anchor_milliseconds_) / 1'000U;
    return saturating_add(epoch_seconds_, elapsed_seconds);
}

std::optional<std::uint32_t> PowerController::prepare_soft_off(
    const std::uint64_t now_milliseconds) {
    if (state_ != PowerState::running) return std::nullopt;
    state_ = PowerState::prepared;
    prepared_token_ = next_token();
    prepare_deadline_ = saturating_add(now_milliseconds, prepare_timeout_milliseconds);
    return prepared_token_;
}

bool PowerController::commit_soft_off(const std::uint32_t token,
                                      const std::uint64_t now_milliseconds) {
    if (state_ != PowerState::prepared || token == 0U || token != prepared_token_ ||
        now_milliseconds > prepare_deadline_) {
        ++diagnostics_.stale_token_count;
        if (state_ == PowerState::prepared && now_milliseconds > prepare_deadline_) {
            ++diagnostics_.prepare_timeout_count;
            state_ = PowerState::running;
            clear_prepare();
        }
        return false;
    }
    state_ = PowerState::soft_off;
    last_reason_ = PowerReason::picoos_request;
    backlights_ = {};
    pico_powered_ = false;
    heartbeat_armed_ = false;
    ++diagnostics_.soft_off_count;
    clear_prepare();
    return true;
}

bool PowerController::cancel_soft_off() {
    if (state_ != PowerState::prepared) return false;
    state_ = PowerState::running;
    clear_prepare();
    return true;
}

bool PowerController::wake_from_button() {
    if (state_ != PowerState::soft_off) return false;
    state_ = PowerState::running;
    last_reason_ = PowerReason::user_button;
    pico_powered_ = true;
    heartbeat_armed_ = false;
    ++diagnostics_.wake_count;
    return true;
}

void PowerController::force_hard_off(const PowerReason reason) {
    state_ = PowerState::hard_off;
    last_reason_ = reason;
    backlights_ = {};
    pico_powered_ = false;
    heartbeat_armed_ = false;
    clear_prepare();
    ++diagnostics_.hard_off_count;
}

void PowerController::true_power_on(const PowerReason reason) {
    state_ = PowerState::running;
    last_reason_ = reason;
    backlights_ = {};
    pico_powered_ = true;
    heartbeat_armed_ = false;
    clear_prepare();
}

void PowerController::heartbeat(const std::uint64_t now_milliseconds) {
    if (state_ != PowerState::running && state_ != PowerState::prepared) return;
    heartbeat_armed_ = true;
    heartbeat_deadline_ = saturating_add(now_milliseconds, heartbeat_timeout_milliseconds);
}

void PowerController::set_backlights(const std::uint8_t lcd,
                                     const std::uint8_t keyboard) {
    if (state_ != PowerState::running && state_ != PowerState::prepared) return;
    backlights_ = {lcd, keyboard};
}

void PowerController::poll(const std::uint64_t now_milliseconds) {
    if (state_ == PowerState::prepared && now_milliseconds > prepare_deadline_) {
        state_ = PowerState::running;
        clear_prepare();
        ++diagnostics_.prepare_timeout_count;
    }
    if (heartbeat_armed_ && now_milliseconds > heartbeat_deadline_) {
        heartbeat_armed_ = false;
        backlights_ = {};
        ++diagnostics_.heartbeat_timeout_count;
    }
}

void PowerController::controller_reset(const bool pico_powered,
                                       const std::uint32_t token_seed) {
    state_ = pico_powered ? PowerState::running : PowerState::soft_off;
    last_reason_ = PowerReason::controller_reset;
    backlights_ = {};
    diagnostics_ = {};
    token_counter_ = 0x50434F53U ^ token_seed;
    if (token_counter_ == 0U) token_counter_ = 1U;
    prepared_token_ = 0U;
    prepare_deadline_ = 0U;
    heartbeat_deadline_ = 0U;
    pico_powered_ = pico_powered;
    heartbeat_armed_ = false;
}

PowerState PowerController::state() const {
    return state_;
}

PowerReason PowerController::last_reason() const {
    return last_reason_;
}

bool PowerController::pico_powered() const {
    return pico_powered_;
}

BacklightState PowerController::backlights() const {
    return backlights_;
}

const PowerDiagnostics& PowerController::diagnostics() const {
    return diagnostics_;
}

std::uint32_t PowerController::next_token() {
    token_counter_ = token_counter_ * 1'664'525U + 1'013'904'223U;
    if (token_counter_ == 0U) token_counter_ = 1U;
    return token_counter_;
}

void PowerController::clear_prepare() {
    prepared_token_ = 0U;
    prepare_deadline_ = 0U;
}

std::optional<bool> DebouncedHeadphone::sample(const bool inserted,
                                                const std::uint64_t now_milliseconds) {
    if (!initialized_) {
        initialized_ = true;
        raw_ = inserted;
        stable_ = inserted;
        raw_changed_at_ = now_milliseconds;
        return stable_;
    }
    if (inserted != raw_) {
        raw_ = inserted;
        raw_changed_at_ = now_milliseconds;
        return std::nullopt;
    }
    if (stable_ != raw_ && now_milliseconds >= raw_changed_at_ &&
        now_milliseconds - raw_changed_at_ >= debounce_milliseconds) {
        stable_ = raw_;
        ++edge_count_;
        return stable_;
    }
    return std::nullopt;
}

bool DebouncedHeadphone::inserted() const {
    return stable_;
}

bool DebouncedHeadphone::initialized() const {
    return initialized_;
}

std::uint32_t DebouncedHeadphone::edge_count() const {
    return edge_count_;
}

void PmuTelemetry::update(const PmuSample& sample,
                          const std::uint32_t captured_milliseconds) {
    snapshot_.sample = sample;
    snapshot_.captured_milliseconds = captured_milliseconds;
    ++snapshot_.generation;
    if (snapshot_.generation == 0U) snapshot_.generation = 1U;
    initialized_ = true;
}

void PmuTelemetry::reset() {
    snapshot_ = {};
    initialized_ = false;
}

bool PmuTelemetry::initialized() const {
    return initialized_;
}

const PmuSnapshot& PmuTelemetry::snapshot() const {
    return snapshot_;
}

bool GpioBank::add(const GpioDescriptor& descriptor) {
    if (size_ == channels_.size() || find(descriptor.logical_id) != nullptr ||
        (descriptor.capabilities &
         static_cast<std::uint8_t>(gpio_capability_input |
                                   gpio_capability_output)) == 0U) {
        return false;
    }
    auto& channel = channels_[size_++];
    channel = {};
    channel.descriptor = descriptor;
    channel.value = descriptor.safe_value;
    return true;
}

std::size_t GpioBank::size() const {
    return size_;
}

const GpioChannelState* GpioBank::at(const std::size_t index) const {
    return index < size_ ? &channels_[index] : nullptr;
}

const GpioChannelState* GpioBank::find(const std::uint8_t logical_id) const {
    for (std::size_t index = 0U; index < size_; ++index) {
        if (channels_[index].descriptor.logical_id == logical_id) {
            return &channels_[index];
        }
    }
    return nullptr;
}

bool GpioBank::configure(const std::uint8_t logical_id,
                         const GpioDirection direction, const GpioPull pull) {
    auto* channel = find_mutable(logical_id);
    if (channel == nullptr) return false;
    const auto capabilities = channel->descriptor.capabilities;
    if ((direction == GpioDirection::input &&
         (capabilities & gpio_capability_input) == 0U) ||
        (direction == GpioDirection::output &&
         (capabilities & gpio_capability_output) == 0U) ||
        (direction == GpioDirection::safe && pull != GpioPull::none) ||
        (pull == GpioPull::up &&
         (capabilities & gpio_capability_pull_up) == 0U) ||
        (pull == GpioPull::down &&
         (capabilities & gpio_capability_pull_down) == 0U) ||
        static_cast<std::uint8_t>(direction) >
            static_cast<std::uint8_t>(GpioDirection::output) ||
        static_cast<std::uint8_t>(pull) >
            static_cast<std::uint8_t>(GpioPull::down)) {
        return false;
    }
    channel->direction = direction;
    channel->pull = pull;
    channel->configured = direction != GpioDirection::safe;
    channel->edges = 0U;
    if (!channel->configured) channel->value = channel->descriptor.safe_value;
    return true;
}

bool GpioBank::write(const std::uint8_t logical_id, const bool value) {
    auto* channel = find_mutable(logical_id);
    if (channel == nullptr || !channel->configured ||
        channel->direction != GpioDirection::output) {
        return false;
    }
    channel->value = value;
    return true;
}

bool GpioBank::sample_input(const std::uint8_t logical_id, const bool value) {
    auto* channel = find_mutable(logical_id);
    if (channel == nullptr || !channel->configured ||
        channel->direction != GpioDirection::input) {
        return false;
    }
    if (value != channel->value) {
        channel->edges = static_cast<std::uint8_t>(
            channel->edges |
            (value ? gpio_edge_rising : gpio_edge_falling));
        channel->value = value;
    }
    return true;
}

std::optional<bool> GpioBank::read(const std::uint8_t logical_id) const {
    const auto* channel = find(logical_id);
    if (channel == nullptr || !channel->configured) return std::nullopt;
    return channel->value;
}

std::optional<std::uint8_t> GpioBank::edges(const std::uint8_t logical_id,
                                            const std::uint8_t clear_mask) {
    auto* channel = find_mutable(logical_id);
    if (channel == nullptr || !channel->configured ||
        channel->direction != GpioDirection::input) {
        return std::nullopt;
    }
    const std::uint8_t result = channel->edges;
    channel->edges = static_cast<std::uint8_t>(
        channel->edges & static_cast<std::uint8_t>(~clear_mask));
    return result;
}

void GpioBank::restore_safe() {
    for (std::size_t index = 0U; index < size_; ++index) {
        auto& channel = channels_[index];
        channel.direction = GpioDirection::safe;
        channel.pull = GpioPull::none;
        channel.value = channel.descriptor.safe_value;
        channel.edges = 0U;
        channel.configured = false;
    }
}

GpioChannelState* GpioBank::find_mutable(const std::uint8_t logical_id) {
    for (std::size_t index = 0U; index < size_; ++index) {
        if (channels_[index].descriptor.logical_id == logical_id) {
            return &channels_[index];
        }
    }
    return nullptr;
}

KeyboardQueue& ControllerModel::keyboard() {
    return keyboard_;
}

const KeyboardQueue& ControllerModel::keyboard() const {
    return keyboard_;
}

RtcClock& ControllerModel::rtc() {
    return rtc_;
}

const RtcClock& ControllerModel::rtc() const {
    return rtc_;
}

PowerController& ControllerModel::power() {
    return power_;
}

const PowerController& ControllerModel::power() const {
    return power_;
}

DebouncedHeadphone& ControllerModel::headphone() {
    return headphone_;
}

const DebouncedHeadphone& ControllerModel::headphone() const {
    return headphone_;
}

PmuTelemetry& ControllerModel::telemetry() {
    return telemetry_;
}

const PmuTelemetry& ControllerModel::telemetry() const {
    return telemetry_;
}

GpioBank& ControllerModel::gpio() {
    return gpio_;
}

const GpioBank& ControllerModel::gpio() const {
    return gpio_;
}

bool ControllerModel::commit_soft_off(const std::uint32_t token,
                                      const std::uint64_t now_milliseconds) {
    const bool committed = power_.commit_soft_off(token, now_milliseconds);
    if (committed) gpio_.restore_safe();
    return committed;
}

void ControllerModel::force_hard_off(const PowerReason reason) {
    power_.force_hard_off(reason);
    rtc_.invalidate();
    gpio_.restore_safe();
}

void ControllerModel::true_power_loss() {
    power_.force_hard_off(PowerReason::pmu_fault);
    rtc_.invalidate();
    keyboard_.reset();
    telemetry_.reset();
    gpio_.restore_safe();
}

void ControllerModel::controller_reset(const bool pico_powered,
                                       const std::uint32_t token_seed,
                                       const bool retain_rtc) {
    keyboard_.reset();
    if (!retain_rtc) rtc_.invalidate();
    power_.controller_reset(pico_powered, token_seed);
    headphone_ = {};
    telemetry_.reset();
    gpio_.restore_safe();
}

}  // namespace picoos::stm32
