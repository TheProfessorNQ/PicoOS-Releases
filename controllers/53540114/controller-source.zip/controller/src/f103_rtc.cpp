#include <picoos/stm32/f103_rtc.hpp>

namespace picoos::stm32 {
namespace {
constexpr std::uint32_t lse_on = 1U, lse_ready = 2U, rtc_lse = 0x100U,
    rtc_select = 0x300U, rtc_enable = 0x8000U, rsf = 8U, cnf = 16U, rtoff = 32U;
constexpr std::uint32_t marker = 0x5043U, version = 0x0101U;
}

void F103Rtc::fail() {
    if (owned_) write(RtcRegister::marker, 0);
    snapshot_ = {}; snapshot_.oscillator = 2;
    state_ = State::fault;
}

bool F103Rtc::counter(std::uint32_t& value) const {
    for (unsigned attempt = 0; attempt != 3; ++attempt) {
        const auto high = read(RtcRegister::cnth) & 0xffffU;
        const auto low = read(RtcRegister::cntl) & 0xffffU;
        if (high == (read(RtcRegister::cnth) & 0xffffU)) {
            value = (high << 16U) | low;
            return true;
        }
    }
    return false;
}

PicoOsStm32Status F103Rtc::request(bool valid, std::uint64_t seconds) {
    if (valid && (seconds < first_second || seconds > last_second))
        return PICOOS_STM32_STATUS_INVALID_ARGUMENT;
    if (state_ == State::fault) return PICOOS_STM32_STATUS_INTERNAL_ERROR;
    if (state_ != State::ready || snapshot_.pending) return PICOOS_STM32_STATUS_BUSY;
    target_ = static_cast<std::uint32_t>(seconds);
    target_valid_ = valid;
    snapshot_.pending = true;
    return PICOOS_STM32_STATUS_OK; // Accepted; RTC_READ.pending clears on completion.
}

void F103Rtc::poll(std::uint32_t now) {
    if (state_ == State::fault) return;
    if (state_ == State::cold) {
        if (!io_.read || !io_.write) { state_ = State::fault; snapshot_.oscillator = 2; return; }
        write(RtcRegister::apb1enr, read(RtcRegister::apb1enr) | (3U << 27U));
        write(RtcRegister::pwr_cr, read(RtcRegister::pwr_cr) | (1U << 8U));
        const auto domain = read(RtcRegister::bdcr);
        // Never reset the backup domain or switch an already selected source.
        if ((domain & rtc_select) != 0 && (domain & rtc_select) != rtc_lse) { fail(); return; }
        owned_ = true;
        write(RtcRegister::bdcr, domain | lse_on);
        transition(State::oscillator, now);
        return;
    }
    if (state_ == State::oscillator) {
        if ((read(RtcRegister::bdcr) & lse_ready) == 0) {
            if (now - since_ >= 5000U) fail();
            return;
        }
        write(RtcRegister::bdcr, read(RtcRegister::bdcr) | rtc_lse | rtc_enable);
        write(RtcRegister::crl, read(RtcRegister::crl) & ~rsf);
        transition(State::sync, now);
        return;
    }
    if ((read(RtcRegister::bdcr) & (lse_ready | rtc_select | rtc_enable)) !=
        (lse_ready | rtc_lse | rtc_enable)) { fail(); return; }
    if (state_ == State::sync) {
        if ((read(RtcRegister::crl) & (rsf | rtoff)) != (rsf | rtoff)) {
            if (now - since_ >= 100U) fail();
            return;
        }
        if (read(RtcRegister::marker) == marker && read(RtcRegister::version) == version &&
            read(RtcRegister::prlh) == 0 && read(RtcRegister::prll) == 32767U &&
            read(RtcRegister::crh) == 0 && (read(RtcRegister::crl) & cnf) == 0) {
            std::uint32_t retained{};
            if (!counter(retained) || retained < first_second || retained > last_second ||
                (read(RtcRegister::crl) & 4U) != 0) { fail(); return; }
            snapshot_.seconds = retained;
            snapshot_.valid = true;
            snapshot_.oscillator = 1;
            transition(State::ready, now);
        } else {
            write(RtcRegister::marker, 0);
            transition(State::configure, now);
        }
        return;
    }
    if (state_ == State::configure || state_ == State::write) {
        if ((read(RtcRegister::crl) & rtoff) == 0) {
            if (now - since_ >= 100U) fail();
            return;
        }
        const bool configuring = state_ == State::configure;
        write(RtcRegister::crl, read(RtcRegister::crl) | cnf);
        if (configuring) {
            write(RtcRegister::crh, 0); // No alarms, second or overflow interrupts.
            write(RtcRegister::prlh, 0); write(RtcRegister::prll, 32767U);
        } else {
            write(RtcRegister::cnth, target_ >> 16U);
            write(RtcRegister::cntl, target_ & 0xffffU);
        }
        write(RtcRegister::crl, read(RtcRegister::crl) & ~(cnf | 4U));
        transition(configuring ? State::configured : State::written, now);
        return;
    }
    if (state_ == State::configured || state_ == State::written) {
        if ((read(RtcRegister::crl) & rtoff) == 0) {
            if (now - since_ >= 100U) fail();
            return;
        }
        if (state_ == State::written) {
            std::uint32_t observed{};
            if (!counter(observed) || observed < target_ || observed - target_ > 1U) { fail(); return; }
            write(RtcRegister::version, version);
            write(RtcRegister::marker, marker); // Commit only after peripheral completion.
            snapshot_.valid = true;
        }
        snapshot_.pending = false;
        transition(State::ready, now);
    }
    if (state_ == State::ready) {
        snapshot_.oscillator = 1;
        if (snapshot_.pending) {
            write(RtcRegister::marker, 0); snapshot_.valid = false; snapshot_.seconds = 0;
            if (target_valid_) transition(State::write, now);
            else snapshot_.pending = false;
            return;
        }
        if (snapshot_.valid) {
            std::uint32_t value{};
            if (!counter(value) || value < first_second || value > last_second ||
                (read(RtcRegister::crl) & 4U) != 0) { fail(); return; }
            snapshot_.seconds = value;
        }
    }
}
}
