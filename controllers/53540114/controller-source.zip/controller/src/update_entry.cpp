#include <picoos/stm32/update_entry.hpp>
namespace picoos::stm32::update {
bool ApplicationMaintenance::receive(const std::uint8_t* request, std::size_t size, std::uint8_t* reply, std::uint32_t now) {
    if (!request || !reply || size != packet_bytes || request[0] != 'P' || request[1] != 'U' || request[2] != 1 ||
        read32(request + 28) != (crc32(request, 28) ^ 0xFFFFFFFFU)) return false;
    const auto command = request[3]; const auto session = read32(request + 4), argument = read32(request + 8);
    Result result = Result::argument;
    if (session != 0 && read32(request + 12) == app_base && read32(request + 16) == layout_id &&
        read32(request + 20) == device_id && read32(request + 24) == build_) {
        if (command == static_cast<std::uint8_t>(Command::enter) && argument == 0) {
            if (!pending_) { pending_ = true; session_ = session; accepted_ = now; result = Result::ok; }
            else result = session_ == session ? Result::ok : Result::busy;
        } else if (command == rtc_admit_command && argument == 1 && !pending_) {
            rtc_enabled_ = true; result = Result::ok; // reset restores the board's startup policy
        } else if (command == power_admit_command && (argument == 1 || argument == 3) &&
                   rtc_enabled_ && !pending_) {
            power_enabled_ = true;
            stop_enabled_ = argument == 3;
            result = Result::ok;
        }
    }
    for (std::size_t i = 0; i < packet_bytes; ++i) reply[i] = 0;
    reply[0] = 'P'; reply[1] = 'U'; reply[2] = 1; reply[3] = command | 0x80U;
    write32(reply + 4, session); reply[12] = static_cast<std::uint8_t>(result);
    write32(reply + 24, build_); write32(reply + 28, crc32(reply, 28) ^ 0xFFFFFFFFU);
    return true;
}
}
