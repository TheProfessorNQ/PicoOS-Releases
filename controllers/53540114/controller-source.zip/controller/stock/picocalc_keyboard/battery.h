#ifndef BATTERY_H
#define BATTERY_H

void indicator_led_refresh();

void show_bat_segs();

void low_bat();

void start_chg();
void stop_chg();

#endif
