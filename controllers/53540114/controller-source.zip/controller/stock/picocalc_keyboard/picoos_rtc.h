#pragma once
#include <picoos/stm32/f103_rtc.hpp>
picoos::stm32::RtcRegisterIo picoos_rtc_registers();
