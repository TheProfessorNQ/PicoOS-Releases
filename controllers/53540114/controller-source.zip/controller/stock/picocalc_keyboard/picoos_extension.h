#ifndef PICOOS_STOCK_EXTENSION_GLUE_H
#define PICOOS_STOCK_EXTENSION_GLUE_H
#include <Arduino.h>
#include <picoos/stm32/stock_extension.hpp>

// Restores the prior interrupt mask, including when called from an ISR or an
// already-guarded FIFO operation. Never blindly enables interrupts on exit.
class PicoosIrqGuard {
public:
    PicoosIrqGuard() : prior_(__get_PRIMASK()) { __disable_irq(); }
    ~PicoosIrqGuard() { __set_PRIMASK(prior_); }
private:
    const uint32_t prior_;
};

void picoos_key_sample(uint8_t id, bool pressed);
bool picoos_host_handles_battery_key();
void picoos_note_legacy_fifo_read();
void picoos_scan_complete(uint32_t now, uint8_t lcd, uint8_t keyboard);
uint8_t picoos_extension_request(const uint8_t* bytes, uint8_t size, uint8_t* response);
uint8_t picoos_extension_identify(uint8_t* response);
void picoos_bus_recovered();
void picoos_services_poll();
bool picoos_power_wake();
bool picoos_power_request();
bool picoos_power_suspended();
bool picoos_power_available();
void picoos_power_diagnostic(uint8_t* response);
void picoos_power_poll(picoos::stm32::PowerController& power, bool admitted, bool stop);
#endif
