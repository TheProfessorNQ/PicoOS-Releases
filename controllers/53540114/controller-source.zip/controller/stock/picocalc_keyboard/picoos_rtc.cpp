#include "picoos_rtc.h"
#include <Arduino.h>

namespace {
volatile std::uint32_t& reg(picoos::stm32::RtcRegister id) {
    using R = picoos::stm32::RtcRegister;
    switch (id) {
        case R::apb1enr: return RCC->APB1ENR;
        case R::pwr_cr: return PWR->CR;
        case R::bdcr: return RCC->BDCR;
        case R::crh: return RTC->CRH;
        case R::crl: return RTC->CRL;
        case R::prlh: return RTC->PRLH;
        case R::prll: return RTC->PRLL;
        case R::cnth: return RTC->CNTH;
        case R::cntl: return RTC->CNTL;
        case R::marker: return BKP->DR1;
        case R::version: return BKP->DR2;
    }
    return BKP->DR1; // Closed enum, never decoded from a wire value.
}
std::uint32_t read(void*, picoos::stm32::RtcRegister id) { return reg(id); }
void write(void*, picoos::stm32::RtcRegister id, std::uint32_t value) { reg(id) = value; }
}
picoos::stm32::RtcRegisterIo picoos_rtc_registers() { return {nullptr, read, write}; }
