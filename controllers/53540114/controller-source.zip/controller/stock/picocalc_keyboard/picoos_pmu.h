#pragma once
// The pinned XPowers Arduino fallback logs to Serial (USART2 on this board).
// PicoCalc initializes Serial1 only. Logging to the unopened USART2 fills its
// TX ring and then waits forever, including inside enableIRQ during shutdown.
// Keep PMU operations independent of debug output, consistently in every TU.
// Stock explicit Serial1 diagnostics and all PMU/charging operations remain.
#pragma push_macro("log_e")
#pragma push_macro("log_i")
#pragma push_macro("log_d")
#undef log_e
#undef log_i
#undef log_d
#define log_e(...) ((void)0)
#define log_i(...) ((void)0)
#define log_d(...) ((void)0)
#define XPOWERS_CHIP_AXP2101
#include "XPowersLib.h"
#pragma pop_macro("log_d")
#pragma pop_macro("log_i")
#pragma pop_macro("log_e")
