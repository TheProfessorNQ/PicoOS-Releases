#include <Arduino.h>

// Interpose only the event handler in this stock-derived build. The pinned
// F1 HAL's BTF handlers decrement XferCount but omit the completion transition
// made by RXNE/TXE. Arduino Wire receives one byte per sequential request; a
// last byte handled through BTF otherwise leaves it at count0/BUSY_RX_LISTEN,
// unable to arm the next byte. No upstream package files are modified.
extern "C" void __real_HAL_I2C_EV_IRQHandler(I2C_HandleTypeDef* handle);
extern "C" void __wrap_HAL_I2C_EV_IRQHandler(I2C_HandleTypeDef* handle) {
    __real_HAL_I2C_EV_IRQHandler(handle);
    if (handle->Mode != HAL_I2C_MODE_SLAVE || handle->ErrorCode != HAL_I2C_ERROR_NONE) return;
    // When STOP and the last RX byte co-pend, HAL drains the byte and calls
    // Wire's RX completion. Wire rearms one-byte reception; HAL then skips
    // ListenCplt because state is BUSY_RX_LISTEN again, leaving ACK disabled.
    // That exact state was captured on CKS hardware. Finish the already-
    // stopped transaction, without counting the received byte a second time.
    if (handle->State == HAL_I2C_STATE_BUSY_RX_LISTEN && handle->XferCount == 1 &&
        (handle->Instance->CR1 & I2C_CR1_ACK) == 0) {
        __HAL_I2C_DISABLE_IT(handle, I2C_IT_EVT | I2C_IT_BUF | I2C_IT_ERR);
        handle->XferOptions = 0xFFFF0000U; // pinned HAL's private I2C_NO_OPTION_FRAME
        handle->PreviousState = 0;
        handle->State = HAL_I2C_STATE_READY;
        handle->Mode = HAL_I2C_MODE_NONE;
#if USE_HAL_I2C_REGISTER_CALLBACKS == 1
        handle->ListenCpltCallback(handle);
#else
        HAL_I2C_ListenCpltCallback(handle);
#endif
        return;
    }
    if (handle->XferCount != 0) return;
    const auto state = handle->State;
    if (state != HAL_I2C_STATE_BUSY_RX_LISTEN && state != HAL_I2C_STATE_BUSY_TX_LISTEN) return;
    // Do not sample SR1/SR2 here: their read sequence can consume a new ADDR.
    // Mirror the pinned HAL's TXE/RXNE completion, once, after its data access.
    __HAL_I2C_DISABLE_IT(handle, I2C_IT_BUF);
    constexpr uint32_t state_mask = (HAL_I2C_STATE_BUSY_TX | HAL_I2C_STATE_BUSY_RX) & ~HAL_I2C_STATE_READY;
    handle->PreviousState = ((state == HAL_I2C_STATE_BUSY_RX_LISTEN ?
        HAL_I2C_STATE_BUSY_RX : HAL_I2C_STATE_BUSY_TX) & state_mask) | HAL_I2C_MODE_SLAVE;
    handle->State = HAL_I2C_STATE_LISTEN;
    if (state == HAL_I2C_STATE_BUSY_RX_LISTEN) {
#if USE_HAL_I2C_REGISTER_CALLBACKS == 1
        handle->SlaveRxCpltCallback(handle);
#else
        HAL_I2C_SlaveRxCpltCallback(handle);
#endif
    } else {
#if USE_HAL_I2C_REGISTER_CALLBACKS == 1
        handle->SlaveTxCpltCallback(handle);
#else
        HAL_I2C_SlaveTxCpltCallback(handle);
#endif
    }
}
