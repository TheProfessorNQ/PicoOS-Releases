#include "picoos_extension.h"
#include <cstring>
#if defined(PICOOS_CONTROLLER_RESIDENT)
#include "picoos_pmu.h"
#include "reg.h"
#include "backlight.h"
#include "fifo.h"
#include <picoos/stm32/power_sequence.hpp>

extern XPowersPMU PMU;
extern uint8_t pmu_online;
extern volatile bool pmu_flag;
extern HardwareSerial Serial1;
void picoos_power_capability(bool enabled);

namespace {
picoos::stm32::PowerSequence sequence;
picoos::stm32::PowerController* active_power;
uint8_t lcd, keyboard;
uint8_t checkpoint;
bool last_admitted, last_stop;
struct Board {
    bool quiesce() {
        checkpoint = 1;
        if (pmu_online != 1) return false;
        checkpoint = 2;
        if (!PMU.enableIRQ(XPOWERS_AXP2101_WARNING_LEVEL1_IRQ)) return false;
        checkpoint = 3;
        lcd = reg_get_value(REG_ID_BKL); keyboard = reg_get_value(REG_ID_BK2);
        analogWrite(PA8, 0); analogWrite(PC8, 0);
        digitalWrite(PA14, LOW);
        // Preserve all factory IRQs; add the already-configured critical
        // battery threshold so STOP never hides the stock low-battery action.
        checkpoint = 4;
        Serial1.flush();
        checkpoint = 5;
        return true;
    }
    bool pico_power(bool on) { checkpoint = on ? 7 : 6; digitalWrite(PA13, on ? HIGH : LOW); return digitalRead(PA13) == (on ? HIGH : LOW); }
    bool restore() {
        fifo_flush();
        analogWriteFrequency(10000);
        analogWrite(PA8, lcd); analogWrite(PC8, keyboard);
        return true;
    }
    bool stop() {
        // PC9/EXTI is the stock PMU interrupt. A pending interrupt must be
        // serviced before sleeping; every other wake simply re-enters STOP.
        if (pmu_flag || digitalRead(PC9) == LOW) return true;
        const auto prior = __get_PRIMASK();
        __disable_irq();
        if (pmu_flag || digitalRead(PC9) == LOW) { __set_PRIMASK(prior); return true; }
        HAL_SuspendTick();
        const auto cr = RCC->CR;
        const auto cfgr = RCC->CFGR;
        HAL_PWR_EnterSTOPMode(PWR_LOWPOWERREGULATOR_ON, PWR_STOPENTRY_WFI);
        // STOP wakes on HSI. Restore the existing clock source with bounded
        // register waits, without HAL timeouts while SysTick is suspended.
        auto wait = [](volatile uint32_t& reg, uint32_t mask, uint32_t value) {
            for (unsigned i = 0; i < 1000000U; ++i) if ((reg & mask) == value) return true;
            return false;
        };
        bool ok = true;
        if (cr & RCC_CR_HSEON) { RCC->CR |= RCC_CR_HSEON; ok = wait(RCC->CR, RCC_CR_HSERDY, RCC_CR_HSERDY); }
        if (ok && (cr & RCC_CR_PLLON)) { RCC->CR |= RCC_CR_PLLON; ok = wait(RCC->CR, RCC_CR_PLLRDY, RCC_CR_PLLRDY); }
        if (ok) { RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | (cfgr & RCC_CFGR_SW); ok = wait(RCC->CFGR, RCC_CFGR_SWS, (cfgr & RCC_CFGR_SW) << 2U); }
        HAL_ResumeTick();
        __set_PRIMASK(prior);
        if (!ok) { __DSB(); NVIC_SystemReset(); }
        return ok;
    }
} board;
}
void picoos_power_poll(picoos::stm32::PowerController& power, bool admitted, bool stop) {
    active_power = &power;
    last_admitted = admitted; last_stop = stop;
    picoos_power_capability(admitted && picoos_power_available());
    sequence.poll(power, board, admitted && pmu_online == 1, stop, millis());
}
bool picoos_power_wake() {
    // Publish the wake state atomically with respect to I2C power requests.
    // restore() uses only GPIO/PWM, never PMU I2C or a timed wait.
    const PicoosIrqGuard guard;
    return active_power && sequence.wake(*active_power, board);
}
bool picoos_power_suspended() { return sequence.suspended(); }
bool picoos_power_available() { return pmu_online == 1 && sequence.phase() != picoos::stm32::PowerSequence::Phase::failed; }
void picoos_power_diagnostic(uint8_t* response) {
    // Private read-only ISR snapshot; no PMU transaction or destructive flags.
    memset(response, 0, 32);
    response[0]='P'; response[1]='D'; response[2]=1;
    response[3]=static_cast<uint8_t>(sequence.phase()); response[4]=checkpoint;
    response[5]=pmu_online; response[6]=last_admitted; response[7]=last_stop;
    response[8]=active_power ? static_cast<uint8_t>(active_power->state()) : 0xff;
    response[9]=(GPIOA->ODR >> 13U) & 1U; response[10]=(GPIOA->IDR >> 13U) & 1U;
    picoos_stm32_write_u32_le(response+12,millis());
    picoos_stm32_write_u32_le(response+16,GPIOA->CRH);
    picoos_stm32_write_u16_le(response+30,picoos_stm32_crc16_ccitt(response,30));
}
#else
bool picoos_power_wake() { return false; }
bool picoos_power_suspended() { return false; }
bool picoos_power_available() { return false; }
void picoos_power_diagnostic(uint8_t* response) { memset(response,0,32); }
#endif
