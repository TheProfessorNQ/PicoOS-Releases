#include "picoos_extension.h"
#include "picoos_rtc.h"
#include <picoos/stm32/stock_extension.hpp>
#include <cstring>
#if defined(PICOOS_CONTROLLER_RESIDENT)
#include <picoos/stm32/update_entry.hpp>
#endif

namespace {
picoos::stm32::F103Rtc rtc(picoos_rtc_registers());
#if defined(PICOOS_CONTROLLER_RESIDENT)
picoos::stm32::StockExtension extension;
// RTC retention and ordinary soft-off/wake passed on this board. Enable those
// services every boot; the physical capability still waits for RTC/PMU ready.
// STOP remains disabled and requires its separate, unaccepted test admission.
picoos::stm32::update::ApplicationMaintenance maintenance(
    picoos::stm32::StockExtension::build_identity,
    picoos::stm32::update::ServicePolicy::rtc_soft_off);
bool power_capability{};
#else
picoos::stm32::StockExtension extension(&rtc);
#endif
}

bool picoos_power_request() { const PicoosIrqGuard guard; return extension.request_power_off(); }

void picoos_key_sample(uint8_t id, bool pressed) { extension.sample_key(id, pressed); }
bool picoos_host_handles_battery_key() {
    const PicoosIrqGuard guard;
    return extension.host_handles_battery_key();
}
void picoos_note_legacy_fifo_read() { extension.note_legacy_fifo_read(); }

void picoos_scan_complete(uint32_t now, uint8_t lcd, uint8_t keyboard) {
    const PicoosIrqGuard guard;
    extension.finish_scan(now);
    extension.observe_backlights(lcd, keyboard);
}

void picoos_services_poll() {
    bool admitted = false;
    {
    const PicoosIrqGuard guard;
#if defined(PICOOS_CONTROLLER_RESIDENT)
    extension.power().poll(millis());
    if (maintenance.reset_due(millis())) {
        RCC->APB1ENR |= RCC_APB1ENR_BKPEN | RCC_APB1ENR_PWREN;
        PWR->CR |= PWR_CR_DBP;
        BKP->DR9 = 0x5055U; BKP->DR10 = 0xAFAAU;
        if (BKP->DR9 == 0x5055U && BKP->DR10 == 0xAFAAU) { __DSB(); NVIC_SystemReset(); }
        return;
    }
    if (!maintenance.rtc_enabled()) return;
    extension.attach_rtc(&rtc);
#endif
    rtc.poll(millis()); // Bounded register steps, never an oscillator/write wait.
#if defined(PICOOS_CONTROLLER_RESIDENT)
    admitted = maintenance.power_enabled() && rtc.snapshot().oscillator == 1 && !rtc.snapshot().pending;
#endif
    }
#if defined(PICOOS_CONTROLLER_RESIDENT)
    // STOP and PMU I2C must run outside the RTC/input critical section.
    picoos_power_poll(extension.power(), admitted, maintenance.stop_enabled());
#else
    static_cast<void>(admitted);
#endif
}

uint8_t picoos_extension_request(const uint8_t* bytes, uint8_t size, uint8_t* response) {
#if defined(PICOOS_CONTROLLER_RESIDENT)
    if (size >= 2 && bytes[0] == 'P' && bytes[1] == 'U') {
        std::memset(response, 0xFF, 32);
        (void)maintenance.receive(bytes, size, response, millis());
        if (maintenance.rtc_enabled()) extension.attach_rtc(&rtc);
        return 32;
    }
#endif
    // ISR reads a coherent RTC snapshot or queues a write; never waits for the
    // peripheral. Only the explicitly admitted board power path is enabled.
    extension.receive(bytes, size, millis());
    const auto count = extension.response_size();
    if (count > PICOOS_STM32_FRAME_MAX_SIZE) return 0;
    std::memset(response, 0, PICOOS_STM32_FRAME_MAX_SIZE);
    std::memcpy(response, extension.response_data(), count);
    return PICOOS_STM32_FRAME_MAX_SIZE;
}

uint8_t picoos_extension_identify(uint8_t* response) {
#if defined(PICOOS_CONTROLLER_RESIDENT)
    const auto size = picoos::stm32::StockExtension::identify(response, 32U, maintenance.rtc_enabled());
    auto caps = picoos_stm32_read_u32_le(response + 8);
    caps |= picoos::stm32::update::updater_capability | picoos::stm32::update::rtc_admission_capability;
    caps |= picoos::stm32::update::power_admission_capability;
    if (power_capability) caps |= PICOOS_STM32_CAPABILITY_SOFT_OFF;
    picoos_stm32_write_u32_le(response + 8, caps);
    return static_cast<uint8_t>(size);
#else
    return static_cast<uint8_t>(picoos::stm32::StockExtension::identify(response, 32U, true));
#endif
}

#if defined(PICOOS_CONTROLLER_RESIDENT)
void picoos_power_capability(bool enabled) { const PicoosIrqGuard guard; power_capability=enabled; extension.enable_power(enabled); }
#endif

void picoos_bus_recovered() {
    const PicoosIrqGuard guard;
    extension.bus_recovered();
}
