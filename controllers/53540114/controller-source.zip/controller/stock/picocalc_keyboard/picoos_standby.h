#pragma once
#include <stdint.h>

// A key held on the first scan after wake stays logically up until released.
// Separate bits allow other keys to work immediately.
template<unsigned Count>
struct PicoosWakeKeys {
    uint8_t held[(Count + 7) / 8]{};
    bool sample(uint8_t id, bool down, bool baseline) {
        uint8_t& bits = held[id / 8];
        const uint8_t mask = 1U << (id % 8);
        if (!down) bits &= ~mask;
        else if (baseline) bits |= mask;
        return down && !(bits & mask);
    }
};

inline bool picoos_battery_only(const uint8_t status[2]) {
    // AXP2101 STATUS1: bit 5 VBUS good, bit 3 battery present.
    // STATUS2 bits 7:5 equal 2 while discharging.
    return (status[0] & 0x28) == 0x08 && (status[1] >> 5) == 2;
}
