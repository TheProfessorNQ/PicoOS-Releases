#include "battery.h"

static unsigned int low_bat_count =0;
static bool indicator_requested_on = true;

void indicator_led_refresh(){
    // LCD zero is PicoOS's explicit suspend blank (normal brightness is >=16).
    // Mask every battery/charge callback too, so periodic updates cannot relight
    // PC13. The PMU's separate charging/low-battery warning LED is untouched.
    const bool dark = reg_get_value(REG_ID_BKL)==0 || picoos_power_suspended();
    digitalWrite(PC13, indicator_requested_on && !dark ? LOW : HIGH);
}

void indicator_led_on(){
    indicator_requested_on = true;
    indicator_led_refresh();
}

void indicator_led_off(){
    indicator_requested_on = false;
    indicator_led_refresh();
}

void flash_one_time(int ts,int restore_status) {
    for(int i=0;i<ts;i++) {
      indicator_led_on();
      delay(400);
      indicator_led_off();
      delay(200);
    }
    indicator_requested_on = restore_status==LOW;
    indicator_led_refresh();
}

void show_bat_segs(){
  if(!PMU.isBatteryConnect()) return;

  int pcnt =  PMU.getBatteryPercent();
  int last_d201_status = indicator_requested_on ? LOW : HIGH;
  
  if(pcnt >0 && pcnt < 33) {
    //show one time
    flash_one_time(1,last_d201_status);
  }else if(pcnt >= 33 && pcnt <66){
    //show 2 times
     flash_one_time(2,last_d201_status);   
  }else if(pcnt >=66 && pcnt <= 100){
    //show 3 times
     flash_one_time(3,last_d201_status);
  }
  
  if(PMU.isCharging()){
    start_chg();
  }

}

void low_bat(){
  int pcnt = PMU.getBatteryPercent();
  if(pcnt >=0 && pcnt <= LOW_BAT_VAL){
    low_bat_count++;
      //This is related to the battery charging and discharging logic. If you're not sure what you're doing, please don't modify it, as it could damage the battery.
    indicator_led_off();      
    if(pcnt <= 1) {//This is related to the battery charging and discharging logic. If you're not sure what you're doing, please don't modify it, as it could damage the battery.
      PMU.setChargingLedMode(XPOWERS_CHG_LED_BLINK_4HZ);
      if(pcnt==0 && low_bat_count >= 4 ) {//This is related to the battery charging and discharging logic. If you're not sure what you're doing, please don't modify it, as it could damage the battery.
        PMU.shutdown();//This is related to the battery charging and discharging logic. If you're not sure what you're doing, please don't modify it, as it could damage the battery.
      }
    }else{
      PMU.setChargingLedMode(XPOWERS_CHG_LED_ON);
    }
  }else{
    low_bat_count = 0;
    indicator_led_on();
    PMU.setChargingLedMode(XPOWERS_CHG_LED_OFF);
  }
}

void start_chg(){
  indicator_led_on();
  PMU.setChargingLedMode(XPOWERS_CHG_LED_BLINK_1HZ);
}

void stop_chg(){
  PMU.setChargingLedMode(XPOWERS_CHG_LED_OFF);
  low_bat();
}
