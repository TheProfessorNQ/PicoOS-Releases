# Stock-derived PicoOS controller

The network release candidate is `0x53540114`. It uses the qualified battery report introduced in build `0x53540113`. The original battery-report candidate is `0x53540113`. Its read-only register and validation
rules are documented in [Hardware](../../docs/HARDWARE.md). The installed November 25
standby build is `0x53540112`. In standby the controller
parks keyboard matrix scanning and disables the speaker amplifiers while it
continues to service the power button, PMU, RTC and I2C.
[Standby details](../../docs/SUSPEND_SERVICE.md)

The November 24 application (`0x53540111`) added a sleep mask
around the PC13 power indicator (LCD-zero or controller soft-off), preserving
the desired awake state. `battery.ino`/`.h` are now intentional derivative files;
the build still compares the stock low-battery and charging handler bodies
byte-for-byte after newline normalization. PMU warning output, cutoff thresholds
and the independent resident updater are unchanged. Focused tests compile the
production battery handlers. See `docs/SUSPEND_SERVICE.md` and the standby proof.

This is a source fork of ClockworkPi PicoCalc commit
`fdcfe2c87a56b6dbcd540e91de1161d483872af9`, directory `Code/picocalc_keyboard`.
The existing downloaded reference remains untouched under `.deps/`.
`upstream.json` records every original source file and SHA-256. Preserve original
source notices; this directory does not change upstream licensing or provenance.

Build from the project root with `scripts/stm32-firmware.ps1 stock-candidate`.
It uses the existing locked STM32duino/XPowers toolchain, checks provenance and
unchanged stock PMU/setup/board support, and writes only to
`build/stm32-stock-candidate*`. It does not flash anything. The first candidate
must pass device-specific factory backup/restore before installation.

## Stock extension and first-contact stage

Current2026-11-23 identities: ordinary stock candidate `0x53540107`, relocated
resident application `0x5354010B`. Older identities in the historical extension
description below are superseded. `picoos_i2c_irq.cpp` wraps the pinned STM32
HAL event handler to supply the missing BTF completion transition/callback and
finish STOP reception after Wire rearming leaves ACK disabled;
upstream files are unchanged. Build verifies the exact HAL hash, and
`scripts/test-stm32-wire-completion.ps1` exercises its actual RXNE/TXE/BTF/STOPF
functions together with the production wrapper. This does not establish
physical controller acceptance; see `docs/CONTROLLER_UPDATE.md`.

- Preserve stock I2C address0x1f, registers0x01..0x0e, legacy key translation/FIFO,
  backlights, battery/charging, headphone, power button and shutdown behavior.
- Validate legacy command lengths before dispatch. Drain and reject overlength
  input rather than wrapping bytes into another command or reading an absent
  write value. Guard FIFO mutations against the I2C ISR, preserving prior IRQ
  masking even for nested calls.
- New non-consuming read0x0f returns12 bytes: `PS`, protocol major/minor,
  little-endian32-bit build identity, little-endian32-bit capability mask.
  Two-byte signature reads are allowed for safe stock/custom detection.
- Framed requests begin0x50/0x43 and use private protocol 1.2.
  Replies are always32 bytes with authenticated encoded length and zero padding.
  Identify/Status/SessionSync/KeyNext/KeySnapshot/Diagnostics are enabled.
  Current build0x53540103 also attaches the real RTC adapter and advertises its
  read/set/invalidate capability. Power, GPIO and extended backlight commands
  return Unsupported. Preserved input-only0x53540102 is a fallback/reference.
  The2026-11-21 batching decision supersedes mandatory input-then-RTC reflashes;
  the next installation target includes the resident updater and staged feature
  admission in one candidate. The separate combined candidate is implemented;
  see `docs/CONTROLLER_UPDATE.md`. `stock-updatable-proof` defines
  PICOOS_CONTROLLER_RESIDENT, relocates this app and uses build0x53540104.
  Its RTC starts disabled until guarded PU command9; reset revokes admission.
  PU command8 queues entry to the independent updater from foreground code,
  never resetting or writing flash in the I2C callback. Ordinary stock-candidate
  output remains build0x53540103 with the earlier RTC behavior.
- Raw key IDs: matrix `row * 8 + column` (0..55,55 unpopulated); direct buttons
  `56 + button` (56..67). Debounce20ms using complete scans and wrap-safe elapsed
  time. Modifier bits0..3 are physical Alt/Ctrl/left Shift/right Shift.
  Bit4 carries this stream's debounced Caps Lock; Status flags bit5 carries
  the same lock state for coherent recovery. Current build identity is0x53540103.
  No extension typematic/sticky policy; PicoOS owns that policy.
- Full held state survives bounded16-event queue overflow, which is counted.
  Duplicate framed reads replay their reply without popping another key.
  I2C recovery clears protocol replay state, not physical key state.
- The original ten-key stock tracker and matrix ghosting limitations are not
  magically removed. The additive stream sees all populated scan positions;
  hardware rollover/ghosting still needs physical acceptance.

The prepared RP firmware selects this event stream after version/capability
checks; factory controllers still use their FIFO. Sequence/overflow/reset
recovery and existing OS key policy are integrated and host-tested. Neither
image is installed or physically accepted. Actual RTC software and RP clock
integration are now built; oscillator/drift/reset acceptance remains. Graceful
power-off and retained-time wake still require software and electrical work.
Never turn the controller model's `full` profile on in this image: it would
advertise hardware capabilities that have not been connected or validated.

See `docs/STM32_STOCK_ROADMAP.md` for the Wednesday demo target and remaining work.
