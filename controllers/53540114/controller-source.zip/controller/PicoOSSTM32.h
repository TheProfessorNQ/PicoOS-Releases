#ifndef PICOOS_STM32_ARDUINO_DISCOVERY_H
#define PICOOS_STM32_ARDUINO_DISCOVERY_H

// Arduino's library discovery begins from a top-level include. Production code
// should include the namespaced headers directly.
#include <picoos/stm32/hardware.hpp>
#include <picoos/stm32/diagnostic.hpp>
#include <picoos/stm32/transport.hpp>

#endif
