/* Retain every compiled function to measure the full receiver/backend, not
   a garbage-collected empty entry point. There is NO valid reset vector. */
ENTRY(proof_entry)
MEMORY {
  FLASH (rx) : ORIGIN = 0x08000000, LENGTH = 8K
  RAM (rwx) : ORIGIN = 0x20000000, LENGTH = 20K
}
SECTIONS {
  .text : { *(.text*) *(.rodata*) } > FLASH
  .ARM.exidx : { *(.ARM.exidx*) } > FLASH
  .data : { *(.data*) } > RAM AT> FLASH
  .bss (NOLOAD) : { *(.bss*) *(COMMON) } > RAM
  /DISCARD/ : { *(.comment*) *(.note*) }
}
ASSERT(SIZEOF(.text) + SIZEOF(.ARM.exidx) + SIZEOF(.data) <= 8192, "updater exceeds reserved boot area")
