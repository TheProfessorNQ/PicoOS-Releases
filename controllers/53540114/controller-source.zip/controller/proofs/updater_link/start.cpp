// LINK/SIZE PROOF ONLY. Not a bootloader. Never install this ELF on a device.
// No board setup or flash command is executed, even if entered accidentally.
#include <cstddef>
extern "C" {
[[noreturn]] void proof_entry() { for (;;) __asm volatile("wfi"); }
void* memset(void* destination, int value, std::size_t size) {
    auto* bytes = static_cast<unsigned char*>(destination);
    for (std::size_t i = 0; i < size; ++i) bytes[i] = static_cast<unsigned char>(value);
    return destination;
}
void* memcpy(void* destination, const void* source, std::size_t size) {
    auto* out = static_cast<unsigned char*>(destination);
    const auto* in = static_cast<const unsigned char*>(source);
    for (std::size_t i = 0; i < size; ++i) out[i] = in[i];
    return destination;
}
}
