#include <Arduino.h>
#include <PicoOSSTM32.h>
#include <picoos/stm32/self_test.hpp>

#include <array>
#include <cstddef>
#include <cstdint>

namespace {

picoos::stm32::TransportEndpoint endpoint;
volatile std::uint32_t proof_observation;

}  // namespace

void setup() {
    PicoOsStm32Frame request{};
    request.command = PICOOS_STM32_COMMAND_IDENTIFY;
    request.transaction = 1U;
    std::array<std::uint8_t, PICOOS_STM32_FRAME_MAX_SIZE> bytes{};
    std::size_t size{};
    if (picoos_stm32_frame_encode(&request, bytes.data(), bytes.size(), &size) ==
        PICOOS_STM32_CODEC_OK) {
        const auto result = endpoint.receive(bytes.data(), size, millis());
        proof_observation = static_cast<std::uint32_t>(result) |
                            static_cast<std::uint32_t>(endpoint.response_size() << 8U);
    }
    const auto report = picoos::stm32::run_self_test();
    proof_observation ^= report.passed ^ report.failed;
}

void loop() {
    endpoint.server().model().power().poll(millis());
    proof_observation ^= endpoint.server().model().keyboard().snapshot().next_sequence;
    delay(10);
}
