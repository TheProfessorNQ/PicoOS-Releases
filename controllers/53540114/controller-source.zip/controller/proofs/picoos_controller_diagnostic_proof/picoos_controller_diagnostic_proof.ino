#include <Arduino.h>
#include <PicoOSSTM32.h>

#include <array>
#include <cstddef>
#include <cstdint>

namespace {

struct ProofHardware {
    std::uint32_t output_calls{};
};

ProofHardware hardware;

bool proof_milliseconds(void*, std::uint64_t& value) {
    value = millis();
    return true;
}

bool proof_key(void*, std::uint8_t, bool& pressed) {
    pressed = false;
    return true;
}

bool proof_headphone(void*, bool& inserted) {
    inserted = false;
    return true;
}

bool proof_pmu(void*, picoos::stm32::PmuSample& sample) {
    sample = {};
    return true;
}

bool proof_rtc(void* context, bool, std::uint64_t) {
    ++static_cast<ProofHardware*>(context)->output_calls;
    return true;
}

bool proof_backlights(void* context, picoos::stm32::BacklightState) {
    ++static_cast<ProofHardware*>(context)->output_calls;
    return true;
}

bool proof_pico_power(void* context, bool) {
    ++static_cast<ProofHardware*>(context)->output_calls;
    return true;
}

bool proof_action(void* context) {
    ++static_cast<ProofHardware*>(context)->output_calls;
    return true;
}

picoos::stm32::HardwareBindings bindings{
    &hardware,
    picoos::stm32::hardware_capability_keyboard |
        picoos::stm32::hardware_capability_headphone |
        picoos::stm32::hardware_capability_pmu |
        picoos::stm32::hardware_capability_rtc_write |
        picoos::stm32::hardware_capability_backlights |
        picoos::stm32::hardware_capability_pico_power |
        picoos::stm32::hardware_capability_stop |
        picoos::stm32::hardware_capability_hard_shutdown,
    proof_milliseconds,
    proof_key,
    proof_headphone,
    proof_pmu,
    proof_rtc,
    proof_backlights,
    proof_pico_power,
    proof_action,
    proof_action,
};

picoos::stm32::DiagnosticRuntime runtime(bindings);
volatile std::uint32_t proof_observation;

void send(PicoOsStm32Frame& request) {
    std::array<std::uint8_t, PICOOS_STM32_FRAME_MAX_SIZE> bytes{};
    std::size_t size{};
    if (picoos_stm32_frame_encode(&request, bytes.data(), bytes.size(), &size) !=
        PICOOS_STM32_CODEC_OK)
        return;
    const auto result = runtime.receive(bytes.data(), size, millis());
    proof_observation ^= static_cast<std::uint32_t>(result) |
                         static_cast<std::uint32_t>(runtime.response_size() << 8U);
}

}  // namespace

void setup() {
    static_cast<void>(runtime.bootstrap(
        {millis(), 0U, 0xD1A60001U, true, false}));
    static_cast<void>(runtime.poll());

    PicoOsStm32Frame request{};
    request.command = PICOOS_STM32_COMMAND_SESSION_SYNC;
    request.transaction = 0U;
    request.payload_size = 4U;
    picoos_stm32_write_u32_le(request.payload, 0xD1A60001U);
    send(request);

    request = {};
    request.command = PICOOS_STM32_COMMAND_IDENTIFY;
    request.transaction = 1U;
    send(request);

    request = {};
    request.command = PICOOS_STM32_COMMAND_POWER_PREPARE;
    request.transaction = 2U;
    send(request);
    proof_observation ^= hardware.output_calls << 16U;
}

void loop() {
    static_cast<void>(runtime.poll());
    proof_observation ^= hardware.output_calls;
    delay(10);
}
