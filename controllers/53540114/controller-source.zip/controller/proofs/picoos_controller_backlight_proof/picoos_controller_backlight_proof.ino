#include <Arduino.h>
#include <PicoOSSTM32.h>
#include <picocalc/backlights.hpp>

// NON-FLASHABLE link proof. Keep the real adapter in the ELF, but never call
// it or enable its output permission. There is no board firmware integration.
using Write = bool (*)(void*, picoos::stm32::BacklightState);
Write volatile retained_write = picoos::stm32::PicoCalcBacklights::write_callback;
volatile std::uint32_t proof_observation;
picoos::stm32::PicoCalcBacklights backlights;

void setup() {
    proof_observation = retained_write != nullptr ? 1U : 0U;
    proof_observation |= sizeof(backlights) << 8U;
}

void loop() { delay(1000); }
