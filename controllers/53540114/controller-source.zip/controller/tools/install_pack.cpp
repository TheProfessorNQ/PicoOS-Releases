#include "install_image.hpp"
#include <charconv>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string_view>
namespace {
bool read_file(const char* path, std::vector<std::uint8_t>& out) {
    std::error_code error; const auto size = std::filesystem::file_size(path, error);
    if (error || size > 4U * 1024U * 1024U || size == 0) return false;
    out.resize(static_cast<std::size_t>(size)); std::ifstream file(path, std::ios::binary);
    file.read(reinterpret_cast<char*>(out.data()), static_cast<std::streamsize>(out.size()));
    return file && file.peek() == std::char_traits<char>::eof();
}
}
int main(int argc, char** argv) {
    if (argc != 5) { std::cerr << "Usage: controller-install-pack resident.bin application.elf output.bin build-id-hex\n"; return 2; }
    std::error_code error;
    if (std::filesystem::exists(argv[3], error) || error) { std::cerr << "Refusing existing output\n"; return 1; }
    const std::string_view text(argv[4]); std::uint32_t build{};
    const auto parsed = std::from_chars(text.data(), text.data() + text.size(), build, 16);
    std::vector<std::uint8_t> resident, application, image;
    if (parsed.ec != std::errc{} || parsed.ptr != text.data() + text.size() ||
        !read_file(argv[1], resident) || !read_file(argv[2], application) ||
        !picoos::stm32::update::make_install_image(resident, application, build, image)) {
        std::cerr << "Invalid resident/application/layout/build\n"; return 1;
    }
    std::ofstream file(argv[3], std::ios::binary); file.write(reinterpret_cast<const char*>(image.data()), static_cast<std::streamsize>(image.size())); file.close();
    if (!file) { std::filesystem::remove(argv[3], error); std::cerr << "Write failed\n"; return 1; }
    std::cout << "65536-byte INITIAL-INSTALL image. Requires exact-unit factory recovery and board acceptance; not an ordinary update package.\n";
}
