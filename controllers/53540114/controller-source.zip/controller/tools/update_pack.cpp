#include <picoos/stm32/updater.hpp>
#include "update_elf.hpp"
#include <array>
#include <charconv>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string_view>
#include <vector>
using namespace picoos::stm32::update;
int main(int argc, char** argv) {
    if (argc != 4) { std::cerr << "Usage: controller-update-pack relocated.elf output.pcu build-id-hex\n"; return 2; }
    const std::filesystem::path input(argv[1]), output(argv[2]);
    const std::string_view build_text(argv[3]); std::uint32_t build{};
    const auto parsed = std::from_chars(build_text.data(), build_text.data() + build_text.size(), build, 16);
    if (parsed.ec != std::errc{} || parsed.ptr != build_text.data() + build_text.size() || build == 0) {
        std::cerr << "Invalid build identity\n"; return 2;
    }
    std::error_code error;
    const auto length = std::filesystem::file_size(input, error);
    if (error || length > 4U * 1024U * 1024U || length < 52) { std::cerr << "Invalid input size\n"; return 1; }
    if (std::filesystem::exists(output, error) || error) { std::cerr << "Refusing to replace an existing output\n"; return 1; }
    std::vector<std::uint8_t> elf(static_cast<std::size_t>(length)), bytes;
    std::ifstream source(input, std::ios::binary);
    source.read(reinterpret_cast<char*>(elf.data()), static_cast<std::streamsize>(elf.size()));
    if (!source || source.peek() != std::char_traits<char>::eof() || !extract_controller_elf(elf, bytes)) {
        std::cerr << "Not a complete image linked for 0x08002000\n"; return 1;
    }
    const Image image{static_cast<std::uint32_t>(bytes.size()), crc32(bytes.data(), bytes.size()) ^ 0xFFFFFFFFU, build};
    std::array<std::uint8_t, package_header_bytes> header{};
    if (!encode_package_header(image, header.data(), header.size())) return 1;
    std::ofstream destination(output, std::ios::binary | std::ios::out);
    destination.write(reinterpret_cast<const char*>(header.data()), header.size());
    destination.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    destination.close();
    if (!destination) { std::filesystem::remove(output, error); std::cerr << "Package write failed\n"; return 1; }
    std::cout << "Controller application package: " << image.length << " bytes + " << package_header_bytes << " byte header\n"
        << "Not a standalone factory-flash image; requires the matching resident updater.\n";
}
