#pragma once
#include <picoos/stm32/updater.hpp>
#include <algorithm>
#include <span>
#include <vector>

namespace picoos::stm32::update {
// Host packer only. Validate ELF32 load addresses, not just a reset vector that
// can coincidentally fall in both the old and relocated address ranges.
inline bool extract_controller_elf(std::span<const std::uint8_t> elf, std::vector<std::uint8_t>& output) {
    output.clear();
    if (elf.size() < 52 || elf.size() > 4U * 1024U * 1024U || elf[0] != 0x7F || elf[1] != 'E' || elf[2] != 'L' ||
        elf[3] != 'F' || elf[4] != 1 || elf[5] != 1 || elf[6] != 1) return false;
    const auto u16 = [&](std::size_t at) { return static_cast<unsigned>(elf[at]) | (static_cast<unsigned>(elf[at + 1]) << 8U); };
    const auto u32 = [&](std::size_t at) { return read32(elf.data() + at); };
    if (u16(16) != 2 || u16(18) != 40 || u32(20) != 1 || u16(40) != 52 || u16(42) != 32 ||
        u16(44) == 0 || u16(44) > 16) return false;
    const auto table = u32(28), count = u16(44);
    if (table > elf.size() || count * 32U > elf.size() - table) return false;
    std::vector<std::uint8_t> bytes(app_capacity, 0xFF), occupied(app_capacity, 0);
    std::uint32_t end = 0;
    bool vectors = false, entry_executable = false;
    for (unsigned i = 0; i < count; ++i) {
        const std::size_t h = table + i * 32U;
        if (u32(h) != 1) continue; // PT_LOAD only
        const auto offset = u32(h + 4), runtime = u32(h + 8), physical = u32(h + 12);
        const auto file_size = u32(h + 16), memory_size = u32(h + 20), flags = u32(h + 24);
        if (file_size > memory_size || offset > elf.size() || file_size > elf.size() - offset) return false;
        const bool in_ram = runtime >= 0x20000000U && runtime <= 0x20005000U && memory_size <= 0x20005000U - runtime;
        const bool in_flash = runtime >= app_base && runtime <= manifest_base && memory_size <= manifest_base - runtime;
        if ((!in_ram && !in_flash) || (in_ram && (flags & 1U) != 0)) return false;
        if (file_size == 0) { if (!in_ram) return false; continue; }
        if (physical < app_base || physical >= manifest_base || file_size > manifest_base - physical) return false;
        if (in_flash && (physical != runtime || file_size != memory_size)) return false;
        const auto begin = physical - app_base;
        if (physical == app_base && in_flash && file_size >= 256 && (flags & 1U) != 0) vectors = true;
        const auto entry = u32(24) & ~1U;
        if (in_flash && (flags & 1U) != 0 && entry >= runtime && entry - runtime < file_size) entry_executable = true;
        for (std::uint32_t n = 0; n < file_size; ++n) {
            if (occupied[begin + n]) return false;
            occupied[begin + n] = 1; bytes[begin + n] = elf[offset + n];
        }
        end = std::max(end, begin + file_size);
    }
    if (!vectors || !entry_executable || end < 256 || end % 2 != 0 || !valid_vectors(bytes.data(), end) || read32(bytes.data() + 4) != u32(24)) return false;
    // Internal gaps use objcopy's zero-fill convention, not undocumented data.
    for (std::uint32_t n = 0; n < end; ++n) if (!occupied[n]) bytes[n] = 0;
    bytes.resize(end); output = std::move(bytes); return true;
}
}
