#pragma once
#include "update_elf.hpp"
namespace picoos::stm32::update {
// Initial factory-loader image only. Ordinary PU/1 updates never use this path.
inline bool make_install_image(std::span<const std::uint8_t> resident,
                               std::span<const std::uint8_t> application_elf,
                               std::uint32_t build, std::vector<std::uint8_t>& output) {
    output.clear();
    if (resident.size() < 256 || resident.size() > app_base - flash_base || (resident.size() & 1U)) return false;
    const auto stack = read32(resident.data()), reset = read32(resident.data() + 4);
    if (stack <= 0x20000000U || stack > 0x20005000U || (stack & 7U) != 0 ||
        (reset & 1U) == 0 || (reset & ~1U) < flash_base + 256U || (reset & ~1U) >= flash_base + resident.size()) return false;
    std::vector<std::uint8_t> app;
    if (!extract_controller_elf(application_elf, app)) return false;
    const Image image{static_cast<std::uint32_t>(app.size()), crc32(app.data(), app.size()) ^ 0xFFFFFFFFU, build};
    std::uint8_t metadata[32]{};
    if (!encode_committed_manifest(image, metadata, sizeof(metadata))) return false;
    output.assign(65536, 0xFF);
    std::copy(resident.begin(), resident.end(), output.begin());
    std::copy(app.begin(), app.end(), output.begin() + (app_base - flash_base));
    std::copy_n(metadata, sizeof(metadata), output.begin() + (manifest_base - flash_base));
    return true;
}
}
