#include "update_board.hpp"
#include <cstddef>
#include <cstdint>
extern "C" {
extern std::uint32_t _estack, _sidata, _sdata, _edata, _sbss, _ebss;
[[noreturn]] void updater_main();
[[noreturn]] void updater_fault() {
    picoos::stm32::update::recovery_trace("UPD FAULT", *reinterpret_cast<volatile std::uint32_t*>(0xE000ED28U));
    picoos::stm32::update::recovery_reset();
}
[[noreturn]] void updater_reset() {
    auto* source = &_sidata;
    for (auto* destination = &_sdata; destination < &_edata;) *destination++ = *source++;
    for (auto* destination = &_sbss; destination < &_ebss;) *destination++ = 0;
    updater_main();
}
using Entry = void (*)();
#define FAULT updater_fault
__attribute__((section(".isr_vector"), used))
const Entry updater_vectors[64] = {
    reinterpret_cast<Entry>(&_estack), updater_reset,
    FAULT, FAULT, FAULT, FAULT, FAULT, nullptr, nullptr, nullptr, nullptr, FAULT, FAULT, nullptr, FAULT, FAULT,
    FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT,
    FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT,
    FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT, FAULT
};
#undef FAULT
void* memset(void* destination, int value, std::size_t size) {
    auto* out = static_cast<unsigned char*>(destination);
    for (std::size_t i = 0; i < size; ++i) out[i] = static_cast<unsigned char>(value);
    return destination;
}
void* memcpy(void* destination, const void* source, std::size_t size) {
    auto* out = static_cast<unsigned char*>(destination); const auto* in = static_cast<const unsigned char*>(source);
    for (std::size_t i = 0; i < size; ++i) out[i] = in[i];
    return destination;
}
}
