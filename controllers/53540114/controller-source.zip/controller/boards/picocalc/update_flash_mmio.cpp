#include "update_flash_mmio.hpp"
namespace picoos::stm32::update {
namespace {
volatile std::uint32_t& reg(std::uint32_t address) {
    return *reinterpret_cast<volatile std::uint32_t*>(address);
}
std::uint32_t address(FlashRegister r) {
    switch (r) {
    case FlashRegister::key: return 0x40022004U;
    case FlashRegister::status: return 0x4002200CU;
    case FlashRegister::control: return 0x40022010U;
    case FlashRegister::address: return 0x40022014U;
    }
    __builtin_trap();
}
std::uint32_t read_register(void*, FlashRegister r) { return reg(address(r)); }
void write_register(void*, FlashRegister r, std::uint32_t value) { reg(address(r)) = value; }
bool read_memory(void*, std::uint32_t at, std::uint8_t* out, std::size_t count) {
    const auto* source = reinterpret_cast<volatile const std::uint8_t*>(at);
    for (std::size_t i = 0; i < count; ++i) out[i] = source[i];
    return true;
}
void write_halfword(void*, std::uint32_t at, std::uint16_t value) {
    *reinterpret_cast<volatile std::uint16_t*>(at) = value;
}
std::uint32_t ticks(void*) { return reg(0xE0001004U); }
}
void f103_enable_cycle_counter() {
    reg(0xE000EDFCU) = reg(0xE000EDFCU) | (1U << 24U); // DEMCR.TRCENA
    reg(0xE0001004U) = 0;
    reg(0xE0001000U) = reg(0xE0001000U) | 1U; // DWT.CYCCNTENA
}
FlashIo f103_flash_mmio_8mhz() {
    return {nullptr, read_register, write_register, read_memory, write_halfword, ticks, 800000U};
}
std::uint32_t f103_device_id() { return reg(0xE0042000U) & 0xFFFU; }
std::uint16_t f103_flash_kib() { return *reinterpret_cast<volatile const std::uint16_t*>(0x1FFFF7E0U); }
}
