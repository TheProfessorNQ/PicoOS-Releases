#pragma once
#include <picoos/stm32/update_flash.hpp>
namespace picoos::stm32::update {
// Only valid in the planned standalone receiver at reset-default 8 MHz HSI.
// Does not configure PMU, GPIO, I2C, clocks, or enter an update by itself.
FlashIo f103_flash_mmio_8mhz();
std::uint32_t f103_device_id();
std::uint16_t f103_flash_kib();
void f103_enable_cycle_counter();
}
