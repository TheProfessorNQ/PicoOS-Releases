#include <picoos/stm32/update_i2c.hpp>
namespace picoos::stm32::update {
namespace {
volatile std::uint32_t& reg(std::uint32_t address) { return *reinterpret_cast<volatile std::uint32_t*>(address); }
std::uint32_t address(I2cRegister r) {
    switch (r) {
    case I2cRegister::cr1: return 0x40005400U;
    case I2cRegister::cr2: return 0x40005404U;
    case I2cRegister::oar1: return 0x40005408U;
    case I2cRegister::dr: return 0x40005410U;
    case I2cRegister::sr1: return 0x40005414U;
    case I2cRegister::sr2: return 0x40005418U;
    case I2cRegister::ccr: return 0x4000541CU;
    case I2cRegister::trise: return 0x40005420U;
    }
    __builtin_trap();
}
std::uint32_t read(void*, I2cRegister r) { return reg(address(r)); }
void write(void*, I2cRegister r, std::uint32_t value) { reg(address(r)) = value; }
bool lines_idle(void*) { return (reg(0x40010C08U) & 0x300U) == 0x300U; } // PB8/9, no I2C side effects
}
// Caller must establish 8 MHz PCLK1 and safe power before enabling this adapter.
I2cIo f103_update_i2c1_pins() {
    reg(0x40021018U) = reg(0x40021018U) | 1U | (1U << 3U); // AFIO, GPIOB
    reg(0x4002101CU) = reg(0x4002101CU) | (1U << 21U); // I2C1
    // SWJ_CFG is not safely read back on F1. Keep PA13/14 assigned to the
    // board's power outputs while remapping I2C1, rather than restoring SWJ.
    reg(0x40010004U) = (reg(0x40010004U) & ~0x07000000U) | 0x04000002U;
    reg(0x40010C04U) = (reg(0x40010C04U) & ~0xFFU) | 0xEEU; // PB8/9 AF open-drain
    return {nullptr, read, write, lines_idle};
}
}
