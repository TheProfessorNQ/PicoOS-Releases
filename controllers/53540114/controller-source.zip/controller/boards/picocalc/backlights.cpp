#include "backlights.hpp"

#include <Arduino.h>

#if !defined(STM32F103xB)
#error "PicoCalc backlights require the pinned STM32F103R8 target"
#endif

namespace picoos::stm32 {
namespace {

bool owns_timer(HardwareTimer& timer, TIM_TypeDef* instance) {
    const auto* owner = HardwareTimer_Handle[get_timer_index(instance)];
    return owner != nullptr && owner->__this == &timer;
}

void force_low(HardwareTimer& timer, PinName pin) {
    // Disconnect AF first, with the output latch already low. Do not call
    // analogWrite/pinMode: their timer bookkeeping can delete timer objects.
    digitalWriteFast(pin, LOW);
    pin_function(pin, STM_PIN_DATA(STM_MODE_OUTPUT_PP, GPIO_NOPULL, 0));
    timer.pause();
}

}  // namespace

bool PicoCalcBacklights::initialize() {
    if (initialized_) return true;
    // Never commandeer a timer already owned by another board service.
    if (HardwareTimer_Handle[get_timer_index(TIM1)] != nullptr ||
        HardwareTimer_Handle[get_timer_index(TIM3)] != nullptr) return false;
    // Check the actual pinned variant's mapping before touching any output.
    if (pinmap_peripheral(PA_8, PinMap_TIM) != TIM1 ||
        STM_PIN_CHANNEL(pinmap_function(PA_8, PinMap_TIM)) != 1U ||
        pinmap_peripheral(PC_8, PinMap_TIM) != TIM3 ||
        STM_PIN_CHANNEL(pinmap_function(PC_8, PinMap_TIM)) != 3U) return false;
    lcd_.setup(TIM1);
    keyboard_.setup(TIM3);
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    force_low(lcd_, PA_8);
    force_low(keyboard_, PC_8);
    initialized_ = true;
    return true;
}

bool PicoCalcBacklights::write(BacklightState levels) {
    if (!allow_outputs_ || !initialize()) return false;
    return write_backlight_pair(this, write_pwm, levels);
}

bool PicoCalcBacklights::write_callback(void* context, BacklightState levels) {
    return context != nullptr &&
           static_cast<PicoCalcBacklights*>(context)->write(levels);
}

bool PicoCalcBacklights::write_pwm(void* context, BacklightChannel channel,
                                  std::uint8_t duty) {
    auto& self = *static_cast<PicoCalcBacklights*>(context);
    const bool is_lcd = channel == BacklightChannel::lcd;
    auto& timer = is_lcd ? self.lcd_ : self.keyboard_;
    auto* instance = is_lcd ? TIM1 : TIM3;
    const PinName pin = is_lcd ? PA_8 : PC_8;
    const std::uint32_t timer_channel = is_lcd ? 1U : 3U;
    if (!owns_timer(timer, instance)) return false;

    force_low(timer, pin);
    if (duty == 0U) {
        // Static push-pull low, with the timer stopped; no minimum brightness
        // clamp and no wait for a pending PWM preload/update event.
        return digitalReadFast(pin) == LOW &&
               (instance->CR1 & TIM_CR1_CEN) == 0U;
    }
    timer.setOverflow(backlight_pwm_hz, HERTZ_FORMAT);
    timer.setCaptureCompare(timer_channel, 0U, TICK_COMPARE_FORMAT);
    timer.setMode(timer_channel, TIMER_OUTPUT_COMPARE_PWM1, pin);
    timer.setCaptureCompare(timer_channel, duty, RESOLUTION_8B_COMPARE_FORMAT);
    timer.refresh();
    timer.resume();

    const std::uint32_t period = instance->ARR + 1U;
    const std::uint32_t compare = is_lcd ? instance->CCR1 : instance->CCR3;
    const std::uint32_t enable = is_lcd ? TIM_CCER_CC1E : TIM_CCER_CC3E;
    const bool ok = period > 1U && period <= 65'536U &&
        compare == period * duty / 255U &&
        timer.getTimerClkFreq() / timer.getPrescaleFactor() / period == backlight_pwm_hz &&
        (instance->CR1 & TIM_CR1_CEN) != 0U &&
        (instance->CCER & enable) != 0U &&
        (!is_lcd || (instance->BDTR & TIM_BDTR_MOE) != 0U);
    if (!ok) force_low(timer, pin);
    // Register acceptance is not a measurement of light output or current.
    return ok;
}

}  // namespace picoos::stm32
