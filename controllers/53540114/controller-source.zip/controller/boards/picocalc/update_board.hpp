#pragma once
#include <picoos/stm32/update_power.hpp>
namespace picoos::stm32::update {
bool recovery_clock();
// Bounded, transmit-only UART1 diagnostics through the factory programming port.
void recovery_trace(const char* message, std::uint32_t value = 0);
void recovery_trace_pmu_done();
void recovery_outputs(bool pico_enabled);
PowerIo recovery_pmu_bus();
std::uint32_t recovery_milliseconds();
bool recovery_requested();
[[noreturn]] void recovery_jump(std::uint32_t stack, std::uint32_t reset);
[[noreturn]] void recovery_reset();
}
