ENTRY(updater_reset)
MEMORY {
  FLASH (rx) : ORIGIN = 0x08000000, LENGTH = 8K
  RAM (rwx) : ORIGIN = 0x20000000, LENGTH = 20K
}
_estack = ORIGIN(RAM) + LENGTH(RAM);
SECTIONS {
  .isr_vector : { KEEP(*(.isr_vector)) } > FLASH
  .text : { *(.text*) *(.rodata*) } > FLASH
  .ARM.exidx : { *(.ARM.exidx*) } > FLASH
  .data : { . = ALIGN(4); _sdata = .; *(.data*) . = ALIGN(4); _edata = .; } > RAM AT> FLASH
  _sidata = LOADADDR(.data);
  .bss (NOLOAD) : { . = ALIGN(4); _sbss = .; *(.bss*) *(COMMON) . = ALIGN(4); _ebss = .; } > RAM
  /DISCARD/ : { *(.comment*) *(.note*) }
}
ASSERT(SIZEOF(.isr_vector) == 256, "reset vector size")
ASSERT(LOADADDR(.data) + SIZEOF(.data) <= 0x08002000, "resident image crosses application")
ASSERT(_ebss <= _estack - 4096, "resident stack reserve")
