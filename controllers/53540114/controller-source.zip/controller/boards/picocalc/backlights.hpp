#ifndef PICOOS_STM32_PICOCALC_BACKLIGHTS_HPP
#define PICOOS_STM32_PICOCALC_BACKLIGHTS_HPP

#include <HardwareTimer.h>
#include <picoos/stm32/backlight.hpp>

namespace picoos::stm32 {

// F103R8 / PicoCalc V2.0. Exclusive ownership of TIM1 and TIM3 is required.
// Construct for the lifetime of the firmware. Construction has no pin/timer
// side effects; output remains disabled unless explicitly opted in.
class PicoCalcBacklights final {
public:
    explicit PicoCalcBacklights(bool allow_outputs = false)
        : allow_outputs_(allow_outputs) {}
    PicoCalcBacklights(const PicoCalcBacklights&) = delete;
    PicoCalcBacklights& operator=(const PicoCalcBacklights&) = delete;

    [[nodiscard]] bool write(BacklightState levels);
    // May be bound directly if HardwareBindings.context points to this object;
    // a composite board context should forward through its own callback.
    static bool write_callback(void* context, BacklightState levels);

private:
    [[nodiscard]] bool initialize();
    static bool write_pwm(void* context, BacklightChannel channel,
                          std::uint8_t duty);
    HardwareTimer lcd_{};
    HardwareTimer keyboard_{};
    bool allow_outputs_{};
    bool initialized_{};
};

}  // namespace picoos::stm32

#endif
