// Separate resident image, never linked into the ordinary keyboard application.
#include "update_board.hpp"
#include "update_flash_mmio.hpp"
#include <picoos/stm32/update_i2c.hpp>
namespace {
using namespace picoos::stm32::update;
struct GuardedFlash {
    Flash inner;
    RecoveryPower& power;
    static bool read(void* p, std::uint32_t at, std::uint8_t* out, std::size_t n) {
        auto& f = *static_cast<GuardedFlash*>(p); return f.inner.read(f.inner.context, at, out, n);
    }
    static bool erase(void* p, std::uint32_t at) {
        auto& f = *static_cast<GuardedFlash*>(p);
        return f.power.healthy() && f.inner.erase_page(f.inner.context, at);
    }
    static bool program(void* p, std::uint32_t at, std::uint16_t value) {
        auto& f = *static_cast<GuardedFlash*>(p);
        return f.power.healthy() && f.inner.program_halfword(f.inner.context, at, value);
    }
    Flash interface() { return {this, read, erase, program}; }
};
}
extern "C" [[noreturn]] void updater_main() {
    if (!recovery_clock()) for (;;) {
        recovery_trace("UPD clock blocked");
        // This failure path must not depend on the failed time source.
        for (unsigned n = 0; n < 1000000; ++n) __asm volatile("nop");
    }
    recovery_trace("UPD clock ready");
    recovery_outputs(false);
    RecoveryPower power(recovery_pmu_bus());
    while (!power.initialize()) {
        recovery_trace("UPD PMU blocked", power.shutting_down() ? 1 : 0);
        const auto start = recovery_milliseconds();
        while (recovery_milliseconds() - start < 1000) {}
        if (power.shutting_down()) for (;;) { (void)power.poll(recovery_milliseconds()); }
    }
    recovery_trace_pmu_done();
    recovery_trace("UPD PMU ready");
    // CPI2.0 exact-unit photograph and capacity register, 2026-11-23.
    // See docs/STM32_RECOVERY.md; this does not broaden the update address range.
    F103Flash device(f103_flash_mmio_8mhz(), f103_device_id(), f103_flash_kib(),
                     FlashPart::cks32f103rb);
    GuardedFlash guarded{device.interface(), power};
    Receiver receiver(guarded.interface());
    I2cReceiver bus(f103_update_i2c1_pins(), receiver);
    if (!bus.initialize_8mhz()) {
        recovery_trace("UPD I2C blocked");
        for (;;) { (void)power.poll(recovery_milliseconds()); }
    }
    const bool forced = recovery_requested();
    if (forced) receiver.hold();
    const bool initial_valid = bootable(guarded.interface());
    recovery_trace("UPD image valid", initial_valid ? 1 : 0);
    recovery_outputs(true); // independent of a valid keyboard application
    const auto powered_at = recovery_milliseconds();
    std::uint32_t power_at = powered_at, boot_at = 0;
    bool boot_pending = false;
    for (;;) {
        const auto now = recovery_milliseconds();
        // No blocking UART trace in the live polled bus loop. Even at10kHz
        // it can span the master's STOP-to-next-address interval.
        if (now - power_at >= 50) {
            power_at = now; (void)power.poll(now);
            if (power.shutting_down()) recovery_outputs(false);
        }
        if (!power.healthy()) continue; // no bus dispatch or flash mutation
        bus.poll();
        if (bus.idle()) receiver.poll();
        if (receiver.boot_requested()) {
            if (!boot_pending) { boot_pending = true; boot_at = now; }
        } else boot_pending = false;
        const bool ordinary = initial_valid && !receiver.held() && receiver.state() == State::idle && now - powered_at >= 3000;
        const bool explicit_boot = boot_pending && now - boot_at >= 100;
        if ((ordinary || explicit_boot) && bus.idle() && bootable(guarded.interface())) {
            std::uint8_t vectors[8]{};
            if (guarded.inner.read(guarded.inner.context, app_base, vectors, sizeof(vectors))) {
                recovery_trace("UPD app jump", read32(vectors + 4));
                recovery_jump(read32(vectors), read32(vectors + 4));
            }
        }
    }
}
