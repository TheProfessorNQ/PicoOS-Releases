#include "update_board.hpp"
#include "update_flash_mmio.hpp"
namespace picoos::stm32::update {
namespace {
volatile std::uint32_t& reg(std::uint32_t a) { return *reinterpret_cast<volatile std::uint32_t*>(a); }
std::uint32_t previous{}, milliseconds{};
bool trace_pmu = true;
void trace_init() {
    reg(0x40021018U) = reg(0x40021018U) | (1U << 14U) | (1U << 2U); // USART1/GPIOA
    reg(0x40010804U) = (reg(0x40010804U) & ~0xF0U) | 0xB0U; // PA9 alternate push-pull
    reg(0x4001380CU) = 0;
    reg(0x40013810U) = 0;
    reg(0x40013814U) = 0;
    // Match the ROM programming session so GO and startup share one capture.
    reg(0x40013808U) = 139; // 8 MHz / 57600, eight data bits + even parity
    reg(0x4001380CU) = (1U << 13U) | (1U << 12U) | (1U << 10U) | (1U << 3U);
}
void trace_char(char c) {
    // Never make startup depend on a UART or attached host responding.
    unsigned count = 10000;
    while ((reg(0x40013800U) & (1U << 7U)) == 0 && --count) {}
    if (count) reg(0x40013804U) = static_cast<unsigned char>(c);
}
constexpr std::uint32_t gpio_b = 0x40010C00U, scl = 1U << 10U, sda = 1U << 11U;
void delay() { const auto start = reg(0xE0001004U); while (reg(0xE0001004U) - start < 40U) {} }
void line(std::uint32_t pin, bool high) { reg(gpio_b + 0x10) = high ? pin : pin << 16U; }
bool level(std::uint32_t pin) { return (reg(gpio_b + 8) & pin) != 0; }
bool clock_high() {
    line(scl, true);
    const auto start = reg(0xE0001004U);
    for (unsigned n = 0; n < 20000; ++n) {
        if (level(scl)) { delay(); return true; }
        if (reg(0xE0001004U) - start >= 20000U) break;
    }
    return false;
}
void stop() { line(scl, false); line(sda, false); delay(); (void)clock_high(); line(sda, true); delay(); }
bool start() {
    line(sda, true); if (!clock_high() || !level(sda)) { stop(); return false; }
    line(sda, false); delay(); line(scl, false); return true;
}
bool send(std::uint8_t value) {
    for (unsigned n = 0; n < 8; ++n) {
        line(sda, (value & 0x80U) != 0); delay();
        if (!clock_high()) return false;
        line(scl, false); value = static_cast<std::uint8_t>(value << 1U);
    }
    line(sda, true); delay(); if (!clock_high()) return false;
    const bool ack = !level(sda); line(scl, false); return ack;
}
bool read_pmu(void*, std::uint8_t address, std::uint8_t& value) {
    if (!start() || !send(0x68) || !send(address) || !start() || !send(0x69)) {
        stop(); if (trace_pmu) recovery_trace("PMU read NACK", address); return false;
    }
    value = 0; line(sda, true);
    for (unsigned n = 0; n < 8; ++n) {
        delay(); if (!clock_high()) { stop(); return false; }
        value = static_cast<std::uint8_t>((value << 1U) | (level(sda) ? 1U : 0U)); line(scl, false);
    }
    // NACK the sole byte, then STOP.
    line(sda, true); delay(); const bool ok = clock_high(); line(scl, false); stop();
    if (trace_pmu) recovery_trace(ok ? "PMU read" : "PMU read clock", (address << 8U) | value);
    return ok;
}
bool write_pmu(void*, std::uint8_t address, std::uint8_t value) {
    const bool ok = start() && send(0x68) && send(address) && send(value); stop();
    if (trace_pmu) recovery_trace(ok ? "PMU write" : "PMU write NACK", (address << 8U) | value);
    return ok;
}
}
void recovery_trace(const char* message, std::uint32_t value) {
    if ((reg(0x40021018U) & (1U << 14U)) == 0) return;
    for (unsigned n = 0; message[n] && n < 64; ++n) trace_char(message[n]);
    trace_char(' ');
    constexpr char hex[] = "0123456789ABCDEF";
    for (unsigned n = 0; n < 8; ++n) trace_char(hex[(value >> (28U - 4U * n)) & 15U]);
    trace_char('\r'); trace_char('\n');
}
void recovery_trace_pmu_done() { trace_pmu = false; }
bool recovery_clock() {
    __asm volatile("cpsid i");
    reg(0xE000ED08U) = 0x08000000U; // also valid when entered by the ROM GO command
    reg(0xE000E010U) = 0; // SysTick off; reset entry is not a callable app routine.
    reg(0x40021000U) = reg(0x40021000U) | 1U;
    unsigned count = 100000;
    while ((reg(0x40021000U) & 2U) == 0 && --count) {}
    if (!count) return false;
    reg(0x40021004U) = reg(0x40021004U) & ~3U;
    count = 100000;
    while ((reg(0x40021004U) & 0xCU) != 0 && --count) {}
    if (!count) return false;
    reg(0x40021004U) = reg(0x40021004U) & ~0x3FF0U; // AHB/APB at HSI, no division
    trace_init();
    recovery_trace("UPD HSI");
    f103_enable_cycle_counter();
    const auto cycles = reg(0xE0001004U);
    count = 100000;
    while (reg(0xE0001004U) == cycles && --count) {}
    if (!count) { recovery_trace("UPD DWT stopped", reg(0xE0001000U)); return false; }
    previous = reg(0xE0001004U); milliseconds = 0;
    return true;
}
void recovery_outputs(bool enabled) {
    reg(0x40021018U) = reg(0x40021018U) | 0x1DU; // AFIO/GPIOA/B/C
    // PA13/14 are board power outputs: release SWJ before configuring them.
    reg(0x40010004U) = (reg(0x40010004U) & ~0x07000000U) | 0x04000000U;
    reg(0x40010810U) = (1U << 30U) | (enabled ? 1U << 13U : 1U << 29U);
    reg(0x40010804U) = (reg(0x40010804U) & ~0x0FF00000U) | 0x02200000U;
    // LCD visible for RP recovery UI; keyboard light/amplifier remain off.
    reg(0x40010810U) = enabled ? 1U << 8U : 1U << 24U;
    reg(0x40010804U) = (reg(0x40010804U) & ~0xFU) | 2U;
    reg(0x40011010U) = 1U << 24U;
    reg(0x40011004U) = (reg(0x40011004U) & ~0xFU) | 2U;
}
PowerIo recovery_pmu_bus() {
    reg(gpio_b + 0x10) = scl | sda;
    reg(gpio_b + 4) = (reg(gpio_b + 4) & ~0xFF00U) | 0x6600U; // PB10/11 OD output
    // Release a slave left mid-byte by reset, at most nine clocks, no commands.
    for (unsigned n = 0; n < 9 && !level(sda); ++n) { line(scl, false); delay(); if (!clock_high()) break; }
    stop(); return {nullptr, read_pmu, write_pmu};
}
std::uint32_t recovery_milliseconds() {
    const auto current = reg(0xE0001004U);
    const auto elapsed = (current - previous) / 8000U;
    previous += elapsed * 8000U; milliseconds += elapsed; return milliseconds;
}
bool recovery_requested() {
    reg(0x4002101CU) = reg(0x4002101CU) | (3U << 27U); // BKP/PWR
    reg(0x40007000U) = reg(0x40007000U) | (1U << 8U);
    const bool requested = reg(0x40006C24U) == 0x5055U && reg(0x40006C28U) == 0xAFAAU; // DR9/10
    reg(0x40006C24U) = 0; reg(0x40006C28U) = 0; // RTC DR1/2 untouched
    return requested;
}
[[noreturn]] void recovery_reset() {
    reg(0x4002101CU) = reg(0x4002101CU) | (3U << 27U);
    reg(0x40007000U) = reg(0x40007000U) | (1U << 8U);
    reg(0x40006C24U) = 0x5055U; reg(0x40006C28U) = 0xAFAAU;
    __asm volatile("dsb"); reg(0xE000ED0CU) = 0x05FA0004U; __asm volatile("dsb");
    for (;;) {}
}
[[noreturn]] void recovery_jump(std::uint32_t stack, std::uint32_t reset) {
    reg(0x40005400U) = 0; // I2C1 off; do not reset GPIOA/Pico power
    reg(0x40021010U) = reg(0x40021010U) | (1U << 21U);
    reg(0x40021010U) = reg(0x40021010U) & ~(1U << 21U);
    for (unsigned i = 0; i < 8; ++i) { reg(0xE000E180U + 4U * i) = 0xFFFFFFFFU; reg(0xE000E280U + 4U * i) = 0xFFFFFFFFU; }
    reg(0xE000E010U) = 0; reg(0xE000ED04U) = (1U << 25U) | (1U << 27U);
    reg(0xE000ED08U) = 0x08002000U;
    // MSP change and branch are one block: no compiler-generated stack use in between.
    __asm volatile("movs r2, #0\nmsr control, r2\nmsr basepri, r2\nmsr faultmask, r2\nmsr msp, %0\ndsb\nisb\ncpsie i\nbx %1" :: "r"(stack), "r"(reset) : "r2", "memory");
    __builtin_unreachable();
}
}
