#pragma once

#include <stdint.h>

namespace picoos { namespace stm32 { namespace battery {

constexpr uint32_t controller_build = 0x53540114U;
inline bool supports_report(uint32_t build) { return build == 0x53540113U || build == controller_build; }
constexpr uint8_t report_register = 0x13;
constexpr uint8_t absent = 0x7d;
constexpr uint8_t settling = 0x7e;
constexpr uint8_t unavailable = 0x7f;

// Only the user-facing estimate passes through this filter. The PMU and
// stock controller handle charge control, warnings and power-off separately.
class Gauge {
public:
    uint8_t reset(uint8_t reason) {
        previous_ = -1;
        return reason;
    }

    uint8_t sample(bool present, bool charging, int percent, int millivolts) {
        if (!present) return reset(absent);
        if (percent < 0 || percent > 100) return reset(unavailable);
        // A near-full terminal voltage makes an empty estimate inconclusive,
        // especially after USB-powered reinsertion. Never infer SOC from it.
        if (percent <= 1 && (millivolts <= 0 || millivolts >= 4000))
            return reset(unavailable);
        const bool consistent = previous_ >= 0 && percent >= previous_ - 2 && percent <= previous_ + 2;
        previous_ = percent;
        return consistent ? static_cast<uint8_t>(percent | (charging ? 0x80 : 0)) : settling;
    }
private:
    int previous_ = -1;
};

}}} // namespace picoos::stm32::battery
