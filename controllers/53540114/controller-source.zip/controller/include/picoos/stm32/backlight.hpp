#ifndef PICOOS_STM32_BACKLIGHT_HPP
#define PICOOS_STM32_BACKLIGHT_HPP

#include <picoos/stm32/model.hpp>

namespace picoos::stm32 {

inline constexpr std::uint32_t backlight_pwm_hz = 10'000U;
inline constexpr std::uint8_t backlight_pwm_max = 240U;

// Protocol levels are normalized, not raw timer values. Preserve the stock
// adjustment ceiling, round to nearest, and reserve zero for true off.
[[nodiscard]] constexpr std::uint8_t backlight_pwm_duty(std::uint8_t level) {
    return static_cast<std::uint8_t>(
        (static_cast<std::uint32_t>(level) * backlight_pwm_max + 127U) / 255U);
}

enum class BacklightChannel : std::uint8_t { lcd, keyboard };
using BacklightPwmWrite = bool (*)(void*, BacklightChannel, std::uint8_t);

[[nodiscard]] inline bool write_backlight_pair(void* context,
                                              BacklightPwmWrite write,
                                              BacklightState levels) {
    if (write == nullptr) return false;
    const bool lcd = write(context, BacklightChannel::lcd,
                           backlight_pwm_duty(levels.lcd));
    // Always attempt both, especially when turning lights off after a failure.
    const bool keyboard = write(context, BacklightChannel::keyboard,
                                backlight_pwm_duty(levels.keyboard));
    return lcd && keyboard;
}

}  // namespace picoos::stm32

#endif
