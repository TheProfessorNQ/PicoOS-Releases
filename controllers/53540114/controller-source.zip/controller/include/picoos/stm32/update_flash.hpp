#pragma once
#include <picoos/stm32/updater.hpp>

namespace picoos::stm32::update {
enum class FlashRegister : std::uint8_t { key, status, control, address };
// An explicit board choice, not chip identification from the shared 0x410 ID.
// Both layouts use only the lower 64 KiB; the RB's upper half is never mutable.
enum class FlashPart : std::uint8_t { stm32f103r8, cks32f103rb };
// ticks must advance independently of interrupts (e.g. Cortex-M3 DWT CYCCNT).
// Backend is single-owner/foreground. Board dispatch must exclude concurrent I2C
// processing during a mutation; it may not invoke this from an I2C ISR.
struct FlashIo {
    void* context{};
    std::uint32_t (*read_register)(void*, FlashRegister){};
    void (*write_register)(void*, FlashRegister, std::uint32_t){};
    bool (*read_memory)(void*, std::uint32_t, std::uint8_t*, std::size_t){};
    void (*write_halfword)(void*, std::uint32_t, std::uint16_t){};
    std::uint32_t (*ticks)(void*){};
    std::uint32_t deadline_ticks{};
};
class F103Flash {
public:
    F103Flash(FlashIo io, std::uint32_t chip, std::uint16_t kilobytes, FlashPart part)
        : io_(io), admitted_(chip == device_id &&
              ((part == FlashPart::stm32f103r8 && kilobytes == 64) ||
               (part == FlashPart::cks32f103rb && kilobytes == 128))) {}
    Flash interface() { return {this, read, erase, program}; }
private:
    bool ready();
    bool unlock();
    bool finish();
    static bool read(void*, std::uint32_t, std::uint8_t*, std::size_t);
    static bool erase(void*, std::uint32_t);
    static bool program(void*, std::uint32_t, std::uint16_t);
    FlashIo io_;
    bool admitted_{};
};
} // namespace picoos::stm32::update
