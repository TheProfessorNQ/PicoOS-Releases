#pragma once
#include <cstdint>
namespace picoos::stm32::update {
struct PowerIo {
    void* context{};
    bool (*read)(void*, std::uint8_t, std::uint8_t&){};
    bool (*write)(void*, std::uint8_t, std::uint8_t){};
};
// Minimal AXP2101 recovery service. Uses the stock PicoCalc thresholds and
// TS/ADC configuration, without changing charging current, voltage or enables.
class RecoveryPower {
public:
    explicit RecoveryPower(PowerIo io) : io_(io) {}
    bool initialize();
    bool poll(std::uint32_t now_ms);
    bool healthy() const { return healthy_ && !shutdown_; }
    bool shutting_down() const { return shutdown_; }
private:
    bool modify(std::uint8_t reg, std::uint8_t clear, std::uint8_t set);
    PowerIo io_;
    std::uint32_t sampled_{};
    unsigned empty_samples_{};
    bool initialized_{}, healthy_{}, shutdown_{};
};
}
