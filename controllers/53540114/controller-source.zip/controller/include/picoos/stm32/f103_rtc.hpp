#ifndef PICOOS_STM32_F103_RTC_HPP
#define PICOOS_STM32_F103_RTC_HPP
#include <picoos/stm32/protocol.h>
#include <cstdint>

namespace picoos::stm32 {
enum class RtcRegister : std::uint8_t {
    apb1enr, pwr_cr, bdcr, crh, crl, prlh, prll, cnth, cntl, marker, version
};
struct RtcRegisterIo {
    void* context{};
    std::uint32_t (*read)(void*, RtcRegister){};
    void (*write)(void*, RtcRegister, std::uint32_t){};
};
struct HardwareRtcSnapshot {
    std::uint32_t seconds{};
    bool valid{};
    bool pending{};
    // Wire values: 0 starting, 1 LSE ready, 2 fault. Not an elapsed-time model.
    std::uint8_t oscillator{};
};

// Actual F103 backup-domain register sequencing. poll() never waits/spins.
// Board glue serializes poll/request/snapshot against I2C interrupts.
class F103Rtc final {
public:
    explicit F103Rtc(RtcRegisterIo io) : io_(io) {}
    void poll(std::uint32_t now_ms);
    PicoOsStm32Status request(bool valid, std::uint64_t seconds = 0);
    HardwareRtcSnapshot snapshot() const { return snapshot_; }
    static constexpr std::uint32_t first_second = 946684800U; // 2000-01-01 UTC
    static constexpr std::uint32_t last_second = 4102444799U; // 2099-12-31 UTC
private:
    enum class State : std::uint8_t { cold, oscillator, sync, configure, configured,
                                      ready, write, written, fault };
    std::uint32_t read(RtcRegister reg) const { return io_.read(io_.context, reg); }
    void write(RtcRegister reg, std::uint32_t value) { io_.write(io_.context, reg, value); }
    void transition(State state, std::uint32_t now) { state_ = state; since_ = now; }
    void fail();
    bool counter(std::uint32_t& value) const;
    RtcRegisterIo io_{};
    HardwareRtcSnapshot snapshot_{};
    State state_{};
    std::uint32_t since_{}, target_{};
    bool owned_{}, target_valid_{};
};
}
#endif
