#ifndef PICOOS_STM32_CLIENT_HPP
#define PICOOS_STM32_CLIENT_HPP

#include <picoos/stm32/protocol.h>

#include <cstddef>
#include <cstdint>

namespace picoos::stm32 {

using ClientExchange = bool (*)(void* context, const std::uint8_t* request,
                                std::size_t request_size,
                                std::uint8_t* fixed_response,
                                std::size_t fixed_response_size);

struct ClientIo {
    void* context{};
    ClientExchange exchange{};
};

enum class ClientResult : std::uint8_t {
    ok,
    invalid_argument,
    io_error,
    codec_error,
    response_mismatch,
    remote_error,
    session_required,
};

struct ClientDiagnostics {
    std::uint32_t successful_transactions{};
    std::uint32_t retries{};
    std::uint32_t io_errors{};
    std::uint32_t codec_errors{};
    std::uint32_t response_mismatches{};
    std::uint32_t remote_errors{};
    std::uint32_t session_synchronizations{};
};

class ControllerClient final {
public:
    explicit ControllerClient(ClientIo io);

    [[nodiscard]] ClientResult synchronize(std::uint32_t session_nonce);
    [[nodiscard]] ClientResult transact(std::uint8_t command,
                                        const std::uint8_t* payload,
                                        std::uint8_t payload_size,
                                        PicoOsStm32Frame& response,
                                        PicoOsStm32Status& remote_status);
    [[nodiscard]] const ClientDiagnostics& diagnostics() const;

private:
    [[nodiscard]] ClientResult exchange_request(
        const PicoOsStm32Frame& request, PicoOsStm32Frame& response,
        PicoOsStm32Status& remote_status);
    [[nodiscard]] std::uint16_t next_transaction();

    ClientIo io_{};
    ClientDiagnostics diagnostics_{};
    std::uint16_t transaction_{};
    bool session_synchronized_{};
};

}  // namespace picoos::stm32

#endif
