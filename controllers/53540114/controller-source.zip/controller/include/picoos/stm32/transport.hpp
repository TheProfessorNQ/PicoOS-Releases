#ifndef PICOOS_STM32_TRANSPORT_HPP
#define PICOOS_STM32_TRANSPORT_HPP

#include <picoos/stm32/server.hpp>

#include <array>
#include <cstddef>
#include <cstdint>

namespace picoos::stm32 {

struct TransportDiagnostics {
    std::uint32_t malformed_frames{};
    std::uint32_t rejected_commands{};
    std::uint32_t duplicate_transactions{};
    std::uint32_t reused_transaction_ids{};
    std::uint32_t response_encode_failures{};
    std::uint32_t bus_recoveries{};
    std::uint32_t session_resynchronizations{};
};

class TransportEndpoint final {
public:
    explicit TransportEndpoint(
        ControllerProfile profile = ControllerProfile::full,
        std::uint32_t build_identity = ControllerServer::build_id);
    [[nodiscard]] PicoOsStm32CodecResult receive(const std::uint8_t* bytes,
                                                  std::size_t size,
                                                  std::uint64_t now_milliseconds);
    [[nodiscard]] const std::uint8_t* response_data() const;
    [[nodiscard]] std::size_t response_size() const;
    [[nodiscard]] ControllerServer& server();
    [[nodiscard]] const ControllerServer& server() const;
    [[nodiscard]] const TransportDiagnostics& diagnostics() const;
    void reset_transport();
    void note_bus_recovery();

private:
    void encode_error(std::uint8_t command, std::uint16_t transaction,
                      PicoOsStm32Status status);
    void encode_response(const PicoOsStm32Frame& response);

    ControllerServer server_{};
    TransportDiagnostics diagnostics_{};
    std::array<std::uint8_t, PICOOS_STM32_FRAME_MAX_SIZE> request_{};
    std::array<std::uint8_t, PICOOS_STM32_FRAME_MAX_SIZE> response_{};
    std::array<std::uint8_t, PICOOS_STM32_FRAME_MAX_SIZE> replay_response_{};
    std::size_t replay_response_size_{};
    std::size_t request_size_{};
    std::size_t response_size_{};
    std::uint16_t transaction_{};
    bool transaction_valid_{};
};

}  // namespace picoos::stm32

#endif
