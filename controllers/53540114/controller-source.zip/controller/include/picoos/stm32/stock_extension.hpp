#ifndef PICOOS_STM32_STOCK_EXTENSION_HPP
#define PICOOS_STM32_STOCK_EXTENSION_HPP

#include <picoos/stm32/transport.hpp>
#include <picoos/stm32/battery_gauge.hpp>

namespace picoos::stm32 {

enum class StockRequestKind : std::uint8_t { invalid, legacy, identity, extended };
[[nodiscard]] StockRequestKind classify_stock_request(const std::uint8_t* bytes,
                                                       std::size_t size, bool overflow);

// Additive observer beside the factory event FIFO. RTC writes enqueue work;
// the board's foreground loop owns all register changes.
// Board glue serializes finish_scan/receive against the I2C ISR.
class StockExtension final {
public:
    static constexpr std::size_t physical_keys = 68U;
    static constexpr std::uint32_t debounce_ms = 20U;
#if defined(PICOOS_CONTROLLER_RESIDENT)
    static constexpr std::uint32_t build_identity = battery::controller_build;
#else
    static constexpr std::uint32_t build_identity = 0x53540108U;
#endif
    static constexpr std::uint8_t identity_register = 0x0fU;
    explicit StockExtension(F103Rtc* rtc = nullptr) {
        endpoint_.server().attach_rtc(rtc);
        endpoint_.server().enable_suspend_ui(true);
    }
    void attach_rtc(F103Rtc* rtc) { endpoint_.server().attach_rtc(rtc); }
    bool request_power_off() { return endpoint_.server().request_power_off(); }
    void enable_power(bool enabled) { endpoint_.server().enable_power(enabled); }
    PowerController& power() { return endpoint_.server().model().power(); }

    void sample_key(std::uint8_t id, bool pressed);
    void finish_scan(std::uint32_t now);
    void observe_backlights(std::uint8_t lcd, std::uint8_t keyboard);
    bool host_handles_battery_key() const {
        return endpoint_.diagnostics().session_resynchronizations != legacy_input_session_;
    }
    void note_legacy_fifo_read() { legacy_input_session_ = endpoint_.diagnostics().session_resynchronizations; }
    void receive(const std::uint8_t* bytes, std::size_t size, std::uint32_t now);
    void bus_recovered();
    [[nodiscard]] const std::uint8_t* response_data() const;
    [[nodiscard]] std::size_t response_size() const;
    [[nodiscard]] static std::size_t identify(std::uint8_t* bytes, std::size_t capacity,
                                             bool hardware_rtc = false);
    [[nodiscard]] const KeyboardQueue& keyboard() const;

private:
    TransportEndpoint endpoint_{ControllerProfile::diagnostic, build_identity};
    std::uint32_t legacy_input_session_{};
    std::array<bool, physical_keys> samples_{};
    std::array<bool, physical_keys> candidate_{};
    std::array<bool, physical_keys> stable_{};
    std::array<std::uint32_t, physical_keys> changed_at_{};
};

}  // namespace picoos::stm32
#endif
