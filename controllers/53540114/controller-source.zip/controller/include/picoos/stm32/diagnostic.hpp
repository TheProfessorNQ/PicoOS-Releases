#ifndef PICOOS_STM32_DIAGNOSTIC_HPP
#define PICOOS_STM32_DIAGNOSTIC_HPP

#include <picoos/stm32/hardware.hpp>
#include <picoos/stm32/transport.hpp>

#include <cstddef>
#include <cstdint>

namespace picoos::stm32 {

// Read-mostly first-hardware-test runtime. It deliberately has no constructor
// parameter capable of enabling physical outputs.
class DiagnosticRuntime final {
public:
    explicit DiagnosticRuntime(HardwareBindings bindings);

    [[nodiscard]] bool bootstrap(const HardwareBootState& state);
    [[nodiscard]] bool poll();
    [[nodiscard]] PicoOsStm32CodecResult receive(const std::uint8_t* bytes,
                                                  std::size_t size,
                                                  std::uint64_t now_milliseconds);
    [[nodiscard]] const std::uint8_t* response_data() const;
    [[nodiscard]] std::size_t response_size() const;
    [[nodiscard]] const HardwareDiagnostics& hardware_diagnostics() const;
    [[nodiscard]] const TransportDiagnostics& transport_diagnostics() const;

private:
    TransportEndpoint endpoint_{ControllerProfile::diagnostic};
    ControllerHardwareAdapter adapter_;
};

}  // namespace picoos::stm32

#endif
