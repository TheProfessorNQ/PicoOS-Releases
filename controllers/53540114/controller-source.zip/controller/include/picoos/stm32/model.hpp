#ifndef PICOOS_STM32_MODEL_HPP
#define PICOOS_STM32_MODEL_HPP

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>

namespace picoos::stm32 {

constexpr std::size_t key_count = 128U;
constexpr std::size_t held_bitmap_bytes = key_count / 8U;
constexpr std::size_t key_queue_capacity = 16U;

enum class KeyTransition : std::uint8_t {
    pressed = 1U,
    released = 2U,
};

struct KeyEvent {
    std::uint32_t sequence{};
    std::uint32_t timestamp_milliseconds{};
    std::uint8_t key_id{};
    KeyTransition transition{};
    std::uint8_t modifiers{};
};

struct KeySnapshot {
    std::uint32_t next_sequence{};
    std::uint32_t overflow_count{};
    std::array<std::uint8_t, held_bitmap_bytes> held{};
};

class KeyboardQueue final {
public:
    bool transition(std::uint8_t key_id, bool pressed, std::uint8_t modifiers,
                    std::uint32_t timestamp_milliseconds);
    [[nodiscard]] std::optional<KeyEvent> pop();
    [[nodiscard]] KeySnapshot snapshot() const;
    void clear_overflow();
    void reset();
    [[nodiscard]] std::size_t size() const;
    [[nodiscard]] bool held(std::uint8_t key_id) const;
    void set_caps_lock(bool enabled) { caps_lock_ = enabled; }
    [[nodiscard]] bool caps_lock() const { return caps_lock_; }

private:
    void set_held(std::uint8_t key_id, bool pressed);

    std::array<KeyEvent, key_queue_capacity> events_{};
    std::array<std::uint8_t, held_bitmap_bytes> held_{};
    std::size_t head_{};
    std::size_t size_{};
    std::uint32_t next_sequence_{1U};
    std::uint32_t overflow_count_{};
    bool caps_lock_{};
};

class RtcClock final {
public:
    void set(std::uint64_t epoch_seconds, std::uint64_t monotonic_milliseconds);
    void invalidate();
    [[nodiscard]] bool valid() const;
    [[nodiscard]] std::uint32_t revision() const;
    [[nodiscard]] std::optional<std::uint64_t> read(
        std::uint64_t monotonic_milliseconds) const;

private:
    std::uint64_t epoch_seconds_{};
    std::uint64_t anchor_milliseconds_{};
    std::uint32_t revision_{};
    bool valid_{};
};

enum class PowerState : std::uint8_t {
    running,
    prepared,
    soft_off,
    hard_off,
};

enum class PowerReason : std::uint8_t {
    none,
    user_button,
    picoos_request,
    forced_user,
    low_battery,
    pmu_fault,
    controller_reset,
};

struct BacklightState {
    std::uint8_t lcd{};
    std::uint8_t keyboard{};
};

struct PowerDiagnostics {
    std::uint32_t stale_token_count{};
    std::uint32_t prepare_timeout_count{};
    std::uint32_t heartbeat_timeout_count{};
    std::uint32_t soft_off_count{};
    std::uint32_t wake_count{};
    std::uint32_t hard_off_count{};
};

class PowerController final {
public:
    static constexpr std::uint64_t prepare_timeout_milliseconds = 5'000U;
    static constexpr std::uint64_t heartbeat_timeout_milliseconds = 5'000U;

    [[nodiscard]] std::optional<std::uint32_t> prepare_soft_off(
        std::uint64_t now_milliseconds);
    [[nodiscard]] bool commit_soft_off(std::uint32_t token,
                                       std::uint64_t now_milliseconds);
    [[nodiscard]] bool cancel_soft_off();
    [[nodiscard]] bool wake_from_button();
    void force_hard_off(PowerReason reason);
    void true_power_on(PowerReason reason);
    void heartbeat(std::uint64_t now_milliseconds);
    void set_backlights(std::uint8_t lcd, std::uint8_t keyboard);
    void poll(std::uint64_t now_milliseconds);
    void controller_reset(bool pico_powered, std::uint32_t token_seed);

    [[nodiscard]] PowerState state() const;
    [[nodiscard]] PowerReason last_reason() const;
    [[nodiscard]] bool pico_powered() const;
    [[nodiscard]] BacklightState backlights() const;
    [[nodiscard]] const PowerDiagnostics& diagnostics() const;

private:
    [[nodiscard]] std::uint32_t next_token();
    void clear_prepare();

    PowerState state_{PowerState::running};
    PowerReason last_reason_{PowerReason::controller_reset};
    BacklightState backlights_{};
    PowerDiagnostics diagnostics_{};
    std::uint32_t token_counter_{0x50434F53U};
    std::uint32_t prepared_token_{};
    std::uint64_t prepare_deadline_{};
    std::uint64_t heartbeat_deadline_{};
    bool pico_powered_{true};
    bool heartbeat_armed_{};
};

class DebouncedHeadphone final {
public:
    static constexpr std::uint64_t debounce_milliseconds = 20U;

    [[nodiscard]] std::optional<bool> sample(bool inserted,
                                             std::uint64_t now_milliseconds);
    [[nodiscard]] bool inserted() const;
    [[nodiscard]] bool initialized() const;
    [[nodiscard]] std::uint32_t edge_count() const;

private:
    bool raw_{};
    bool stable_{};
    bool initialized_{};
    std::uint64_t raw_changed_at_{};
    std::uint32_t edge_count_{};
};

enum class ChargerState : std::uint8_t {
    unknown,
    idle,
    precharge,
    constant_current,
    constant_voltage,
    complete,
    fault,
};

enum PmuValidity : std::uint16_t {
    pmu_valid_battery_percent = 1U << 0U,
    pmu_valid_battery_voltage = 1U << 1U,
    pmu_valid_vbus_voltage = 1U << 2U,
    pmu_valid_system_voltage = 1U << 3U,
    pmu_valid_battery_current = 1U << 4U,
};

enum PmuStateFlag : std::uint8_t {
    pmu_state_battery_present = 1U << 0U,
    pmu_state_vbus_present = 1U << 1U,
    pmu_state_charging = 1U << 2U,
    pmu_state_discharging = 1U << 3U,
    pmu_state_full = 1U << 4U,
    pmu_state_low_warning = 1U << 5U,
};

struct PmuSample {
    std::uint16_t validity{};
    std::uint8_t state_flags{};
    std::uint8_t battery_percent{};
    ChargerState charger_state{ChargerState::unknown};
    std::uint16_t battery_millivolts{};
    std::uint16_t vbus_millivolts{};
    std::uint16_t system_millivolts{};
    std::int16_t battery_milliamps{};
    std::uint32_t fault_flags{};
    std::uint32_t last_irq_flags{};
    std::uint8_t warning_threshold_percent{};
    std::uint8_t shutdown_threshold_percent{};
};

struct PmuSnapshot {
    std::uint32_t generation{};
    std::uint32_t captured_milliseconds{};
    PmuSample sample{};
};

class PmuTelemetry final {
public:
    void update(const PmuSample& sample, std::uint32_t captured_milliseconds);
    void reset();
    [[nodiscard]] bool initialized() const;
    [[nodiscard]] const PmuSnapshot& snapshot() const;

private:
    PmuSnapshot snapshot_{};
    bool initialized_{};
};

constexpr std::size_t gpio_channel_capacity = 8U;

enum GpioCapability : std::uint8_t {
    gpio_capability_input = 1U << 0U,
    gpio_capability_output = 1U << 1U,
    gpio_capability_pull_up = 1U << 2U,
    gpio_capability_pull_down = 1U << 3U,
    gpio_capability_wake = 1U << 4U,
    gpio_capability_active_low = 1U << 5U,
};

enum class GpioDirection : std::uint8_t {
    safe = 0U,
    input = 1U,
    output = 2U,
};

enum class GpioPull : std::uint8_t {
    none = 0U,
    up = 1U,
    down = 2U,
};

enum GpioEdge : std::uint8_t {
    gpio_edge_rising = 1U << 0U,
    gpio_edge_falling = 1U << 1U,
};

struct GpioDescriptor {
    std::uint8_t logical_id{};
    std::uint8_t capabilities{};
    bool safe_value{};
};

struct GpioChannelState {
    GpioDescriptor descriptor{};
    GpioDirection direction{GpioDirection::safe};
    GpioPull pull{GpioPull::none};
    bool value{};
    std::uint8_t edges{};
    bool configured{};
};

class GpioBank final {
public:
    [[nodiscard]] bool add(const GpioDescriptor& descriptor);
    [[nodiscard]] std::size_t size() const;
    [[nodiscard]] const GpioChannelState* at(std::size_t index) const;
    [[nodiscard]] const GpioChannelState* find(std::uint8_t logical_id) const;
    [[nodiscard]] bool configure(std::uint8_t logical_id,
                                 GpioDirection direction, GpioPull pull);
    [[nodiscard]] bool write(std::uint8_t logical_id, bool value);
    [[nodiscard]] bool sample_input(std::uint8_t logical_id, bool value);
    [[nodiscard]] std::optional<bool> read(std::uint8_t logical_id) const;
    [[nodiscard]] std::optional<std::uint8_t> edges(
        std::uint8_t logical_id, std::uint8_t clear_mask);
    void restore_safe();

private:
    [[nodiscard]] GpioChannelState* find_mutable(std::uint8_t logical_id);

    std::array<GpioChannelState, gpio_channel_capacity> channels_{};
    std::size_t size_{};
};

class ControllerModel final {
public:
    [[nodiscard]] KeyboardQueue& keyboard();
    [[nodiscard]] const KeyboardQueue& keyboard() const;
    [[nodiscard]] RtcClock& rtc();
    [[nodiscard]] const RtcClock& rtc() const;
    [[nodiscard]] PowerController& power();
    [[nodiscard]] const PowerController& power() const;
    [[nodiscard]] DebouncedHeadphone& headphone();
    [[nodiscard]] const DebouncedHeadphone& headphone() const;
    [[nodiscard]] PmuTelemetry& telemetry();
    [[nodiscard]] const PmuTelemetry& telemetry() const;
    [[nodiscard]] GpioBank& gpio();
    [[nodiscard]] const GpioBank& gpio() const;

    [[nodiscard]] bool commit_soft_off(std::uint32_t token,
                                       std::uint64_t now_milliseconds);
    void force_hard_off(PowerReason reason);
    void true_power_loss();
    void controller_reset(bool pico_powered, std::uint32_t token_seed,
                          bool retain_rtc);

private:
    KeyboardQueue keyboard_{};
    RtcClock rtc_{};
    PowerController power_{};
    DebouncedHeadphone headphone_{};
    PmuTelemetry telemetry_{};
    GpioBank gpio_{};
};

}  // namespace picoos::stm32

#endif
