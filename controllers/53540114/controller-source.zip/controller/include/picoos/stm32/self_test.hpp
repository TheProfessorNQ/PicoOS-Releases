#ifndef PICOOS_STM32_SELF_TEST_HPP
#define PICOOS_STM32_SELF_TEST_HPP

#include <cstdint>

namespace picoos::stm32 {

enum SelfTestBit : std::uint32_t {
    self_test_codec = 1UL << 0U,
    self_test_integrity = 1UL << 1U,
    self_test_duplicate_replay = 1UL << 2U,
    self_test_power_safety = 1UL << 3U,
    self_test_keyboard_recovery = 1UL << 4U,
    self_test_telemetry = 1UL << 5U,
    self_test_gpio_safe_state = 1UL << 6U,
    self_test_client_retry = 1UL << 7U,
    self_test_hardware_boundary = 1UL << 8U,
    self_test_diagnostic_profile = 1UL << 9U,
};

inline constexpr std::uint32_t self_test_all =
    self_test_codec | self_test_integrity | self_test_duplicate_replay |
    self_test_power_safety | self_test_keyboard_recovery | self_test_telemetry |
    self_test_gpio_safe_state | self_test_client_retry |
    self_test_hardware_boundary | self_test_diagnostic_profile;

struct SelfTestReport {
    std::uint32_t passed{};
    std::uint32_t failed{};
    std::uint32_t duplicate_transactions{};
    std::uint32_t queue_overflows{};
};

[[nodiscard]] SelfTestReport run_self_test();

}  // namespace picoos::stm32

#endif
