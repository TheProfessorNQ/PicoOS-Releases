#pragma once
#include <picoos/stm32/updater.hpp>
namespace picoos::stm32::update {
enum class I2cRegister : std::uint8_t { cr1, cr2, oar1, dr, sr1, sr2, ccr, trise };
struct I2cIo {
    void* context{};
    std::uint32_t (*read)(void*, I2cRegister){};
    void (*write)(void*, I2cRegister, std::uint32_t){};
    bool (*lines_idle)(void*){};
};
I2cIo f103_update_i2c1_pins();
// Standalone, polled F103 I2C1 slave. Not an Arduino Wire callback/ISR.
// Requests must end with STOP before the separate 32-byte reply read.
class I2cReceiver {
public:
    I2cReceiver(I2cIo io, Receiver& receiver) : io_(io), receiver_(receiver) {}
    bool initialize_8mhz();
    void poll();
    bool idle();
private:
    void discard();
    void drain_received();
    void finish_received();
    I2cIo io_;
    Receiver& receiver_;
    std::uint8_t request_[packet_bytes]{}, reply_[packet_bytes]{};
    std::size_t received_{}, sent_{};
    bool receiving_{}, transmitting_{}, overflow_{}, initialized_{};
};
}
