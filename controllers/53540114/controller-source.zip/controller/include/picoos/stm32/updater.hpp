#pragma once

#include <cstddef>
#include <cstdint>

namespace picoos::stm32::update {
// Documented F103R8 geometry. No option-byte writes or undocumented flash.
inline constexpr std::uint32_t flash_base = 0x08000000U;
inline constexpr std::uint32_t app_base = flash_base + 8192U;
inline constexpr std::uint32_t manifest_base = flash_base + 65536U - 1024U;
inline constexpr std::uint32_t app_capacity = manifest_base - app_base;
inline constexpr std::uint32_t page_bytes = 1024U;
inline constexpr std::uint32_t layout_id = 1U;
inline constexpr std::uint32_t device_id = 0x410U;
inline constexpr std::size_t packet_bytes = 32;
inline constexpr std::size_t chunk_bytes = 16;
inline constexpr std::size_t package_header_bytes = 40;

struct Flash {
    void* context{};
    bool (*read)(void*, std::uint32_t, std::uint8_t*, std::size_t){};
    bool (*erase_page)(void*, std::uint32_t){};
    bool (*program_halfword)(void*, std::uint32_t, std::uint16_t){};
};
struct Image {
    std::uint32_t length{}, crc{}, build{};
};
enum class State : std::uint8_t { idle, invalidate, erasing, receiving, verifying, committing, complete, failed };
enum class Result : std::uint8_t { ok, busy, argument, session, offset, integrity, io, state };
enum class Command : std::uint8_t { status = 1, begin = 2, data = 3, commit = 4, cancel = 5, boot = 6, hold = 7, enter = 8, installed = 10 };

std::uint32_t crc32(const std::uint8_t* bytes, std::size_t size,
                    std::uint32_t running = 0xFFFFFFFFU);
std::uint32_t read32(const std::uint8_t* bytes);
void write32(std::uint8_t* bytes, std::uint32_t value);
bool valid_image_description(const Image& image);
bool valid_vectors(const std::uint8_t* vectors, std::uint32_t length);
bool decode_package_header(const std::uint8_t* bytes, std::size_t size, Image& image);
bool encode_package_header(Image image, std::uint8_t* bytes, std::size_t size);
bool encode_committed_manifest(Image image, std::uint8_t* bytes, std::size_t size);
// Verifies manifest AND full application on every boot; no heap allocation.
bool bootable(const Flash& flash, Image* image = nullptr);

class Receiver {
public:
    explicit Receiver(Flash flash) : flash_(flash) {}
    Result begin(std::uint32_t session, Image image);
    Result data(std::uint32_t session, std::uint32_t offset, const std::uint8_t* bytes);
    Result commit(std::uint32_t session);
    Result cancel(std::uint32_t session);
    Result request_boot();
    void hold() { held_ = true; boot_requested_ = false; }
    bool held() const { return held_; }
    bool boot_requested() const { return boot_requested_; }
    bool installed(Image& image) const { return bootable(flash_, &image); }
    // Foreground only: at most one page erase or one bounded verification block.
    // Board transport must advertise busy and serialize flash with I2C servicing.
    void poll();
    State state() const { return state_; }
    Result error() const { return error_; }
    std::uint32_t session() const { return session_; }
    std::uint32_t received() const { return received_; }
    Image image() const { return image_; }
private:
    void fail(Result error) { error_ = error; state_ = State::failed; }
    Flash flash_;
    Image image_{};
    State state_{State::idle};
    Result error_{Result::ok};
    std::uint32_t session_{}, received_{}, cursor_{}, crc_{0xFFFFFFFFU};
    bool held_{}, boot_requested_{};
};

// Dedicated fixed-size PU/1 receiver protocol, never a stock keyboard register.
// Reject malformed requests before dispatch. Replies are always initialized.
bool exchange(Receiver& receiver, const std::uint8_t* request, std::size_t size,
              std::uint8_t* reply);
} // namespace picoos::stm32::update
