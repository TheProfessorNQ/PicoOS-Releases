#ifndef PICOOS_STM32_SERVER_HPP
#define PICOOS_STM32_SERVER_HPP

#include <picoos/stm32/model.hpp>
#include <picoos/stm32/f103_rtc.hpp>
#include <picoos/stm32/protocol.h>

#include <cstdint>

namespace picoos::stm32 {

enum class ControllerProfile : std::uint8_t {
    full,
    diagnostic,
};

class ControllerServer final {
public:
    static constexpr std::uint8_t firmware_major = 0U;
    static constexpr std::uint8_t firmware_minor = 2U;
    static constexpr std::uint8_t firmware_patch = 0U;
    static constexpr std::uint32_t build_id = 1U;
    static constexpr std::uint32_t base_capabilities =
        PICOOS_STM32_CAPABILITY_KEY_EVENTS |
        PICOOS_STM32_CAPABILITY_HELD_SNAPSHOT |
        PICOOS_STM32_CAPABILITY_SOFT_OFF |
        PICOOS_STM32_CAPABILITY_RTC |
        PICOOS_STM32_CAPABILITY_PMU_TELEMETRY |
        PICOOS_STM32_CAPABILITY_BACKLIGHTS |
        PICOOS_STM32_CAPABILITY_HEADPHONE |
        PICOOS_STM32_CAPABILITY_DIAGNOSTICS;
    static constexpr std::uint32_t diagnostic_capabilities =
        PICOOS_STM32_CAPABILITY_KEY_EVENTS |
        PICOOS_STM32_CAPABILITY_HELD_SNAPSHOT |
        PICOOS_STM32_CAPABILITY_DIAGNOSTICS;

    explicit ControllerServer(ControllerProfile profile = ControllerProfile::full,
                              std::uint32_t build_identity = build_id);

    [[nodiscard]] PicoOsStm32Status handle(const PicoOsStm32Frame& request,
                                            std::uint64_t now_milliseconds,
                                            PicoOsStm32Frame& response);
    [[nodiscard]] ControllerModel& model();
    [[nodiscard]] const ControllerModel& model() const;
    void attach_rtc(F103Rtc* rtc) { hardware_rtc_ = rtc; }
    // Board glue enables only after installing the physical power path. This
    // does not expose the model-only GPIO/PMU/backlight commands.
    void enable_power(bool enabled) { hardware_power_ = enabled; }
    void enable_suspend_ui(bool enabled) { suspend_ui_ = enabled; }
    bool request_power_off() {
        if ((!hardware_power_ && !suspend_ui_) || model_.power().state() != PowerState::running) return false;
        if (++power_requests_ == 0) ++power_requests_;
        return true;
    }

private:
    [[nodiscard]] bool command_allowed(std::uint8_t command) const;
    static void begin_response(const PicoOsStm32Frame& request,
                               PicoOsStm32Frame& response);
    static PicoOsStm32Status finish(PicoOsStm32Frame& response,
                                    PicoOsStm32Status status,
                                    std::uint8_t payload_size);
    PicoOsStm32Status identify(PicoOsStm32Frame& response) const;
    PicoOsStm32Status status(PicoOsStm32Frame& response) const;
    PicoOsStm32Status key_next(PicoOsStm32Frame& response);
    PicoOsStm32Status key_snapshot(const PicoOsStm32Frame& request,
                                   PicoOsStm32Frame& response) const;
    PicoOsStm32Status rtc_read(std::uint64_t now_milliseconds,
                               PicoOsStm32Frame& response) const;
    PicoOsStm32Status diagnostics(const PicoOsStm32Frame& request,
                                  PicoOsStm32Frame& response) const;
    PicoOsStm32Status telemetry(const PicoOsStm32Frame& request,
                                PicoOsStm32Frame& response) const;
    PicoOsStm32Status gpio_describe(const PicoOsStm32Frame& request,
                                    PicoOsStm32Frame& response) const;
    PicoOsStm32Status gpio_configure(const PicoOsStm32Frame& request,
                                     PicoOsStm32Frame& response);
    PicoOsStm32Status gpio_read(const PicoOsStm32Frame& request,
                                PicoOsStm32Frame& response) const;
    PicoOsStm32Status gpio_write(const PicoOsStm32Frame& request,
                                 PicoOsStm32Frame& response);
    PicoOsStm32Status gpio_edges(const PicoOsStm32Frame& request,
                                 PicoOsStm32Frame& response);

    ControllerModel model_{};
    F103Rtc* hardware_rtc_{};
    bool hardware_power_{};
    bool suspend_ui_{};
    std::uint32_t power_requests_{};
    ControllerProfile profile_{ControllerProfile::full};
    std::uint32_t build_identity_{build_id};
};

}  // namespace picoos::stm32

#endif
