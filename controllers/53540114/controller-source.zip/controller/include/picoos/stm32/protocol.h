#ifndef PICOOS_STM32_PROTOCOL_H
#define PICOOS_STM32_PROTOCOL_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PICOOS_STM32_I2C_ADDRESS 0x1FU
#define PICOOS_STM32_PROTOCOL_MAJOR 1U
#define PICOOS_STM32_PROTOCOL_MINOR 3U
#define PICOOS_STM32_FRAME_MAGIC_0 0x50U
#define PICOOS_STM32_FRAME_MAGIC_1 0x43U
#define PICOOS_STM32_FRAME_HEADER_SIZE 8U
#define PICOOS_STM32_FRAME_CRC_SIZE 2U
#define PICOOS_STM32_FRAME_MAX_SIZE 32U
#define PICOOS_STM32_PAYLOAD_MAX_SIZE \
    (PICOOS_STM32_FRAME_MAX_SIZE - PICOOS_STM32_FRAME_HEADER_SIZE - \
     PICOOS_STM32_FRAME_CRC_SIZE)

typedef enum PicoOsStm32FrameFlag {
    PICOOS_STM32_FRAME_RESPONSE = 1U << 0U,
    PICOOS_STM32_FRAME_ERROR = 1U << 1U
} PicoOsStm32FrameFlag;

typedef enum PicoOsStm32Command {
    PICOOS_STM32_COMMAND_IDENTIFY = 0x01U,
    PICOOS_STM32_COMMAND_STATUS = 0x02U,
    PICOOS_STM32_COMMAND_SESSION_SYNC = 0x03U,

    PICOOS_STM32_COMMAND_KEY_NEXT = 0x10U,
    PICOOS_STM32_COMMAND_KEY_SNAPSHOT = 0x11U,

    PICOOS_STM32_COMMAND_RTC_READ = 0x20U,
    PICOOS_STM32_COMMAND_RTC_SET = 0x21U,
    PICOOS_STM32_COMMAND_RTC_INVALIDATE = 0x22U,

    PICOOS_STM32_COMMAND_POWER_PREPARE = 0x30U,
    PICOOS_STM32_COMMAND_POWER_COMMIT = 0x31U,
    PICOOS_STM32_COMMAND_POWER_CANCEL = 0x32U,
    PICOOS_STM32_COMMAND_HEARTBEAT = 0x33U,
    PICOOS_STM32_COMMAND_POWER_REQUEST = 0x34U,

    PICOOS_STM32_COMMAND_BACKLIGHT_SET = 0x40U,
    PICOOS_STM32_COMMAND_TELEMETRY_READ = 0x41U,
    PICOOS_STM32_COMMAND_HEADPHONE_READ = 0x42U,
    PICOOS_STM32_COMMAND_DIAGNOSTICS_READ = 0x43U,

    PICOOS_STM32_COMMAND_GPIO_DESCRIBE = 0x50U,
    PICOOS_STM32_COMMAND_GPIO_CONFIGURE = 0x51U,
    PICOOS_STM32_COMMAND_GPIO_READ = 0x52U,
    PICOOS_STM32_COMMAND_GPIO_WRITE = 0x53U,
    PICOOS_STM32_COMMAND_GPIO_EDGES = 0x54U
} PicoOsStm32Command;

typedef enum PicoOsStm32Status {
    PICOOS_STM32_STATUS_OK = 0U,
    PICOOS_STM32_STATUS_INVALID_COMMAND = 1U,
    PICOOS_STM32_STATUS_INVALID_ARGUMENT = 2U,
    PICOOS_STM32_STATUS_INVALID_STATE = 3U,
    PICOOS_STM32_STATUS_UNSUPPORTED = 4U,
    PICOOS_STM32_STATUS_BUSY = 5U,
    PICOOS_STM32_STATUS_STALE_TOKEN = 6U,
    PICOOS_STM32_STATUS_INTEGRITY = 7U,
    PICOOS_STM32_STATUS_INTERNAL_ERROR = 8U
} PicoOsStm32Status;

typedef enum PicoOsStm32Capability {
    PICOOS_STM32_CAPABILITY_KEY_EVENTS = 1UL << 0U,
    PICOOS_STM32_CAPABILITY_HELD_SNAPSHOT = 1UL << 1U,
    PICOOS_STM32_CAPABILITY_SOFT_OFF = 1UL << 2U,
    PICOOS_STM32_CAPABILITY_RTC = 1UL << 3U,
    PICOOS_STM32_CAPABILITY_PMU_TELEMETRY = 1UL << 4U,
    PICOOS_STM32_CAPABILITY_BACKLIGHTS = 1UL << 5U,
    PICOOS_STM32_CAPABILITY_HEADPHONE = 1UL << 6U,
    PICOOS_STM32_CAPABILITY_DIAGNOSTICS = 1UL << 7U,
    PICOOS_STM32_CAPABILITY_GPIO = 1UL << 8U,
    // Bits9..11 are the resident update/admission capabilities. This bit
    // promises short Power events without power-cut admission and LCD PWM0.
    PICOOS_STM32_CAPABILITY_SUSPEND_UI = 1UL << 12U
} PicoOsStm32Capability;

typedef enum PicoOsStm32CodecResult {
    PICOOS_STM32_CODEC_OK = 0,
    PICOOS_STM32_CODEC_INVALID_ARGUMENT = 1,
    PICOOS_STM32_CODEC_NO_SPACE = 2,
    PICOOS_STM32_CODEC_TRUNCATED = 3,
    PICOOS_STM32_CODEC_BAD_MAGIC = 4,
    PICOOS_STM32_CODEC_BAD_VERSION = 5,
    PICOOS_STM32_CODEC_BAD_LENGTH = 6,
    PICOOS_STM32_CODEC_BAD_FLAGS = 7,
    PICOOS_STM32_CODEC_BAD_CRC = 8
} PicoOsStm32CodecResult;

typedef struct PicoOsStm32Frame {
    uint8_t command;
    uint16_t transaction;
    uint8_t flags;
    uint8_t payload_size;
    uint8_t payload[PICOOS_STM32_PAYLOAD_MAX_SIZE];
} PicoOsStm32Frame;

uint16_t picoos_stm32_crc16_ccitt(const uint8_t* data, size_t size);
size_t picoos_stm32_frame_encoded_size(const PicoOsStm32Frame* frame);
PicoOsStm32CodecResult picoos_stm32_frame_encode(
    const PicoOsStm32Frame* frame,
    uint8_t* destination,
    size_t capacity,
    size_t* encoded_size);
PicoOsStm32CodecResult picoos_stm32_frame_decode(
    const uint8_t* source,
    size_t size,
    PicoOsStm32Frame* frame);

uint16_t picoos_stm32_read_u16_le(const uint8_t* source);
uint32_t picoos_stm32_read_u32_le(const uint8_t* source);
uint64_t picoos_stm32_read_u64_le(const uint8_t* source);
void picoos_stm32_write_u16_le(uint8_t* destination, uint16_t value);
void picoos_stm32_write_u32_le(uint8_t* destination, uint32_t value);
void picoos_stm32_write_u64_le(uint8_t* destination, uint64_t value);

#ifdef __cplusplus
}
#endif

#endif
