#pragma once
#include <picoos/stm32/updater.hpp>
namespace picoos::stm32::update {
struct Source {
    void* context{};
    // Offset is into the application payload, not its package header.
    bool (*read)(void*, std::uint32_t, std::uint8_t*, std::size_t){};
    std::uint32_t length{};
};
struct Link {
    void* context{};
    bool (*exchange)(void*, const std::uint8_t*, std::uint8_t*){};
};
enum class SendState : std::uint8_t { idle, checking, probing, starting, erasing, sending, committing, verifying, cancelling, complete, cancelled, failed };
class Sender {
public:
    Sender(Source source, Link link) : source_(source), link_(link) {}
    bool start(Image image, std::uint32_t session, std::uint32_t now_ms);
    void poll(std::uint32_t now_ms);
    void cancel();
    SendState state() const { return state_; }
    Result error() const { return error_; }
    std::uint32_t sent() const { return offset_; }
private:
    void fail(Result result) { state_ = SendState::failed; error_ = result; }
    Source source_;
    Link link_;
    Image image_{};
    SendState state_{SendState::idle};
    Result error_{Result::ok};
    std::uint32_t session_{}, offset_{}, crc_{0xFFFFFFFFU}, started_{}, attempt_{};
    unsigned failures_{};
    bool sent_command_{}, commit_sent_{};
};
}
