#pragma once
#include <picoos/stm32/updater.hpp>
namespace picoos::stm32::update {
inline constexpr std::uint8_t rtc_admit_command = 9;
inline constexpr std::uint8_t power_admit_command = 11;
inline constexpr std::uint32_t updater_capability = 1U << 9U;
inline constexpr std::uint32_t rtc_admission_capability = 1U << 10U;
inline constexpr std::uint32_t power_admission_capability = 1U << 11U;
enum class ServicePolicy { operator_admitted, rtc_soft_off };
// Stock-application side only. Queues foreground reset; never resets from I2C.
class ApplicationMaintenance {
public:
    explicit ApplicationMaintenance(std::uint32_t build,
            ServicePolicy policy = ServicePolicy::operator_admitted)
        : build_(build), rtc_enabled_(policy == ServicePolicy::rtc_soft_off),
          power_enabled_(policy == ServicePolicy::rtc_soft_off) {}
    bool receive(const std::uint8_t* request, std::size_t size, std::uint8_t* reply, std::uint32_t now);
    bool reset_due(std::uint32_t now) const { return pending_ && now - accepted_ >= 200U; }
    bool rtc_enabled() const { return rtc_enabled_; }
    bool power_enabled() const { return power_enabled_; }
    bool stop_enabled() const { return stop_enabled_; }
private:
    std::uint32_t build_{}, session_{}, accepted_{};
    bool pending_{}, rtc_enabled_{}, power_enabled_{}, stop_enabled_{};
};
}
