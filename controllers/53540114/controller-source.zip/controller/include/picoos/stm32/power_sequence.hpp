#pragma once
#include <picoos/stm32/model.hpp>

namespace picoos::stm32 {
// Foreground-only physical sequence. The protocol reply is allowed to leave
// the I2C FIFO before any outputs change. Backlights precede Pico EN; wake
// restores the board before allowing another prepare transaction.
class PowerSequence final {
public:
    enum class Phase { awake, acknowledging, asleep, failed };
    template<class Board>
    void poll(PowerController& power, Board& board, bool admitted, bool stop,
              std::uint32_t now) {
        if (!admitted || phase_ == Phase::failed) return;
        if (phase_ == Phase::awake && power.state() == PowerState::soft_off) {
            since_ = now; phase_ = Phase::acknowledging;
        }
        if (phase_ == Phase::acknowledging && now - since_ >= 200U) {
            if (!board.quiesce() || !board.pico_power(false)) { phase_ = Phase::failed; return; }
            phase_ = Phase::asleep;
        }
        if (phase_ == Phase::asleep && stop && !board.stop()) phase_ = Phase::failed;
    }
    template<class Board>
    bool wake(PowerController& power, Board& board) {
        if (phase_ != Phase::asleep) return false;
        if (!board.restore() || !board.pico_power(true)) { phase_ = Phase::failed; return true; }
        static_cast<void>(power.wake_from_button());
        phase_ = Phase::awake;
        return true;
    }
    Phase phase() const { return phase_; }
    bool suspended() const { return phase_ != Phase::awake; }
private:
    Phase phase_{Phase::awake};
    std::uint32_t since_{};
};
}
