#ifndef PICOOS_STM32_HARDWARE_HPP
#define PICOOS_STM32_HARDWARE_HPP

#include <picoos/stm32/model.hpp>

#include <cstdint>

namespace picoos::stm32 {

enum HardwareCapability : std::uint32_t {
    hardware_capability_keyboard = 1UL << 0U,
    hardware_capability_headphone = 1UL << 1U,
    hardware_capability_pmu = 1UL << 2U,
    hardware_capability_rtc_write = 1UL << 3U,
    hardware_capability_backlights = 1UL << 4U,
    hardware_capability_pico_power = 1UL << 5U,
    hardware_capability_stop = 1UL << 6U,
    hardware_capability_hard_shutdown = 1UL << 7U,
};

using HardwareMilliseconds = bool (*)(void* context, std::uint64_t& value);
using HardwareReadKey = bool (*)(void* context, std::uint8_t key_id,
                                 bool& pressed);
using HardwareReadHeadphone = bool (*)(void* context, bool& inserted);
using HardwareReadPmu = bool (*)(void* context, PmuSample& sample);
using HardwareWriteRtc = bool (*)(void* context, bool valid,
                                  std::uint64_t epoch_seconds);
using HardwareWriteBacklights = bool (*)(void* context, BacklightState state);
using HardwareWritePicoPower = bool (*)(void* context, bool powered);
using HardwareAction = bool (*)(void* context);

struct HardwareBindings {
    void* context{};
    std::uint32_t capabilities{};
    HardwareMilliseconds milliseconds{};
    HardwareReadKey read_key{};
    HardwareReadHeadphone read_headphone{};
    HardwareReadPmu read_pmu{};
    HardwareWriteRtc write_rtc{};
    HardwareWriteBacklights write_backlights{};
    HardwareWritePicoPower write_pico_power{};
    HardwareAction enter_stop{};
    HardwareAction hard_shutdown{};
};

// All output permissions default off. A board-specific image must opt in to
// each class of side effect after its recovery and electrical gates pass.
struct HardwarePolicy {
    bool allow_rtc_write{};
    bool allow_backlights{};
    bool allow_pico_power{};
    bool allow_stop{};
    bool allow_hard_shutdown{};
};

struct HardwareBootState {
    std::uint64_t now_milliseconds{};
    std::uint64_t rtc_epoch_seconds{};
    std::uint32_t reset_nonce{};
    bool pico_powered{true};
    bool rtc_valid{};
};

struct HardwareDiagnostics {
    std::uint32_t boots{};
    std::uint32_t polls{};
    std::uint32_t input_failures{};
    std::uint32_t held_state_repairs{};
    std::uint32_t blocked_outputs{};
    std::uint32_t output_failures{};
    std::uint32_t rtc_writes{};
    std::uint32_t backlight_writes{};
    std::uint32_t pico_power_writes{};
    std::uint32_t stop_entries{};
    std::uint32_t hard_shutdowns{};
};

class ControllerHardwareAdapter final {
public:
    ControllerHardwareAdapter(ControllerModel& model, HardwareBindings bindings,
                              HardwarePolicy policy = {});

    [[nodiscard]] bool valid() const;
    [[nodiscard]] bool bootstrap(const HardwareBootState& state);
    [[nodiscard]] bool poll();
    [[nodiscard]] bool wake_from_button();
    [[nodiscard]] const HardwareDiagnostics& diagnostics() const;

private:
    [[nodiscard]] bool has(std::uint32_t capability) const;
    void sample_inputs(std::uint64_t now_milliseconds);
    void synchronize_outputs(std::uint64_t now_milliseconds);
    void synchronize_backlights();
    void synchronize_rtc(std::uint64_t now_milliseconds);
    void synchronize_pico_power();
    void synchronize_power_action();

    ControllerModel& model_;
    HardwareBindings bindings_{};
    HardwarePolicy policy_{};
    HardwareDiagnostics diagnostics_{};
    BacklightState applied_backlights_{};
    std::uint32_t applied_rtc_revision_{};
    PowerState observed_power_state_{PowerState::running};
    bool applied_backlights_valid_{};
    bool backlights_confirmed_{};
    bool applied_pico_power_{true};
    bool pico_power_confirmed_{true};
    bool first_key_scan_{true};
    bool action_handled_{};
    bool bootstrapped_{};
};

}  // namespace picoos::stm32

#endif
