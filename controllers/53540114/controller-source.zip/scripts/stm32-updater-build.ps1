[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Lock = Get-Content -LiteralPath (Join-Path $Root 'dependencies.lock.json') -Raw | ConvertFrom-Json
$CompilerVersion = ($Lock.local_dependencies.stm32_arduino_core.transitive_tools | Where-Object name -eq 'xpack-arm-none-eabi-gcc').version
$Bin = Join-Path $Root "$($Lock.local_dependencies.arduino_cli.data_directory)/packages/STMicroelectronics/tools/xpack-arm-none-eabi-gcc/$CompilerVersion/bin"
$Compiler = Join-Path $Bin 'arm-none-eabi-g++.exe'
if (-not (Test-Path -LiteralPath $Compiler)) { throw 'Pinned STM32 compiler missing.' }
$Output = Join-Path $Root 'build/stm32-resident-updater'
New-Item -ItemType Directory -Force -Path $Output | Out-Null
$Sources = @('controller/src/updater.cpp', 'controller/src/update_flash.cpp', 'controller/src/update_i2c.cpp',
    'controller/src/update_power.cpp', 'controller/boards/picocalc/update_flash_mmio.cpp',
    'controller/boards/picocalc/update_i2c_mmio.cpp', 'controller/boards/picocalc/update_board.cpp',
    'controller/boards/picocalc/update_start.cpp', 'controller/boards/picocalc/update_main.cpp')
$Objects = @()
foreach ($Source in $Sources) {
    $Object = Join-Path $Output ((Split-Path $Source -Leaf) + '.o')
    & $Compiler -mcpu=cortex-m3 -mthumb -Os -std=c++20 -ffreestanding -fno-builtin -fno-exceptions -fno-rtti `
        -fno-threadsafe-statics -fno-unwind-tables -fno-asynchronous-unwind-tables -fstack-usage `
        -ffunction-sections -fdata-sections -Wall -Wextra -Werror `
        -I (Join-Path $Root 'controller/include') -c (Join-Path $Root $Source) -o $Object
    if ($LASTEXITCODE -ne 0) { throw "Resident compilation failed: $Source" }
    $Objects += $Object
}
$Elf = Join-Path $Output 'resident-NOT-ACCEPTED.elf'
& $Compiler -mcpu=cortex-m3 -mthumb -nostdlib '-Wl,--no-undefined,--gc-sections' `
    -T (Join-Path $Root 'controller/boards/picocalc/update_layout.ld') "-Wl,-Map=$Output/resident.map" @Objects -lgcc -o $Elf
if ($LASTEXITCODE -ne 0) { throw 'Resident link/size failed.' }
& (Join-Path $Bin 'arm-none-eabi-objcopy.exe') -O binary $Elf (Join-Path $Output 'resident-NOT-ACCEPTED.bin')
if ($LASTEXITCODE -ne 0) { throw 'Resident binary extraction failed.' }
& (Join-Path $Bin 'arm-none-eabi-size.exe') $Elf
if ($LASTEXITCODE -ne 0) { throw 'Resident size failed.' }
Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $Output 'resident-NOT-ACCEPTED.bin')
Write-Output 'BUILD ONLY: factory recovery and physical PMU/update acceptance required. Matching RP startup integration is opt-in. Does not flash or package an installation.'
