[CmdletBinding()]
param(
    [ValidateSet('doctor', 'baseline', 'stock-candidate', 'stock-updatable-proof', 'logic-proof', 'diagnostic-proof', 'backlight-proof')]
    [string]$Action = 'baseline'
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$LockPath = Join-Path $ProjectRoot 'dependencies.lock.json'

if (-not (Test-Path -LiteralPath $LockPath)) {
    throw "Dependency lock is missing: $LockPath"
}

$Lock = Get-Content -LiteralPath $LockPath -Raw | ConvertFrom-Json
$CliDependency = $Lock.local_dependencies.arduino_cli
$CoreDependency = $Lock.local_dependencies.stm32_arduino_core
$XpowersDependency = $Lock.local_dependencies.stm32_xpowers
$ClockworkDependency = $Lock.reference_dependencies.clockworkpi_picocalc_hardware

$Cli = Join-Path $ProjectRoot (Join-Path $CliDependency.install_directory 'arduino-cli.exe')
$Config = Join-Path $ProjectRoot $CliDependency.config_file
$Core = Join-Path $ProjectRoot (Join-Path $CliDependency.data_directory "packages\STMicroelectronics\hardware\stm32\$($CoreDependency.version)")
$Xpowers = Join-Path $ProjectRoot $XpowersDependency.install_directory
$Clockwork = Join-Path $ProjectRoot $ClockworkDependency.install_directory
$Sketch = Join-Path $Clockwork 'Code\picocalc_keyboard'
$BuildDirectory = Join-Path $ProjectRoot 'build\stm32-upstream'
$OutputDirectory = Join-Path $ProjectRoot 'build\stm32-upstream-output'
$LogicProofSketch = Join-Path $ProjectRoot 'controller\proofs\picoos_controller_logic_proof'
$LogicProofRoot = Join-Path $ProjectRoot 'build\stm32-controller-logic'
$LogicProofLibrary = Join-Path $LogicProofRoot 'PicoOSSTM32'
$LogicProofLibrarySource = Join-Path $LogicProofLibrary 'src'
$LogicProofOutput = Join-Path $ProjectRoot 'build\stm32-controller-logic-output'
$DiagnosticProofSketch = Join-Path $ProjectRoot 'controller\proofs\picoos_controller_diagnostic_proof'
$DiagnosticProofRoot = Join-Path $ProjectRoot 'build\stm32-controller-diagnostic'
$DiagnosticProofLibrary = Join-Path $DiagnosticProofRoot 'PicoOSSTM32'
$DiagnosticProofLibrarySource = Join-Path $DiagnosticProofLibrary 'src'
$DiagnosticProofOutput = Join-Path $ProjectRoot 'build\stm32-controller-diagnostic-output'
$Git = (Get-Command git -ErrorAction Stop).Source

function Assert-File([string]$Path, [string]$Label) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "$Label is missing: $Path. Run .\scripts\bootstrap.ps1 first."
    }
}

function Assert-Directory([string]$Path, [string]$Label) {
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        throw "$Label is missing: $Path. Run .\scripts\bootstrap.ps1 first."
    }
}

function Get-PinnedCommit([string]$Path, [string]$Label, [string]$Expected) {
    $Output = & $Git -c "safe.directory=$Path" -C $Path rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or -not $Output) {
        throw "Could not determine the installed $Label commit."
    }
    $Actual = ($Output | Select-Object -Last 1).Trim()
    if ($Actual -ne $Expected) {
        throw "$Label commit mismatch. Expected $Expected, found $Actual."
    }
    return $Actual
}

function Test-Dependencies {
    Assert-File $Cli 'Arduino CLI'
    Assert-File $Config 'repository-local Arduino CLI configuration'
    Assert-File (Join-Path $Core 'platform.txt') 'STM32duino core'
    Assert-File (Join-Path $Sketch 'picocalc_keyboard.ino') 'ClockworkPi upstream controller sketch'
    Assert-Directory $Xpowers 'ClockworkPi XPowersLib fork'
    $null = Get-PinnedCommit $Xpowers 'XPowersLib' $XpowersDependency.commit
}

function Show-Doctor {
    Test-Dependencies
    Write-Output "Project root:       $ProjectRoot"
    Write-Output "Arduino CLI:        $Cli"
    & $Cli version
    if ($LASTEXITCODE -ne 0) { throw 'Arduino CLI version query failed.' }
    Write-Output "STM32duino core:    $Core"
    Write-Output "Board target:       $($CoreDependency.fqbn)"
    Write-Output "XPowersLib commit:  $($XpowersDependency.commit)"
    Write-Output "Upstream source:    $Sketch"
    Write-Output 'Stock-derived candidate can be built; physical backup/restore is required before flashing.'
}

function Build-UpstreamBaseline {
    Test-Dependencies
    New-Item -ItemType Directory -Force -Path $BuildDirectory, $OutputDirectory | Out-Null

    & $Cli compile `
        --config-file $Config `
        --fqbn $CoreDependency.fqbn `
        --libraries $Xpowers `
        --build-path $BuildDirectory `
        --output-dir $OutputDirectory `
        --warnings all --jobs 4 `
        $Sketch
    if ($LASTEXITCODE -ne 0) {
        throw "Upstream STM32 controller build failed with exit code $LASTEXITCODE."
    }

    $Binary = Get-ChildItem -LiteralPath $OutputDirectory -Filter '*.bin' -File | Select-Object -First 1
    if (-not $Binary) {
        throw "The STM32 build completed without a binary in $OutputDirectory."
    }
    $FlashCapacity = 65536
    if ($Binary.Length -gt $FlashCapacity) {
        throw "Upstream STM32 binary is $($Binary.Length) bytes, exceeding the $FlashCapacity-byte F103R8 flash budget."
    }
    $Hash = (Get-FileHash -LiteralPath $Binary.FullName -Algorithm SHA256).Hash
    Write-Output ''
    Write-Output 'Pinned upstream STM32 controller baseline built successfully.'
    Write-Output "Binary:       $($Binary.FullName)"
    Write-Output "Binary bytes: $($Binary.Length) / $FlashCapacity"
    Write-Output "SHA-256:      $Hash"
    Write-Output 'This verifies reproducibility only; it does not flash or validate physical hardware.'
}

function Build-StockCandidate([switch]$Relocated) {
    Test-Dependencies
    $Adapter = $CoreDependency.i2c_completion_adapter
    if ((Get-FileHash -LiteralPath (Join-Path $Core $Adapter.upstream_file) -Algorithm SHA256).Hash -ne $Adapter.upstream_sha256) {
        throw 'Pinned HAL changed; review the slave completion adapter before building.'
    }
    $CandidateSketch = Join-Path $ProjectRoot 'controller\stock\picocalc_keyboard'
    $Provenance = Get-Content -LiteralPath (Join-Path $ProjectRoot 'controller\stock\upstream.json') -Raw | ConvertFrom-Json
    if ($Provenance.commit -ne $ClockworkDependency.commit) { throw 'Stock derivative provenance differs from the dependency lock.' }
    foreach ($Source in $Provenance.files) {
        $Original = Join-Path $Sketch $Source.name
        if ((Get-FileHash -LiteralPath $Original -Algorithm SHA256).Hash -ne $Source.sha256) {
            throw "Pinned stock source changed: $($Source.name)"
        }
        if ($Source.name -notin @('picocalc_keyboard.ino', 'keyboard.ino', 'fifo.ino', 'battery.ino', 'battery.h')) {
            if ((Get-FileHash -LiteralPath (Join-Path $CandidateSketch $Source.name) -Algorithm SHA256).Hash -ne $Source.sha256) {
                throw "Read-only candidate unexpectedly changed stock board behavior: $($Source.name)"
            }
        }
    }
    # Sleep may mask the separate PC13 indicator, but retain the stock battery
    # thresholds, charge-warning modes and critical shutdown path byte-for-byte.
    $OriginalBattery = (Get-Content -LiteralPath (Join-Path $Sketch 'battery.ino') -Raw).Replace("`r`n", "`n")
    $CandidateBattery = (Get-Content -LiteralPath (Join-Path $CandidateSketch 'battery.ino') -Raw).Replace("`r`n", "`n")
    if ($OriginalBattery.Substring($OriginalBattery.IndexOf('void low_bat()')) -cne
        $CandidateBattery.Substring($CandidateBattery.IndexOf('void low_bat()'))) {
        throw 'Controller LED change altered stock battery/charging protection.'
    }
    $OriginalMain = Get-Content -LiteralPath (Join-Path $Sketch 'picocalc_keyboard.ino') -Raw
    $CandidateMain = Get-Content -LiteralPath (Join-Path $CandidateSketch 'picocalc_keyboard.ino') -Raw
    # Compare after normalizing line endings only. Future power work needs its
    # own deliberate profile; this first-contact image keeps PMU/setup intact.
    $OriginalSafety = $OriginalMain.Substring($OriginalMain.IndexOf('void check_pmu_int()'),
        $OriginalMain.IndexOf('//hp headphone') - $OriginalMain.IndexOf('void check_pmu_int()')).Replace("`r`n", "`n")
    $CandidateSafety = $CandidateMain.Substring($CandidateMain.IndexOf('void check_pmu_int()'),
        $CandidateMain.IndexOf('//hp headphone') - $CandidateMain.IndexOf('void check_pmu_int()')).Replace("`r`n", "`n")
    # The sole power-handler change consumes a short press only while the
    # explicitly admitted resident candidate is asleep. Non-resident builds
    # compile the hook to false; long press, battery safety and setup stay stock.
    $CandidateSafety = $CandidateSafety.Replace('if (!picoos_power_wake() && !picoos_power_request()) key_cb(KEY_POWER,KEY_STATE_PRESSED);', 'key_cb(KEY_POWER,KEY_STATE_PRESSED);')
    $CandidateSafety = $CandidateSafety.Replace("    if (PMU.isBatInsertIrq() || PMU.isBatRemoveIrq() || PMU.isGaugeWdtTimeoutIrq()) invalidate_battery_report();`n", '')
    if ($OriginalSafety -cne $CandidateSafety) { throw 'Read-only candidate changed stock PMU/shutdown/setup code.' }
    $CandidateRoot = Join-Path $ProjectRoot 'build\stm32-stock-candidate'
    $CandidateOutput = Join-Path $ProjectRoot 'build\stm32-stock-candidate-output'
    $RelocationProperties = @()
    if ($Relocated) {
        $CandidateRoot = Join-Path $ProjectRoot 'build\stm32-stock-updatable-proof'
        $CandidateOutput = Join-Path $ProjectRoot 'build\stm32-stock-updatable-proof-output'
        # The upstream linker subtracts offset from maximum_size. Reserve the
        # final 1 KiB metadata page as well as the first 8 KiB receiver region.
        $RelocationProperties = @('--build-property', 'build.flash_offset=0x2000',
            '--build-property', 'upload.maximum_size=64512',
            '--build-property', 'compiler.cpp.extra_flags=-DPICOOS_CONTROLLER_RESIDENT=1')
    }
    $CandidateLibrary = Join-Path $CandidateRoot 'PicoOSSTM32'
    # Stock-derived sketch interposes only the pinned F1 event handler; upstream
    # Arduino/HAL files remain byte-for-byte untouched.
    $RelocationProperties += @('--build-property', 'compiler.c.elf.extra_flags=-Wl,--wrap=HAL_I2C_EV_IRQHandler')
    $CandidateSource = Join-Path $CandidateLibrary 'src'
    New-Item -ItemType Directory -Force -Path $CandidateSource, (Join-Path $CandidateSource 'picoos\stm32'), $CandidateOutput | Out-Null
    Copy-Item -LiteralPath (Join-Path $ProjectRoot 'controller\arduino-library.properties') -Destination (Join-Path $CandidateLibrary 'library.properties') -Force
    Copy-Item -LiteralPath (Join-Path $ProjectRoot 'controller\PicoOSSTM32.h') -Destination $CandidateSource -Force
    Copy-Item -Path (Join-Path $ProjectRoot 'controller\include\picoos\stm32\*') -Destination (Join-Path $CandidateSource 'picoos\stm32') -Force
    Copy-Item -Path (Join-Path $ProjectRoot 'controller\src\*') -Destination $CandidateSource -Force
    & $Cli compile --config-file $Config --fqbn $CoreDependency.fqbn `
        --libraries $Xpowers --library $CandidateLibrary `
        --build-path (Join-Path $CandidateRoot 'build') --output-dir $CandidateOutput `
        --warnings all --jobs 2 @RelocationProperties $CandidateSketch
    if ($LASTEXITCODE -ne 0) { throw "Stock-derived candidate build failed: $LASTEXITCODE" }
    $Binary = Get-Item -LiteralPath (Join-Path $CandidateOutput 'picocalc_keyboard.ino.bin')
    if ($Relocated) {
        if ($Binary.Length -gt 56320 -or $Binary.Length -lt 256 -or ($Binary.Length % 2) -ne 0) {
            throw 'Relocated controller image violates the 55 KiB application region.'
        }
        $Bytes = [IO.File]::ReadAllBytes($Binary.FullName)
        $Stack = [BitConverter]::ToUInt32($Bytes, 0)
        $Reset = [BitConverter]::ToUInt32($Bytes, 4)
        if ($Stack -le 0x20000000 -or $Stack -gt 0x20005000 -or ($Stack % 8) -ne 0 -or
            ($Reset -band 1) -ne 1 -or ($Reset -band 0xFFFFFFFE) -lt 0x08002008 -or
            ($Reset -band 0xFFFFFFFE) -ge (0x08002000 + $Binary.Length)) {
            throw 'Relocated controller vectors are outside the intended application/RAM regions.'
        }
        Write-Output "Relocated keyboard proof: $($Binary.Length) / 56320 bytes; base 0x08002000"
        Write-Output "SHA-256: $((Get-FileHash -LiteralPath $Binary.FullName -Algorithm SHA256).Hash)"
        Write-Output 'APPLICATION ONLY: use controller-install-pack with the matching resident for initial installation. Factory recovery and board acceptance remain required.'
        return
    }
    if ($Binary.Length -gt 65536) { throw 'Stock-derived candidate exceeds 64 KiB controller flash.' }
    Write-Output "Stock-derived candidate bytes: $($Binary.Length) / 65536"
    Write-Output "SHA-256: $((Get-FileHash -LiteralPath $Binary.FullName -Algorithm SHA256).Hash)"
    Write-Output 'NOT HARDWARE ACCEPTED: backup/restore and stock regression required before custom flashing.'
    Write-Output 'Key events and foreground hardware RTC; stock power/charging unchanged. No soft-off/GPIO capability.'
}

function Build-ControllerLogicProof {
    Test-Dependencies
    Assert-File (Join-Path $LogicProofSketch 'picoos_controller_logic_proof.ino') 'STM32 controller logic proof'
    New-Item -ItemType Directory -Force -Path `
        $LogicProofLibrarySource, `
        (Join-Path $LogicProofLibrarySource 'picoos\stm32'), `
        $LogicProofOutput | Out-Null

    Copy-Item -LiteralPath (Join-Path $ProjectRoot 'controller\arduino-library.properties') `
        -Destination (Join-Path $LogicProofLibrary 'library.properties') -Force
    Copy-Item -LiteralPath (Join-Path $ProjectRoot 'controller\PicoOSSTM32.h') `
        -Destination (Join-Path $LogicProofLibrarySource 'PicoOSSTM32.h') -Force
    Copy-Item -Path (Join-Path $ProjectRoot 'controller\include\picoos\stm32\*') `
        -Destination (Join-Path $LogicProofLibrarySource 'picoos\stm32') -Force
    Copy-Item -Path (Join-Path $ProjectRoot 'controller\src\*') `
        -Destination $LogicProofLibrarySource -Force

    $BuildDirectory = Join-Path $LogicProofRoot 'build'
    New-Item -ItemType Directory -Force -Path $BuildDirectory | Out-Null
    & $Cli compile `
        --config-file $Config `
        --fqbn $CoreDependency.fqbn `
        --library $LogicProofLibrary `
        --build-path $BuildDirectory `
        --output-dir $LogicProofOutput `
        --warnings all --jobs 4 `
        $LogicProofSketch
    if ($LASTEXITCODE -ne 0) {
        throw "PicoOS STM32 controller logic proof failed with exit code $LASTEXITCODE."
    }

    $Binary = Get-ChildItem -LiteralPath $LogicProofOutput -Filter '*.bin' -File | Select-Object -First 1
    if (-not $Binary) { throw 'Controller logic proof produced no binary.' }
    $FlashCapacity = 65536
    if ($Binary.Length -gt $FlashCapacity) {
        throw "Controller logic proof is $($Binary.Length) bytes, exceeding the $FlashCapacity-byte F103R8 flash budget."
    }
    Write-Output ''
    Write-Output 'PicoOS portable STM32 controller logic proof built successfully.'
    Write-Output "Binary:       $($Binary.FullName)"
    Write-Output "Binary bytes: $($Binary.Length) / $FlashCapacity"
    Write-Output "SHA-256:      $((Get-FileHash -LiteralPath $Binary.FullName -Algorithm SHA256).Hash)"
    Write-Output 'This proof contains no board adapters and must not be flashed.'
}

function Build-ControllerDiagnosticProof {
    Test-Dependencies
    Assert-File (Join-Path $DiagnosticProofSketch 'picoos_controller_diagnostic_proof.ino') 'STM32 controller diagnostic proof'
    New-Item -ItemType Directory -Force -Path `
        $DiagnosticProofLibrarySource, `
        (Join-Path $DiagnosticProofLibrarySource 'picoos\stm32'), `
        $DiagnosticProofOutput | Out-Null

    Copy-Item -LiteralPath (Join-Path $ProjectRoot 'controller\arduino-library.properties') `
        -Destination (Join-Path $DiagnosticProofLibrary 'library.properties') -Force
    Copy-Item -LiteralPath (Join-Path $ProjectRoot 'controller\PicoOSSTM32.h') `
        -Destination (Join-Path $DiagnosticProofLibrarySource 'PicoOSSTM32.h') -Force
    Copy-Item -Path (Join-Path $ProjectRoot 'controller\include\picoos\stm32\*') `
        -Destination (Join-Path $DiagnosticProofLibrarySource 'picoos\stm32') -Force
    Copy-Item -Path (Join-Path $ProjectRoot 'controller\src\*') `
        -Destination $DiagnosticProofLibrarySource -Force

    $BuildDirectory = Join-Path $DiagnosticProofRoot 'build'
    New-Item -ItemType Directory -Force -Path $BuildDirectory | Out-Null
    & $Cli compile `
        --config-file $Config `
        --fqbn $CoreDependency.fqbn `
        --library $DiagnosticProofLibrary `
        --build-path $BuildDirectory `
        --output-dir $DiagnosticProofOutput `
        --warnings all --jobs 4 `
        $DiagnosticProofSketch
    if ($LASTEXITCODE -ne 0) {
        throw "PicoOS STM32 controller diagnostic proof failed with exit code $LASTEXITCODE."
    }

    $Binary = Get-ChildItem -LiteralPath $DiagnosticProofOutput -Filter '*.bin' -File | Select-Object -First 1
    if (-not $Binary) { throw 'Controller diagnostic proof produced no binary.' }
    $FlashCapacity = 65536
    if ($Binary.Length -gt $FlashCapacity) {
        throw "Controller diagnostic proof is $($Binary.Length) bytes, exceeding the $FlashCapacity-byte F103R8 flash budget."
    }
    Write-Output ''
    Write-Output 'PicoOS restricted STM32 diagnostic proof built successfully.'
    Write-Output "Binary:       $($Binary.FullName)"
    Write-Output "Binary bytes: $($Binary.Length) / $FlashCapacity"
    Write-Output "SHA-256:      $((Get-FileHash -LiteralPath $Binary.FullName -Algorithm SHA256).Hash)"
    Write-Output 'NON-FLASHABLE PROOF: no PicoCalc board adapters or stock-behavior integration.'
}

function Build-ControllerBacklightProof {
    Test-Dependencies
    $ProofRoot = Join-Path $ProjectRoot 'build\stm32-controller-backlight'
    $ProofOutput = Join-Path $ProjectRoot 'build\stm32-controller-backlight-output'
    $ProofSketch = Join-Path $ProjectRoot 'controller\proofs\picoos_controller_backlight_proof'
    $Library = Join-Path $ProofRoot 'PicoOSSTM32'
    $Source = Join-Path $Library 'src'
    $BuildPath = Join-Path $ProofRoot 'build'
    New-Item -ItemType Directory -Force -Path $Source, $ProofOutput, $BuildPath,
        (Join-Path $Source 'picoos\stm32'), (Join-Path $Source 'picocalc') | Out-Null
    Copy-Item -LiteralPath (Join-Path $ProjectRoot 'controller\arduino-library.properties') `
        -Destination (Join-Path $Library 'library.properties') -Force
    Copy-Item -LiteralPath (Join-Path $ProjectRoot 'controller\PicoOSSTM32.h') `
        -Destination $Source -Force
    Copy-Item -Path (Join-Path $ProjectRoot 'controller\include\picoos\stm32\*') `
        -Destination (Join-Path $Source 'picoos\stm32') -Force
    Copy-Item -Path (Join-Path $ProjectRoot 'controller\boards\picocalc\backlights.*') `
        -Destination (Join-Path $Source 'picocalc') -Force
    & $Cli compile --config-file $Config --fqbn $CoreDependency.fqbn `
        --library $Library --build-path $BuildPath --output-dir $ProofOutput `
        --warnings all --jobs 4 $ProofSketch
    if ($LASTEXITCODE -ne 0) { throw 'STM32 backlight adapter proof failed.' }
    $Binary = Get-ChildItem -LiteralPath $ProofOutput -Filter '*.bin' -File | Select-Object -First 1
    if (-not $Binary -or $Binary.Length -gt 65536) { throw 'Backlight proof missing or over flash budget.' }
    Write-Output "Backlight adapter proof bytes: $($Binary.Length) / 65536"
    Write-Output "SHA-256: $((Get-FileHash -LiteralPath $Binary.FullName -Algorithm SHA256).Hash)"
    Write-Output 'NON-FLASHABLE: real PWM adapter linked, outputs disabled, no board integration.'
}

Push-Location $ProjectRoot
try {
    switch ($Action) {
        'doctor'   { Show-Doctor }
        'baseline' { Build-UpstreamBaseline }
        'stock-candidate' { Build-StockCandidate }
        'stock-updatable-proof' { Build-StockCandidate -Relocated }
        'logic-proof' { Build-ControllerLogicProof }
        'diagnostic-proof' { Build-ControllerDiagnosticProof }
        'backlight-proof' { Build-ControllerBacklightProof }
    }
}
finally {
    Pop-Location
}
