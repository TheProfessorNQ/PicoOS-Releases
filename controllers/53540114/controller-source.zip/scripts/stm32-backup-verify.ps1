#requires -Version 7.4
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$ReadA,
    [Parameter(Mandatory)][string]$ReadB,
    [Parameter(Mandatory)][string]$ArchiveDirectory,
    [Parameter(Mandatory)][string]$DeviceRecord,
    [string]$Readback
)
$ErrorActionPreference = 'Stop'
$recordPath = (Resolve-Path -LiteralPath $DeviceRecord).Path
$recordBytes = [IO.File]::ReadAllBytes($recordPath)
$record = [Text.Encoding]::UTF8.GetString($recordBytes) | ConvertFrom-Json
# These are backup extents, NOT permission to program either controller.
# Require an explicitly observed part instead of inferring it from shared ID 0x0410.
$expectedBytes = switch ($record.controller_model) {
    'STM32F103R8T6' { 65536 }
    'CKS32F103RBT6' { 131072 }
    default { throw 'Unsupported or missing observed controller_model. Review the exact part before backup verification.' }
}
if ($record.device_id -ne '0x0410' -or $record.flash_bytes -ne $expectedBytes -or
    !$record.board_revision -or !$record.controller_marking -or !$record.tool_version -or
    !$record.port -or $record.independent_reads_confirmed -ne $true) {
    throw 'Device record must confirm the reviewed model/capacity, ID 0x0410, board revision, marking, tool version, port and independent reads.'
}
function Read-FactoryImage([string]$Path) {
    $full = (Resolve-Path -LiteralPath $Path).Path
    $data = [IO.File]::ReadAllBytes($full)
    if ($data.Length -ne $expectedBytes) { throw "Factory image must contain exactly $expectedBytes bytes: $full" }
    # Explicit little-endian vector decoding; do not infer a board from these.
    [uint32]$stack = [BitConverter]::ToUInt32($data,0)
    [uint32]$entry = [BitConverter]::ToUInt32($data,4)
    if (![BitConverter]::IsLittleEndian) { throw 'This verifier requires a little-endian Windows host.' }
    if ($stack -le 0x20000000 -or $stack -gt 0x20005000 -or ($stack -band 7) -ne 0) {
        throw "Implausible 20 KiB SRAM stack vector in $full"
    }
    if (($entry -band 1) -ne 1 -or $entry -lt 0x08000001 -or $entry -ge (0x08000000 + $expectedBytes)) {
        throw "Reset vector is outside the observed controller flash in $full"
    }
    [pscustomobject]@{ Path=$full; Bytes=$data; SHA256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($data)); Stack=$stack; Entry=$entry }
}
$a = Read-FactoryImage $ReadA
$b = Read-FactoryImage $ReadB
if ($a.Path -eq $b.Path) { throw 'Provide two different independent-read files.' }
if ($a.SHA256 -cne $b.SHA256) { throw 'Factory reads differ. Do not erase or program the controller.' }
$verifiedReadback = $null
if ($Readback) {
    $verifiedReadback = Read-FactoryImage $Readback
    if ($verifiedReadback.Path -in @($a.Path,$b.Path) -or $verifiedReadback.SHA256 -cne $a.SHA256) {
        throw 'Restore readback must be a separate read matching the preserved factory image.'
    }
}
$archive = [IO.Path]::GetFullPath($ArchiveDirectory)
if (Test-Path -LiteralPath $archive) { throw 'Archive destination already exists. Choose a new directory; evidence is never replaced.' }
$null = [IO.Directory]::CreateDirectory($archive)
function Write-New([string]$Name,[byte[]]$Bytes) {
    $path = Join-Path $archive $Name
    $stream = [IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try { $stream.Write($Bytes); $stream.Flush($true) } finally { $stream.Dispose() }
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -cne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($Bytes))) {
        throw "Archive readback verification failed: $Name"
    }
}
Write-New 'factory-read-a.bin' $a.Bytes
Write-New 'factory-read-b.bin' $b.Bytes
Write-New 'device-record.json' $recordBytes
if ($verifiedReadback) { Write-New 'factory-restore-readback.bin' $verifiedReadback.Bytes }
$manifest = [ordered]@{
    schema=2; verified_utc=[DateTime]::UtcNow.ToString('o'); image_bytes=$expectedBytes; sha256=$a.SHA256
    controller_model=$record.controller_model
    stack_vector=('0x{0:X8}' -f $a.Stack); reset_vector=('0x{0:X8}' -f $a.Entry)
    original_read_a=$a.Path; original_read_b=$b.Path
    restore_readback_verified=[bool]$verifiedReadback
    physical_stock_regression_verified=$false
    note='Offline file verification only. This tool never opens a serial port, erases, programs, changes protection, or establishes physical recovery acceptance.'
}
Write-New 'manifest.json' ([Text.UTF8Encoding]::new($false).GetBytes(($manifest | ConvertTo-Json -Depth 4)))
Write-Output "Verified identical factory files and archived copies: $archive"
Write-Output "SHA256: $($a.SHA256)"
Write-Output 'Copy the archive to a second storage device before any programming. Physical restore/boot checks remain separate.'
